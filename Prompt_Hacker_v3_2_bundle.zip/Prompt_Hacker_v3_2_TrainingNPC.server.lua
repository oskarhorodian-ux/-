-- Prompt_Hacker v3.2 — Training NPC server companion
-- Помести этот файл как обычный Script в ServerScriptService.
-- В ServerStorage должна лежать Model TrainingNPC с Humanoid и HumanoidRootPart.
local Players = game:GetService("Players")
local ServerStorage = game:GetService("ServerStorage")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local ServerScriptService = game:GetService("ServerScriptService")
local Debris = game:GetService("Debris")
local TweenService = game:GetService("TweenService")

local function remote(name)
    local r = ReplicatedStorage:FindFirstChild(name)
    if not r then r = Instance.new("RemoteEvent"); r.Name = name; r.Parent = ReplicatedStorage end
    return r
end
local spawnRemote = remote("PH_TrainingNPC_Spawn")
local removeRemote = remote("PH_TrainingNPC_Remove")
local active, connections, lastSpawn = {}, {}, {}
local MAX_DISTANCE, COOLDOWN = 120, 1.5

local function parts(npc)
    if not npc or not npc.Parent then return end
    local h, r = npc:FindFirstChildOfClass("Humanoid"), npc:FindFirstChild("HumanoidRootPart")
    if h and r then return h, r end
end
local function clear(npc)
    for _, c in ipairs(connections[npc] or {}) do pcall(function() c:Disconnect() end) end
    connections[npc] = nil
end
local function billboard(root)
    local gui = root:FindFirstChild("PH_TrainingStatus")
    if gui then return gui end
    gui = Instance.new("BillboardGui"); gui.Name="PH_TrainingStatus"; gui.Size=UDim2.fromOffset(190,58)
    gui.StudsOffset=Vector3.new(0,3.5,0); gui.AlwaysOnTop=true; gui.MaxDistance=120; gui.Parent=root
    local status=Instance.new("TextLabel"); status.Name="Status"; status.Size=UDim2.new(1,0,.55,0)
    status.BackgroundTransparency=1; status.Text="ГОТОВ"; status.TextColor3=Color3.fromRGB(110,255,150)
    status.TextStrokeTransparency=.35; status.Font=Enum.Font.GothamBold; status.TextScaled=true; status.Parent=gui
    local hp=Instance.new("TextLabel"); hp.Name="Health"; hp.Position=UDim2.new(0,0,.55,0); hp.Size=UDim2.new(1,0,.45,0)
    hp.BackgroundTransparency=1; hp.TextColor3=Color3.new(1,1,1); hp.TextStrokeTransparency=.4
    hp.Font=Enum.Font.Gotham; hp.TextScaled=true; hp.Parent=gui
    return gui
end
local function status(npc, msg, color)
    local h,r=parts(npc); if not r then return end
    local gui=billboard(r); local label=gui:FindFirstChild("Status")
    if label then label.Text=tostring(msg):sub(1,42); label.TextColor3=color or Color3.new(1,1,1) end
end
local function floating(root, text, color)
    local p=Instance.new("Part"); p.Name="PH_TrainingFloat"; p.Anchored=true; p.CanCollide=false
    p.CanQuery=false; p.CanTouch=false; p.Transparency=1; p.Size=Vector3.new(.1,.1,.1)
    p.CFrame=root.CFrame*CFrame.new(math.random(-10,10)/10,2.5,0); p.Parent=workspace
    local gui=Instance.new("BillboardGui"); gui.Size=UDim2.fromOffset(100,42); gui.AlwaysOnTop=true; gui.Parent=p
    local t=Instance.new("TextLabel"); t.Size=UDim2.fromScale(1,1); t.BackgroundTransparency=1; t.Text=text
    t.TextColor3=color; t.TextStrokeTransparency=.2; t.Font=Enum.Font.GothamBlack; t.TextScaled=true; t.Parent=gui
    TweenService:Create(p,TweenInfo.new(.8),{CFrame=p.CFrame*CFrame.new(0,2,0)}):Play(); Debris:AddItem(p,.9)
end
local function remove(player)
    local npc=active[player]; active[player]=nil
    if npc then clear(npc); if npc.Parent then npc:Destroy() end end
end
local function observe(owner,npc)
    local hum,root=parts(npc); local list={}; connections[npc]=list
    local gui=billboard(root); local hp=gui:FindFirstChild("Health")
    local function updateHp() if hp and hp.Parent then hp.Text=string.format("HP: %d / %d", math.ceil(hum.Health), math.ceil(hum.MaxHealth)) end end
    updateHp()
    local previous=hum.Health
    table.insert(list,hum.HealthChanged:Connect(function(value)
        local delta=value-previous; previous=value; updateHp()
        if delta<-.01 then local n=math.floor(-delta+.5); floating(root,"-"..n,Color3.fromRGB(255,100,100)); status(npc,"ПОЛУЧЕН УРОН -"..n,Color3.fromRGB(255,110,110))
        elseif delta>.01 then local n=math.floor(delta+.5); floating(root,"+"..n,Color3.fromRGB(100,255,140)); status(npc,"ЛЕЧЕНИЕ",Color3.fromRGB(100,255,140)) end
    end))
    local lastVel=root.AssemblyLinearVelocity; local lastImpulse=0
    table.insert(list,RunService.Heartbeat:Connect(function()
        if not npc.Parent or hum.Health<=0 or not root.Parent then return end
        local vel=root.AssemblyLinearVelocity
        if (vel-lastVel).Magnitude>24 and os.clock()-lastImpulse>.45 then lastImpulse=os.clock(); status(npc,"ОТБРАСЫВАНИЕ / ИМПУЛЬС",Color3.fromRGB(255,190,80)) end
        lastVel=vel
        if hum.FloorMaterial==Enum.Material.Air and vel.Y < -35 then status(npc,"ПАДЕНИЕ",Color3.fromRGB(160,210,255)) end
    end))
    table.insert(list,hum.StateChanged:Connect(function(_,state)
        if state==Enum.HumanoidStateType.FallingDown or state==Enum.HumanoidStateType.Ragdoll then status(npc,"СБИТ С НОГ",Color3.fromRGB(255,170,90))
        elseif state==Enum.HumanoidStateType.Physics then status(npc,"ФИЗИЧЕСКИЙ ЭФФЕКТ",Color3.fromRGB(190,160,255)) end
    end))
    table.insert(list,hum.Died:Connect(function()
        status(npc,"ПОВЕРЖЕН",Color3.fromRGB(255,70,70))
        task.delay(5,function() if npc.Parent then if active[owner]==npc then active[owner]=nil end; clear(npc); npc:Destroy() end end)
    end))
end
local function spawn(player)
    local now=os.clock(); if lastSpawn[player] and now-lastSpawn[player]<COOLDOWN then return end; lastSpawn[player]=now
    local char=player.Character; local playerRoot=char and char:FindFirstChild("HumanoidRootPart"); if not playerRoot then return end
    remove(player)
    local template=ServerStorage:FindFirstChild("TrainingNPC")
    if not template or not template:IsA("Model") then warn("[PH TrainingNPC] Add Model TrainingNPC to ServerStorage"); return end
    local npc=template:Clone(); local hum,root=parts(npc)
    if not hum then npc:Destroy(); warn("[PH TrainingNPC] Model needs Humanoid and HumanoidRootPart"); return end
    npc.Name=player.Name.."_TrainingNPC"; npc:SetAttribute("TrainingOwnerUserId",player.UserId); npc:SetAttribute("IsTrainingNPC",true)
    npc.PrimaryPart=root; hum.MaxHealth=math.max(hum.MaxHealth,100); hum.Health=hum.MaxHealth; root:SetNetworkOwner(nil)
    npc:PivotTo(playerRoot.CFrame*CFrame.new(0,0,-8)); npc.Parent=workspace; active[player]=npc; observe(player,npc)
    status(npc,"ТРЕНИРОВОЧНЫЙ NPC",Color3.fromRGB(100,220,255))
end
local function valid(player,npc)
    if active[player]~=npc or not npc or not npc.Parent or npc:GetAttribute("TrainingOwnerUserId")~=player.UserId then return false end
    local char=player.Character; local pr=char and char:FindFirstChild("HumanoidRootPart"); local _,nr=parts(npc)
    return pr and nr and (pr.Position-nr.Position).Magnitude<=MAX_DISTANCE
end
-- Skills in YOUR server code can call this BindableFunction after validating the hit.
local apply=ServerScriptService:FindFirstChild("PH_TrainingNPC_ApplyEffect")
if not apply then apply=Instance.new("BindableFunction"); apply.Name="PH_TrainingNPC_ApplyEffect"; apply.Parent=game:GetService("ServerScriptService") end
apply.OnInvoke=function(player,npc,effect,data)
    data=typeof(data)=="table" and data or {}; if not valid(player,npc) then return false end
    local hum,root=parts(npc); if not hum or hum.Health<=0 then return false end
    local amount=math.clamp(tonumber(data.Amount) or 15,0,250); local duration=math.clamp(tonumber(data.Duration) or 1.5,.1,12)
    if effect=="Damage" then hum:TakeDamage(amount)
    elseif effect=="Heal" then hum.Health=math.min(hum.MaxHealth,hum.Health+amount)
    elseif effect=="Knockback" or effect=="Launch" then
        local dir=typeof(data.Direction)=="Vector3" and data.Direction or -root.CFrame.LookVector; if dir.Magnitude<.01 then dir=Vector3.new(0,1,0) end
        local power=math.clamp(tonumber(data.Power) or 65,0,180); root:ApplyImpulse((dir.Unit+Vector3.new(0,effect=="Launch" and .8 or .25,0))*power*root.AssemblyMass)
        status(npc,effect=="Launch" and "ПОДБРОШЕН" or "ОТБРОШЕН",Color3.fromRGB(255,185,90))
    elseif effect=="Stun" or effect=="Freeze" or effect=="Slow" then
        local ws,jp,ar=hum.WalkSpeed,hum.JumpPower,hum.AutoRotate; hum.WalkSpeed=effect=="Slow" and math.clamp(tonumber(data.Speed) or 6,0,16) or 0; hum.JumpPower=0
        if effect~="Slow" then hum.AutoRotate=false end; status(npc,effect=="Freeze" and "ЗАМОРОЖЕН" or effect=="Stun" and "ОГЛУШЁН" or "ЗАМЕДЛЕН",Color3.fromRGB(120,190,255))
        task.delay(duration,function() if hum.Parent and hum.Health>0 then hum.WalkSpeed=ws; hum.JumpPower=jp; hum.AutoRotate=ar end end)
    elseif effect=="Pull" then
        local origin=typeof(data.Origin)=="Vector3" and data.Origin or root.Position; local d=origin-root.Position
        if d.Magnitude>.1 then root:ApplyImpulse(d.Unit*math.clamp(tonumber(data.Power) or 45,0,120)*root.AssemblyMass) end; status(npc,"ПРИТЯНУТ",Color3.fromRGB(190,140,255))
    elseif effect=="Burn" or effect=="Poison" then
        status(npc,effect=="Burn" and "ГОРИТ" or "ОТРАВЛЕН",Color3.fromRGB(255,130,60)); local ticks=math.floor(duration)
        for i=1,ticks do task.delay(i,function() if hum.Parent and hum.Health>0 then hum:TakeDamage(amount/math.max(ticks,1)) end end) end
    elseif effect=="Dodge" then root:ApplyImpulse(root.CFrame.RightVector*(data.Left and -1 or 1)*math.clamp(tonumber(data.Power) or 40,0,100)*root.AssemblyMass); status(npc,"УКЛОНЕНИЕ",Color3.fromRGB(100,230,255))
    elseif effect=="Mark" then status(npc,tostring(data.Label or "ОТМЕЧЕН"),Color3.fromRGB(255,230,90))
    elseif effect=="Reset" then hum.Health=hum.MaxHealth; hum.WalkSpeed=16; hum.JumpPower=50; hum.AutoRotate=true; root.AssemblyLinearVelocity=Vector3.zero; root.AssemblyAngularVelocity=Vector3.zero; status(npc,"СБРОС / ГОТОВ",Color3.fromRGB(100,255,150))
    else return false end
    return true
end
spawnRemote.OnServerEvent:Connect(spawn)
removeRemote.OnServerEvent:Connect(remove)
Players.PlayerRemoving:Connect(function(p) remove(p); lastSpawn[p]=nil end)
