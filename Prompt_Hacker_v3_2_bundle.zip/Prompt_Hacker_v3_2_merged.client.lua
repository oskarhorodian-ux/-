--=========================================================
-- ----- НАЧАЛО ЧАСТИ 1 -----
-- =========================================================

_G.ScriptPaused = false
_G.ScriptDestroyed = false
_G.PH_Toggles = {} -- реестр тумблеров для конфигов (v3.0)

-- ГЛОБАЛЬНЫЕ ПЕРЕМЕННЫЕ ХАКОВ (ВЕРСИЯ 1.7)
local walkSpeedValue = 16
local jumpPowerValue = 50
local flySpeedValue = 50
local flying = false
local noclip = false
local infiniteJumpEnabled = false
local clickTeleportEnabled = false
local autoClickerEnabled = false
local uiSmartClickerEnabled = false
local targetPlayerName = ""
local spectating = false
local autoStalk = false
local playerEspEnabled = false
local itemEspEnabled = false
local hitboxSizeValue = 2
local hitboxExtenderEnabled = false
local showHitboxesEnabled = false
local antiStunEnabled = false

-- ПЕРЕМЕННЫЕ СВЕТА И ТУМАНА
local fullBrightEnabled = false
local removeFogEnabled = false

-- ПЕРЕМЕННЫЕ КОРОБКИ БЕЗОПАСНОСТИ (ЗОНЫ)
local pointA = nil
local pointB = nil
local markerA = nil
local markerB = nil
local zoneBoxVisual = nil
local zoneMode = "Находиться ТОЛЬКО внутри"
local zonesEnabled = false

-- БАЗА ДАННЫХ ДЛЯ ЦЕПОЧЕК ТОЧЕК И ЗИПЛАЙНА (TWEEN)
local savedPoints = {}
local orderCounter = 0

-- ПЕРЕМЕННЫЕ УЛЬТИМАТИВНОЙ СИМУЛЯЦИИ НЕВИДИМОСТИ БЕЗ СМЕРТЕЙ
local invisActive = false
local realCharacter = nil
local ghostSimulationCube = nil
local ghostVisualClone = nil

-- ПЕРЕМЕННЫЕ РЕЖИМА БОГА
local godmodeEnabled = false
local godAirPlatform = nil
local godGroundCube = nil
local godVisualClone = nil
local isQuantumAttacking = false

local Players = game:GetService("Players")
local Player = game.Players.LocalPlayer
local Mouse = Player:GetMouse()
local RunService = game:GetService("RunService")
local VirtualInputManager = game:GetService("VirtualInputManager")
local TweenService = game:GetService("TweenService")
local Lighting = game:GetService("Lighting")

-- PROMPT_HACKER v3.2: единый журнал ошибок
local LogService = game:GetService("LogService")
local function PH_reportError(where, err)
    warn(string.format("[Prompt_Hacker] %s\n%s\n%s", tostring(where), tostring(err), debug.traceback("", 2)))
end
local function PH_safeCall(where, callback, ...)
    local args = table.pack(...)
    local ok, result = xpcall(function() return callback(table.unpack(args, 1, args.n)) end, debug.traceback)
    if not ok then PH_reportError(where, result); return false, result end
    return true, result
end
local phLogConnection
pcall(function()
    phLogConnection = LogService.MessageOut:Connect(function(message, messageType)
        if messageType == Enum.MessageType.MessageError then
            warn("[Prompt_Hacker runtime] " .. tostring(message))
        end
    end)
end)


-- ЗАПОМИНАЕМ ИСХОДНЫЕ НАСТРОЙКИ СВЕТА И ТУМАНА ДЛЯ ИСПРАВЛЕНИЯ СБРОСА ХАКОВ
local defaultBrightness = Lighting.Brightness or 1
local defaultClockTime = Lighting.ClockTime or 12
local defaultFogStart = Lighting.FogStart or 0
local defaultFogEnd = Lighting.FogEnd or 1000
local defaultGlobalShadows = Lighting.GlobalShadows
local defaultAmbient = Lighting.Ambient
local defaultOutdoorAmbient = Lighting.OutdoorAmbient
local defaultAtmosphere = Lighting:FindFirstChildOfClass("Atmosphere") and Lighting:FindFirstChildOfClass("Atmosphere"):Clone() or nil
local defaultSky = Lighting:FindFirstChildOfClass("Sky") and Lighting:FindFirstChildOfClass("Sky"):Clone() or nil

-- =========================================================
-- ----- КОНЕЦ ЧАСТИ 1 -----
-- =========================================================
-- =========================================================
-- ----- НАЧАЛО ЧАСТИ 2 -----
-- =========================================================

local ScreenGui = Instance.new("ScreenGui")
ScreenGui.Name = "PromptHackerGui"
ScreenGui.ResetOnSpawn = false
local parentUI
pcall(function() parentUI = game:GetService("CoreGui") end)
if not parentUI then pcall(function() if type(gethui) == "function" then parentUI = gethui() end end) end
if not parentUI then parentUI = Player:WaitForChild("PlayerGui") end
ScreenGui.Parent = parentUI
if not ScreenGui.Parent then ScreenGui.Parent = Player:WaitForChild("PlayerGui") end

-- ГЛАВНЫЙ ФРЕЙМ МЕНЮ
local MainFrame = Instance.new("Frame")
MainFrame.Name = "MainFrame"
MainFrame.Size = UDim2.new(0, 500, 0, 340)
MainFrame.Position = UDim2.new(0.5, -250, 0.5, -170)
MainFrame.BackgroundColor3 = Color3.fromRGB(25, 25, 25)
MainFrame.BorderSizePixel = 0
MainFrame.Active = true
MainFrame.Draggable = true
MainFrame.Parent = ScreenGui
Instance.new("UICorner", MainFrame).CornerRadius = UDim.new(0, 10)

-- Плавное появление существующего окна (размеры/цвета/расположение сохранены)
do
    local finalSize, finalPosition = MainFrame.Size, MainFrame.Position
    local scale = Instance.new("UIScale")
    scale.Scale = 0.94
    scale.Parent = MainFrame
    MainFrame.BackgroundTransparency = 1
    MainFrame.Size = UDim2.new(finalSize.X.Scale, finalSize.X.Offset * 0.94,
        finalSize.Y.Scale, finalSize.Y.Offset * 0.94)
    MainFrame.Position = finalPosition + UDim2.fromOffset(0, 10)
    TweenService:Create(MainFrame, TweenInfo.new(0.3, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
        Size = finalSize, Position = finalPosition, BackgroundTransparency = 0
    }):Play()
    TweenService:Create(scale, TweenInfo.new(0.3, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {Scale = 1}):Play()
end


-- ЗАГОЛОВОК ЧИТА
local Title = Instance.new("TextLabel")
Title.Size = UDim2.new(1, 0, 0, 35)
Title.BackgroundColor3 = Color3.fromRGB(35, 35, 35)
Title.Text = "  ⚡ PROMPT_HACKER MULTIHACK v3.0"
Title.TextColor3 = Color3.fromRGB(255, 255, 255)
Title.TextSize = 14
Title.Font = Enum.Font.SourceSansBold
Title.TextXAlignment = Enum.TextXAlignment.Left
Title.Parent = MainFrame
Instance.new("UICorner", Title).CornerRadius = UDim.new(0, 10)

-- КНОПКА ПОЛНОГО ЗАКРЫТИЯ (КРАСНЫЙ КРЕСТИК)
local CloseBtn = Instance.new("TextButton")
CloseBtn.Size = UDim2.new(0, 26, 0, 26)
CloseBtn.Position = UDim2.new(1, -31, 0, 4.5)
CloseBtn.BackgroundColor3 = Color3.fromRGB(200, 50, 50)
CloseBtn.Text = "❌"
CloseBtn.TextColor3 = Color3.fromRGB(255, 255, 255)
CloseBtn.TextSize = 12
CloseBtn.Font = Enum.Font.SourceSansBold
CloseBtn.Parent = MainFrame
Instance.new("UICorner", CloseBtn).CornerRadius = UDim.new(0, 6)

CloseBtn.MouseButton1Click:Connect(function()
    _G.ScriptDestroyed = true
    if _G.PromptBuilderMusic then pcall(function() _G.PromptBuilderMusic:Destroy() end) _G.PromptBuilderMusic = nil end
    pcall(function()
        local radio = game:GetService("SoundService"):FindFirstChild("PromptPersonalRadio")
        if radio then radio:Destroy() end
    end)
    _G.ScriptPaused = false
    flying = false
    invisActive = false
    godmodeEnabled = false
    noclip = false
    zonesEnabled = false

    pcall(function()
        local char = Player.Character
        if char then
            local hrp = char:FindFirstChild("HumanoidRootPart")
            local hum = char:FindFirstChildOfClass("Humanoid")
            if hrp then
                hrp.Anchored = false
                hrp.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
                for _, obj in pairs(hrp:GetChildren()) do
                    if obj:IsA("BodyVelocity") or obj:IsA("BodyGyro") or obj:IsA("BodyPosition") then
                        obj:Destroy()
                    end
                end
                if godGroundCube then
                    hrp.CFrame = CFrame.new(godGroundCube.Position + Vector3.new(0, 3, 0))
                elseif ghostSimulationCube then
                    hrp.CFrame = CFrame.new(ghostSimulationCube.Position + Vector3.new(0, 3, 0))
                end
            end
            if hum then
                hum.PlatformStand = false
                hum:ChangeState(Enum.HumanoidStateType.GettingUp)
                hum.WalkSpeed = 16
                hum.JumpPower = 50
                workspace.CurrentCamera.CameraSubject = hum
                local animator = hum:FindFirstChildOfClass("Animator")
                if animator then
                    for _, track in pairs(animator:GetPlayingAnimationTracks()) do
                        track.Speed = 1
                    end
                end
            end
        end
    end)

    pcall(function()
        if markerA then markerA:Destroy() end
        if markerB then markerB:Destroy() end
        if zoneBoxVisual then zoneBoxVisual:Destroy() end
        if godAirPlatform then godAirPlatform:Destroy() end
        if godGroundCube then godGroundCube:Destroy() end
        if godVisualClone then godVisualClone:Destroy() end
        if ghostSimulationCube then ghostSimulationCube:Destroy() end
        if ghostVisualClone then ghostVisualClone:Destroy() end
        
        if _G.SavedZoneBoxes then
            for _, boxData in ipairs(_G.SavedZoneBoxes) do
                if boxData.Visual then boxData.Visual:Destroy() end
                if boxData.MarkerA then boxData.MarkerA:Destroy() end
                if boxData.MarkerB then boxData.MarkerB:Destroy() end
            end
            _G.SavedZoneBoxes = {}
        end
        
        if savedPoints then
            for _, pt in pairs(savedPoints) do 
                if pt.Visual then pt.Visual:Destroy() end 
            end
        end
    end)

    if ScreenGui then
        ScreenGui:Destroy()
    end
end)

-- КНОПКА СВОРАЧИВАНИЯ (ЗЕЛЕНЫЙ МИНУС)
local MinTopBtn = Instance.new("TextButton")
MinTopBtn.Size = UDim2.new(0, 26, 0, 26)
MinTopBtn.Position = UDim2.new(1, -62, 0, 4.5)
MinTopBtn.BackgroundColor3 = Color3.fromRGB(50, 180, 50)
MinTopBtn.Text = "➖"
MinTopBtn.TextColor3 = Color3.fromRGB(255, 255, 255)
MinTopBtn.TextSize = 12
MinTopBtn.Font = Enum.Font.SourceSansBold
MinTopBtn.Parent = MainFrame
Instance.new("UICorner", MinTopBtn).CornerRadius = UDim.new(0, 6)

-- КНОПКА ПАУЗЫ ВСЕХ ХАКОВ (ЖЕЛТАЯ ПАУЗА)
local PauseTopBtn = Instance.new("TextButton")
PauseTopBtn.Size = UDim2.new(0, 26, 0, 26)
PauseTopBtn.Position = UDim2.new(1, -93, 0, 4.5)
PauseTopBtn.BackgroundColor3 = Color3.fromRGB(220, 180, 40)
PauseTopBtn.Text = "⏸"
PauseTopBtn.TextColor3 = Color3.fromRGB(255, 255, 255)
PauseTopBtn.TextSize = 12
PauseTopBtn.Font = Enum.Font.SourceSansBold
PauseTopBtn.Parent = MainFrame
Instance.new("UICorner", PauseTopBtn).CornerRadius = UDim.new(0, 6)

PauseTopBtn.MouseButton1Click:Connect(function()
    _G.ScriptPaused = not _G.ScriptPaused
    PauseTopBtn.BackgroundColor3 = _G.ScriptPaused and Color3.fromRGB(130, 110, 30) or Color3.fromRGB(220, 180, 40)
end)

-- КРУГЛАЯ ПЕРЕТАСКИВАЕМАЯ ИКОНКА ПРИ СВОРАЧИВАНИИ СО СЛУЧАЙНЫМ ЭМОДЗИ
local randomIcons = {"👾", "🤖", "⚡", "🔥", "💀", "👽", "🚀", "💎", "👻", "🎯"}
local chosenIcon = randomIcons[math.random(1, #randomIcons)]

local MinimizeBtn = Instance.new("TextButton")
MinimizeBtn.Size = UDim2.new(0, 45, 0, 45)
MinimizeBtn.Position = UDim2.new(0, 10, 0, 10)
MinimizeBtn.BackgroundColor3 = Color3.fromRGB(35, 35, 35)
MinimizeBtn.Text = chosenIcon
MinimizeBtn.TextSize = 24
MinimizeBtn.Visible = false
MinimizeBtn.Active = true
MinimizeBtn.Draggable = true
MinimizeBtn.Parent = ScreenGui
Instance.new("UICorner", MinimizeBtn).CornerRadius = UDim.new(1, 0)

MinTopBtn.MouseButton1Click:Connect(function() MainFrame.Visible = false; MinimizeBtn.Visible = true end)
MinimizeBtn.MouseButton1Click:Connect(function() MainFrame.Visible = true; MinimizeBtn.Visible = false end)

-- ПАНЕЛЬ ВКЛАДОК СЛЕВА И ОБЛАСТЬ КОНТЕНТА СПРАВА
local Sidebar = Instance.new("Frame")
Sidebar.Name = "TabPanel"
Sidebar.Size = UDim2.new(0, 130, 1, -35)
Sidebar.Position = UDim2.new(0, 0, 0, 35)
Sidebar.BackgroundColor3 = Color3.fromRGB(20, 20, 20)
Sidebar.BorderSizePixel = 0
Sidebar.Parent = MainFrame

local ContentArea = Instance.new("Frame")
ContentArea.Name = "ContentArea"
ContentArea.Size = UDim2.new(1, -140, 1, -45)
ContentArea.Position = UDim2.new(0, 135, 0, 40)
ContentArea.BackgroundTransparency = 1
ContentArea.Parent = MainFrame

-- РАДУЖНАЯ ОБВОДКА ОКНА, ШАПКИ И ЛЕВОЙ ПАНЕЛИ
local mainStroke = Instance.new("UIStroke")
mainStroke.Thickness = 3
mainStroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
mainStroke.Parent = MainFrame

local titleStroke = Instance.new("UIStroke")
titleStroke.Thickness = 2
titleStroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
titleStroke.Parent = Title

local sideStroke = Instance.new("UIStroke")
sideStroke.Thickness = 2
sideStroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
sideStroke.Parent = Sidebar

local miniStroke = Instance.new("UIStroke")
miniStroke.Thickness = 3
miniStroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
miniStroke.Parent = MinimizeBtn

task.spawn(function()
    local hue = 0
    while not _G.ScriptDestroyed do
        local rainbowColor = Color3.fromHSV(hue, 0.85, 1)
        mainStroke.Color = rainbowColor
        titleStroke.Color = rainbowColor
        sideStroke.Color = rainbowColor
        miniStroke.Color = rainbowColor
        Title.TextColor3 = rainbowColor
        
        hue = (hue + 0.004) % 1
        RunService.RenderStepped:Wait()
    end
end)

-- =========================================================
-- ----- КОНЕЦ ЧАСТИ 2 -----
-- =========================================================
-- =========================================================
-- ----- НАЧАЛО ЧАСТИ 3 -----
-- =========================================================

local TabScroll = Instance.new("ScrollingFrame")
TabScroll.Size = UDim2.new(1, -10, 1, -10)
TabScroll.Position = UDim2.new(0, 5, 0, 5)
TabScroll.BackgroundTransparency = 1
TabScroll.BorderSizePixel = 0
TabScroll.ScrollBarThickness = 2
TabScroll.CanvasSize = UDim2.new(0, 0, 0, 0)
TabScroll.AutomaticCanvasSize = Enum.AutomaticSize.Y
TabScroll.Parent = Sidebar

local TabListLayout = Instance.new("UIListLayout")
TabListLayout.Padding = UDim.new(0, 5)
TabListLayout.Parent = TabScroll

local pages = {}
local tabButtons = {}

local function createTab(name)
    local btn = Instance.new("TextButton")
    btn.Size = UDim2.new(1, 0, 0, 32)
    btn.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
    btn.Text = name
    btn.TextColor3 = Color3.fromRGB(200, 200, 200)
    btn.Font = Enum.Font.SourceSansBold
    btn.TextSize = 13
    btn.Parent = TabScroll
    Instance.new("UICorner", btn).CornerRadius = UDim.new(0, 5)

    local page = Instance.new("ScrollingFrame")
    page.Size = UDim2.new(1, 0, 1, 0)
    page.Position = UDim2.new(0, 0, 0, 0)
    page.BackgroundTransparency = 1
    page.BorderSizePixel = 0
    page.ScrollBarThickness = 4
    page.Visible = false
    page.Parent = ContentArea

    local layout = Instance.new("UIListLayout")
    layout.Padding = UDim.new(0, 8)
    layout.Parent = page

    layout:GetPropertyChangedSignal("AbsoluteContentSize"):Connect(function()
        page.CanvasSize = UDim2.new(0, 0, 0, layout.AbsoluteContentSize.Y + 15)
    end)

    btn.MouseButton1Click:Connect(function()
        for _, p in pairs(pages) do p.Visible = false end
        for _, b in pairs(tabButtons) do
            b.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
            b.TextColor3 = Color3.fromRGB(200, 200, 200)
        end
        page.Visible = true
        btn.BackgroundColor3 = Color3.fromRGB(220, 180, 40)
        btn.TextColor3 = Color3.fromRGB(25, 25, 25)
    end)

    table.insert(pages, page)
    table.insert(tabButtons, btn)
    return page
end

local mainPage = createTab("🏠 Основные")
local movePage = createTab("🕊 Полет и Стены")
local playersPage = createTab("👥 Игроки")
local visualsPage = createTab("👁 Визуалы и Бой")
local farmPage = createTab("🤖 Автофарм")
local zonesPage = createTab("🛡️ Зоны")
local pointsPage = createTab("📍 Точки")

pages[1].Visible = true
tabButtons[1].BackgroundColor3 = Color3.fromRGB(220, 180, 40)
tabButtons[1].TextColor3 = Color3.fromRGB(25, 25, 25)

-- =========================================================
-- ----- КОНЕЦ ЧАСТИ 3 -----
-- =========================================================
-- =========================================================
-- ----- НАЧАЛО ЧАСТИ 4 -----
-- =========================================================

local function createToggle(page, text, callback)
    local frame = Instance.new("Frame")
    frame.Size = UDim2.new(1, 0, 0, 35)
    frame.BackgroundTransparency = 1
    frame.Parent = page
    
    local lbl = Instance.new("TextLabel")
    lbl.Size = UDim2.new(1, -65, 1, 0)
    lbl.BackgroundTransparency = 1
    lbl.Text = text
    lbl.TextColor3 = Color3.fromRGB(230, 230, 230)
    lbl.TextSize = 14
    lbl.Font = Enum.Font.SourceSans
    lbl.TextXAlignment = Enum.TextXAlignment.Left
    lbl.Parent = frame
    
    local btn = Instance.new("TextButton")
    btn.Size = UDim2.new(0, 55, 0, 22)
    btn.Position = UDim2.new(1, -55, 0.5, -11)
    btn.BackgroundColor3 = Color3.fromRGB(200, 50, 50)
    btn.Text = "ВЫКЛ"
    btn.TextColor3 = Color3.fromRGB(255, 255, 255)
    btn.TextSize = 11
    btn.Font = Enum.Font.SourceSansBold
    btn.Parent = frame
    Instance.new("UICorner", btn).CornerRadius = UDim.new(0, 5)
    
    local state = false
    btn.MouseButton1Click:Connect(function()
        if _G.ScriptPaused then return end
        state = not state
        btn.Text = state and "ВКЛ" or "ВЫКЛ"
        btn.BackgroundColor3 = state and Color3.fromRGB(50, 180, 50) or Color3.fromRGB(200, 50, 50)
        callback(state)
    end)

    -- программная смена состояния (без вызова callback), чтобы тумблеры могли выключать друг друга
    local api = {
        Set = function(value)
            state = value and true or false
            btn.Text = state and "ВКЛ" or "ВЫКЛ"
            btn.BackgroundColor3 = state and Color3.fromRGB(50, 180, 50) or Color3.fromRGB(200, 50, 50)
        end,
        Get = function() return state end,
        -- смена состояния С вызовом callback (используют конфиги при загрузке)
        Apply = function(value)
            state = value and true or false
            btn.Text = state and "ВКЛ" or "ВЫКЛ"
            btn.BackgroundColor3 = state and Color3.fromRGB(50, 180, 50) or Color3.fromRGB(200, 50, 50)
            callback(state)
        end,
    }
    _G.PH_Toggles = _G.PH_Toggles or {}
    _G.PH_Toggles[text] = api
    return api
end

local function createInput(page, text, placeholder, callback)
    local frame = Instance.new("Frame")
    frame.Size = UDim2.new(1, 0, 0, 35)
    frame.BackgroundTransparency = 1
    frame.Parent = page
    
    local lbl = Instance.new("TextLabel")
    lbl.Size = UDim2.new(0.5, 0, 1, 0)
    lbl.BackgroundTransparency = 1
    lbl.Text = text
    lbl.TextColor3 = Color3.fromRGB(230, 230, 230)
    lbl.TextSize = 14
    lbl.Font = Enum.Font.SourceSans
    lbl.TextXAlignment = Enum.TextXAlignment.Left
    lbl.Parent = frame
    
    local box = Instance.new("TextBox")
    box.Size = UDim2.new(0.5, -5, 0, 24)
    box.Position = UDim2.new(0.5, 5, 0.5, -12)
    box.BackgroundColor3 = Color3.fromRGB(40, 40, 40)
    box.PlaceholderText = placeholder
    box.Text = ""
    box.TextColor3 = Color3.fromRGB(255, 255, 255)
    box.TextSize = 13
    box.Font = Enum.Font.SourceSans
    box.Parent = frame
    Instance.new("UICorner", box).CornerRadius = UDim.new(0, 5)
    
    box.FocusLost:Connect(function() callback(box.Text) end)
end

local function createButton(page, text, callback)
    local btn = Instance.new("TextButton")
    btn.Size = UDim2.new(1, 0, 0, 30)
    btn.BackgroundColor3 = Color3.fromRGB(40, 40, 40)
    btn.Text = text
    btn.TextColor3 = Color3.fromRGB(255, 255, 255)
    btn.TextSize = 13
    btn.Font = Enum.Font.SourceSansBold
    btn.Parent = page
    Instance.new("UICorner", btn).CornerRadius = UDim.new(0, 5)
    btn.MouseButton1Click:Connect(function() if not _G.ScriptDestroyed then callback() end end)
end

-- Тренировочный NPC: кнопки используют серверные RemoteEvent из companion-скрипта.
do
    local ReplicatedStorage = game:GetService("ReplicatedStorage")
    local spawnRemote = ReplicatedStorage:WaitForChild("PH_TrainingNPC_Spawn", 8)
    local removeRemote = ReplicatedStorage:WaitForChild("PH_TrainingNPC_Remove", 8)
    if spawnRemote and removeRemote then
        createButton(visualsPage, "🤖 Создать / пересоздать тренировочного NPC", function()
            spawnRemote:FireServer()
        end)
        createButton(visualsPage, "🧹 Удалить моего тренировочного NPC", function()
            removeRemote:FireServer()
        end)
    else
        warn("[Prompt_Hacker] Training NPC server companion не найден; кнопки NPC не добавлены.")
    end
end

local function createParagraph(page, titleText, contentText)
    local frame = Instance.new("Frame")
    frame.Size = UDim2.new(1, 0, 0, 55)
    frame.BackgroundColor3 = Color3.fromRGB(35, 35, 35)
    frame.Parent = page
    Instance.new("UICorner", frame).CornerRadius = UDim.new(0, 5)
    
    local tl = Instance.new("TextLabel", frame)
    tl.Size = UDim2.new(1, -10, 0, 20)
    tl.Position = UDim2.new(0, 5, 0, 2)
    tl.BackgroundTransparency = 1
    tl.Text = titleText
    tl.TextColor3 = Color3.fromRGB(255, 220, 60)
    tl.TextSize = 13
    tl.Font = Enum.Font.SourceSansBold
    tl.TextXAlignment = Enum.TextXAlignment.Left
    
    local cl = Instance.new("TextLabel", frame)
    cl.Size = UDim2.new(1, -10, 1, -22)
    cl.Position = UDim2.new(0, 5, 0, 22)
    cl.BackgroundTransparency = 1
    cl.Text = contentText
    cl.TextColor3 = Color3.fromRGB(200, 200, 200)
    cl.TextSize = 11
    cl.Font = Enum.Font.SourceSans
    cl.TextWrapped = true
    cl.TextXAlignment = Enum.TextXAlignment.Left
    cl.TextYAlignment = Enum.TextYAlignment.Top
    return frame, cl
end

local function findTargetPlayer(str)
    if str == "" then return nil end
    for _, p in pairs(game.Players:GetPlayers()) do
        if p ~= Player and (p.Name:lower():sub(1, #str) == str:lower() or p.DisplayName:lower():sub(1, #str) == str:lower()) then return p end
    end
    return nil
end

local function updateMovement()
    if _G.ScriptPaused or _G.ScriptDestroyed or invisActive then return end
    local char = Player.Character or Player.CharacterAdded:Wait()
    local hum = char:FindFirstChildOfClass("Humanoid")
    if hum then hum.WalkSpeed = walkSpeedValue; hum.JumpPower = jumpPowerValue; hum.UseJumpPower = true end
end
Player.CharacterAdded:Connect(function() task.wait(1) if not _G.ScriptDestroyed then updateMovement() end end)

-- АВТОНОМНЫЙ ЦИКЛ АНТИ-СТАНА (АБСОЛЮТНО СТАБИЛЕН)
RunService.RenderStepped:Connect(function()
    if antiStunEnabled and Player.Character and not _G.ScriptDestroyed and not _G.ScriptPaused then
        local hum = Player.Character:FindFirstChildOfClass("Humanoid")
        if hum then
            if hum.PlatformStand then hum.PlatformStand = false end
            if hum.Sit then hum.Sit = false end
            if hum.WalkSpeed == 0 then hum.WalkSpeed = walkSpeedValue end
        end
    end
end)
-- УСИЛЕННЫЙ КОНТРОЛЬ СКОРОСТИ И ПРЫЖКА (В КОНЕЦ ЧАСТИ 4)
local function updateMovement()
    local char = Player.Character
    local hum = char and char:FindFirstChildOfClass("Humanoid")
    if hum then
        hum.UseJumpPower = true
        hum.WalkSpeed = walkSpeedValue
        hum.JumpPower = jumpPowerValue
    end
end

-- Постоянное удержание заданной скорости и прыжка, чтобы игра не сбрасывала их обратно на 16/50
RunService.Heartbeat:Connect(function()
    if _G.ScriptDestroyed or _G.ScriptPaused then return end
    local char = Player.Character
    local hum = char and char:FindFirstChildOfClass("Humanoid")
    if hum then
        if walkSpeedValue ~= 16 and hum.WalkSpeed ~= walkSpeedValue then
            hum.WalkSpeed = walkSpeedValue
        end
        if jumpPowerValue ~= 50 then
            hum.UseJumpPower = true
            if hum.JumpPower ~= jumpPowerValue then
                hum.JumpPower = jumpPowerValue
            end
        end
    end
end)

-- =========================================================
-- ----- КОНЕЦ ЧАСТИ 4 -----
-- =========================================================
-- =========================================================
-- ----- НАЧАЛО ЧАСТИ 5.1 -----
-- =========================================================

local randomGreetings = {
    "Версия 2.7. Усиленный Год Мод без случайных спусков, 3D-радар и глаз скрытности готовы!",
    "На связи! Все системы v2.7 в норме, удачной катки и аккуратнее с админами.",
    "Prompt_Hacker v2.7 готов к работе. Помни: главное — не палиться на ровном месте!",
    "Системы активны! Если античит начнет чудить — жми паузу в шапке меню.",
    "Загружено без ошибок. Выбирай нужную вкладку и погнали тестить!"
}
createParagraph(mainPage, "🤖 Твой ИИ-напарник Prompt_Hacker", randomGreetings[math.random(1, #randomGreetings)])

createInput(mainPage, "Скорость бега (Дефолт: 16)", "Число...", function(Text) 
    local num = tonumber(Text)
    if num then walkSpeedValue = num; updateMovement() end 
end)

createInput(mainPage, "Высота прыжка (Дефолт: 50)", "Число...", function(Text) 
    local num = tonumber(Text)
    if num then jumpPowerValue = num; updateMovement() end 
end)

createToggle(mainPage, "⚡ Активировать Анти-Стан (Anti-Stun)", function(Value)
    antiStunEnabled = Value
    if not antiStunEnabled and Player.Character then
        local hum = Player.Character:FindFirstChildOfClass("Humanoid")
        if hum then hum.WalkSpeed = walkSpeedValue end
    end
end)

local function getCustomMoveDirection(hum)
    local camera = workspace.CurrentCamera
    local moveDir = hum and hum.MoveDirection or Vector3.new(0, 0, 0)
    if moveDir.Magnitude == 0 and (flying or godmodeEnabled or invisActive) then
        local dir = Vector3.new(0, 0, 0)
        local UIS = game:GetService("UserInputService")
        if UIS:IsKeyDown(Enum.KeyCode.W) then dir = dir + camera.CFrame.LookVector end
        if UIS:IsKeyDown(Enum.KeyCode.S) then dir = dir - camera.CFrame.LookVector end
        if UIS:IsKeyDown(Enum.KeyCode.A) then dir = dir - camera.CFrame.RightVector end
        if UIS:IsKeyDown(Enum.KeyCode.D) then dir = dir + camera.CFrame.RightVector end
        if dir.Magnitude > 0 then return Vector3.new(dir.X, 0, dir.Z).Unit end
    end
    return moveDir
end

local phantomModeType = "none"
local phantomRunning = false
local phantomMiniBtn = nil
local phantomSafeOffset = Vector3.new(3500, 1500, 3500)
local isCastingSkill = false
local castReturnTimer = 0

local function destroyPhantomObjects()
    if godAirPlatform then pcall(function() godAirPlatform:Destroy() end) godAirPlatform = nil end
    if ghostSimulationCube then pcall(function() ghostSimulationCube:Destroy() end) ghostSimulationCube = nil end
    if ghostVisualClone then pcall(function() ghostVisualClone:Destroy() end) ghostVisualClone = nil end
    if godGroundCube then pcall(function() godGroundCube:Destroy() end) godGroundCube = nil end
    if godVisualClone then pcall(function() godVisualClone:Destroy() end) godVisualClone = nil end
    isCastingSkill = false
    castReturnTimer = 0
end

local function triggerQuantumSkillCast(holdDuration)
    if not phantomRunning or not ghostSimulationCube then return end
    local char = Player.Character
    local hrp = char and char:FindFirstChild("HumanoidRootPart")
    if not hrp then return end

    castReturnTimer = tick() + (holdDuration or 0.25)
    if isCastingSkill then return end
    isCastingSkill = true

    task.spawn(function()
        while phantomRunning and ghostSimulationCube and hrp and tick() < castReturnTimer and not _G.ScriptDestroyed do
            hrp.Anchored = false
            hrp.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
            hrp.CFrame = ghostSimulationCube.CFrame
            RunService.Heartbeat:Wait()
        end
        if phantomRunning and ghostSimulationCube and hrp then
            hrp.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
            hrp.CFrame = CFrame.new(ghostSimulationCube.Position + phantomSafeOffset + Vector3.new(0, 4, 0))
            hrp.Anchored = true
        end
        isCastingSkill = false
    end)
end

local function stopPhantomSystem(keepMiniBtn)
    phantomRunning = false
    local char = Player.Character
    local hrp = char and char:FindFirstChild("HumanoidRootPart")
    local hum = char and char:FindFirstChildOfClass("Humanoid")

    if hrp then
        hrp.Anchored = false
        hrp.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
        if ghostSimulationCube then
            hrp.CFrame = CFrame.new(ghostSimulationCube.Position + Vector3.new(0, 3, 0))
        end
    end
    destroyPhantomObjects()
    if hum then
        workspace.CurrentCamera.CameraSubject = hum
    end
    if not keepMiniBtn and phantomMiniBtn then
        pcall(function() phantomMiniBtn:Destroy() end)
        phantomMiniBtn = nil
    end
end
local function startPhantomSystem(mode)
    stopPhantomSystem(true)
    local char = Player.Character
    local hrp = char and char:FindFirstChild("HumanoidRootPart")
    local hum = char and char:FindFirstChildOfClass("Humanoid")
    if not hrp or not hum then return end

    phantomModeType = mode
    phantomRunning = true
    local startCFrame = hrp.CFrame
    local isInvis = (mode == "invis")

    godAirPlatform = Instance.new("Part")
    godAirPlatform.Name = "Phantom_AirPlatform"
    godAirPlatform.Size = Vector3.new(30, 2, 30)
    godAirPlatform.Position = startCFrame.Position + phantomSafeOffset
    godAirPlatform.Anchored = true
    godAirPlatform.Transparency = 1
    godAirPlatform.CanCollide = true
    godAirPlatform.Parent = workspace

    ghostSimulationCube = Instance.new("Part")
    ghostSimulationCube.Name = "Phantom_SimCube"
    ghostSimulationCube.Size = Vector3.new(2, 2, 2)
    ghostSimulationCube.CFrame = startCFrame
    ghostSimulationCube.Anchored = true
    ghostSimulationCube.Transparency = 1
    ghostSimulationCube.CanCollide = false
    ghostSimulationCube.Parent = workspace
    godGroundCube = ghostSimulationCube

    char.Archivable = true
    ghostVisualClone = char:Clone()
    ghostVisualClone.Name = "Phantom_Visual"
    ghostVisualClone.Parent = workspace
    godVisualClone = ghostVisualClone

    local cloneRoot = ghostVisualClone:FindFirstChild("HumanoidRootPart")
    if cloneRoot then
        ghostVisualClone.PrimaryPart = cloneRoot
    end

    local origTransparency = {}
    for _, origPart in pairs(char:GetDescendants()) do
        if origPart:IsA("BasePart") then
            origTransparency[origPart.Name] = origPart.Transparency
        end
    end

    for _, p in pairs(ghostVisualClone:GetDescendants()) do
        if p:IsA("BasePart") then
            p.CanCollide = false
            p.Anchored = true
            local wasHidden = (origTransparency[p.Name] and origTransparency[p.Name] >= 0.9)
            if p.Name == "HumanoidRootPart" or p.Name:lower():find("hitbox") or p.Name:lower():find("root") or wasHidden then
                p.Transparency = 1
            else
                p.Transparency = isInvis and 0.65 or 0
            end
        elseif p:IsA("Decal") or p:IsA("Texture") then
            p.Transparency = isInvis and 0.5 or 0
        elseif p:IsA("Script") or p:IsA("LocalScript") then
            p:Destroy()
        end
    end
    local cloneHum = ghostVisualClone:FindFirstChildOfClass("Humanoid")
    if cloneHum then cloneHum.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.None end

    if cloneRoot then
        ghostVisualClone:SetPrimaryPartCFrame(startCFrame)
    end

    local lowestY = startCFrame.Position.Y - 3
    for _, part in pairs(ghostVisualClone:GetDescendants()) do
        if part:IsA("BasePart") and part.Name ~= "HumanoidRootPart" then
            local partBottom = part.Position.Y - (part.Size.Y * 0.5)
            if partBottom < lowestY then
                lowestY = partBottom
            end
        end
    end
    local hipOffset = math.max(startCFrame.Position.Y - lowestY, 2.5) + 0.05

    hrp.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
    hrp.CFrame = CFrame.new(startCFrame.Position + phantomSafeOffset + Vector3.new(0, 4, 0))
    hrp.Anchored = true

    local camTarget = ghostVisualClone:FindFirstChild("Head") or cloneRoot or ghostSimulationCube
    workspace.CurrentCamera.CameraSubject = camTarget

    local conns = {}
    local function hookTool(tool)
        if tool:IsA("Tool") then
            table.insert(conns, tool.Activated:Connect(function()
                if phantomRunning then triggerQuantumSkillCast(0.28) end
            end))
        end
    end
    for _, t in pairs(char:GetChildren()) do hookTool(t) end
    table.insert(conns, char.ChildAdded:Connect(hookTool))

    table.insert(conns, workspace.DescendantAdded:Connect(function(obj)
        if not phantomRunning or not ghostSimulationCube then return end
        if obj:IsA("BasePart") then
            local n = obj.Name:lower()
            local isMyAttack = obj:IsDescendantOf(char)
                or ((n:find("hitbox") or n:find("slash") or n:find("punch") or n:find("dmg") or n:find("damage"))
                    and (obj.Position - hrp.Position).Magnitude < 25)
            if isMyAttack then
                triggerQuantumSkillCast(0.28)
            end
        end
    end))

    local UIS = game:GetService("UserInputService")
    table.insert(conns, UIS.InputBegan:Connect(function(input, gp)
        if not phantomRunning or gp then return end
        if input.KeyCode == Enum.KeyCode.One or input.KeyCode == Enum.KeyCode.Two or input.KeyCode == Enum.KeyCode.Three or input.KeyCode == Enum.KeyCode.Four then
            triggerQuantumSkillCast(0.28)
        end
    end))

    task.spawn(function()
        local lastTick = tick()
        local verticalVel = 0

        while phantomRunning and ghostSimulationCube and char and hrp and hum and hum.Health > 0 and not _G.ScriptDestroyed do
            local dt = tick() - lastTick
            lastTick = tick()

            if not _G.ScriptPaused then
                if not spectatingPlayer and not freecamEnabled and camTarget and camTarget.Parent then
                    workspace.CurrentCamera.CameraSubject = camTarget
                end

                local moveDir = getCustomMoveDirection(hum)
                local currentPos = ghostSimulationCube.Position

                if moveDir.Magnitude > 0 then
                    local flatDir = Vector3.new(moveDir.X, 0, moveDir.Z).Unit
                    local step = flatDir * (walkSpeedValue * dt)
                    local ray = Ray.new(currentPos, flatDir * (step.Magnitude + 2))
                    local hitPart = workspace:FindPartOnRayWithIgnoreList(ray, {char, ghostSimulationCube, ghostVisualClone, godAirPlatform})
                    if not hitPart or not hitPart.CanCollide or noclip then
                        currentPos = currentPos + step
                    end
                end

                if hum.Jump and verticalVel == 0 then
                    verticalVel = jumpPowerValue
                end

                local downRay = Ray.new(currentPos + Vector3.new(0, 2, 0), Vector3.new(0, -(hipOffset + 3.0), 0))
                local floorPart, floorPos = workspace:FindPartOnRayWithIgnoreList(downRay, {char, ghostSimulationCube, ghostVisualClone, godAirPlatform})

                if floorPart and floorPart.CanCollide and verticalVel <= 0 and not noclip then
                    currentPos = Vector3.new(currentPos.X, floorPos.Y + hipOffset, currentPos.Z)
                    verticalVel = 0
                else
                    verticalVel = verticalVel - (196.2 * dt)
                    currentPos = currentPos + Vector3.new(0, verticalVel * dt, 0)
                    if currentPos.Y < -300 then
                        currentPos = Vector3.new(currentPos.X, 50, currentPos.Z)
                        verticalVel = 0
                    end
                end

                local lookVec = moveDir.Magnitude > 0 and Vector3.new(moveDir.X, 0, moveDir.Z) or ghostSimulationCube.CFrame.LookVector
                if lookVec.Magnitude > 0 then
                    ghostSimulationCube.CFrame = CFrame.new(currentPos, currentPos + lookVec)
                else
                    ghostSimulationCube.CFrame = CFrame.new(currentPos)
                end

                if ghostVisualClone and ghostVisualClone.PrimaryPart then
                    ghostVisualClone:SetPrimaryPartCFrame(ghostSimulationCube.CFrame)
                end

                if not isCastingSkill and godAirPlatform then
                    godAirPlatform.Position = currentPos + phantomSafeOffset
                    hrp.CFrame = CFrame.new(currentPos + phantomSafeOffset + Vector3.new(0, 4, 0))
                end
            end
            RunService.RenderStepped:Wait()
        end

        for _, c in pairs(conns) do pcall(function() c:Disconnect() end) end
        if phantomRunning then stopPhantomSystem(false) end
    end)
end

local function createOrUpdatePhantomMiniBtn(mode)
    if phantomMiniBtn then pcall(function() phantomMiniBtn:Destroy() end) phantomMiniBtn = nil end
    if ScreenGui then ScreenGui.DisplayOrder = 999 end

    local btn = Instance.new("TextButton")
    btn.Name = "PhantomMiniToggle"
    btn.Size = UDim2.new(0, 130, 0, 34)
    btn.Position = UDim2.new(0.5, -65, 0.13, 0)
    btn.BackgroundColor3 = Color3.fromRGB(50, 180, 50)
    btn.Text = (mode == "invis") and "👻 Инвиз: ВКЛ" or "🛡 Бог: ВКЛ"
    btn.TextColor3 = Color3.fromRGB(255, 255, 255)
    btn.Font = Enum.Font.SourceSansBold
    btn.TextSize = 13
    btn.Active = true
    btn.Draggable = true
    btn.ZIndex = 60
    btn.Parent = ScreenGui
    Instance.new("UICorner", btn).CornerRadius = UDim.new(0, 8)

    local stroke = Instance.new("UIStroke", btn)
    stroke.Thickness = 2
    stroke.Color = Color3.fromRGB(255, 220, 60)

    phantomMiniBtn = btn

    local lastTap = 0
    local function toggleMini()
        if tick() - lastTap < 0.25 then return end
        lastTap = tick()
        if phantomRunning then
            stopPhantomSystem(true)
            btn.Text = (mode == "invis") and "👻 Инвиз: ВЫКЛ" or "🛡 Бог: ВЫКЛ"
            btn.BackgroundColor3 = Color3.fromRGB(200, 50, 50)
        else
            startPhantomSystem(mode)
            btn.Text = (mode == "invis") and "👻 Инвиз: ВКЛ" or "🛡 Бог: ВКЛ"
            btn.BackgroundColor3 = Color3.fromRGB(50, 180, 50)
        end
    end

    btn.MouseButton1Down:Connect(toggleMini)
    btn.TouchTap:Connect(toggleMini)
end

Player.CharacterRemoving:Connect(function()
    stopPhantomSystem(false)
    godmodeEnabled = false
    invisActive = false
end)

-- =========================================================
-- ----- КОНЕЦ ЧАСТИ 5.1 -----
-- =========================================================
-- =========================================================
-- ----- НАЧАЛО ЧАСТИ 5.2 -----
-- =========================================================

local UIS = game:GetService("UserInputService")
local godToggleObj = nil
local invisToggleObj = nil

godToggleObj = createToggle(mainPage, "🛡 Режим Бога (Анти-урон + Уклонение)", function(Value)
    godmodeEnabled = Value
    if godmodeEnabled then
        if invisActive then
            invisActive = false
            if invisToggleObj and invisToggleObj.Set then invisToggleObj.Set(false) end
        end
        startPhantomSystem("god")
        createOrUpdatePhantomMiniBtn("god")
    else
        if not invisActive then
            stopPhantomSystem(false)
        end
    end
end)

invisToggleObj = createToggle(mainPage, "👻 Невидимость (Квантовый инвиз)", function(Value)
    invisActive = Value
    if invisActive then
        if godmodeEnabled then
            godmodeEnabled = false
            if godToggleObj and godToggleObj.Set then godToggleObj.Set(false) end
        end
        startPhantomSystem("invis")
        createOrUpdatePhantomMiniBtn("invis")
    else
        if not godmodeEnabled then
            stopPhantomSystem(false)
        end
    end
end)

-- после смерти/респавна возвращаем тумблеры в положение "ВЫКЛ", чтобы они не врали
Player.CharacterRemoving:Connect(function()
    if godToggleObj and godToggleObj.Set then godToggleObj.Set(false) end
    if invisToggleObj and invisToggleObj.Set then invisToggleObj.Set(false) end
end)

clickTpEnabled = false
createToggle(mainPage, "🖱 Click TP (появится кнопка ON/OFF)", function(Value)
    clickTpEnabled = false
    if _G.PH_ClickTpBtn then pcall(function() _G.PH_ClickTpBtn:Destroy() end) _G.PH_ClickTpBtn = nil end
    if not Value then return end

    local b = Instance.new("TextButton")
    b.Name = "ClickTpHud"
    b.Size = UDim2.new(0, 115, 0, 48)
    b.Position = UDim2.new(1, -135, 0.35, -58)
    b.BackgroundColor3 = Color3.fromRGB(205, 55, 45)
    b.TextColor3 = Color3.fromRGB(255, 255, 255)
    b.Font = Enum.Font.SourceSansBold
    b.TextSize = 16
    b.Text = "TP: OFF"
    b.Active = true
    b.Draggable = true
    b.ZIndex = 90
    b.Parent = ScreenGui
    Instance.new("UICorner", b).CornerRadius = UDim.new(0, 8)
    _G.PH_ClickTpBtn = b

    b.MouseButton1Click:Connect(function()
        if _G.ScriptPaused or _G.ScriptDestroyed then return end
        clickTpEnabled = not clickTpEnabled
        b.Text = clickTpEnabled and "TP: ON" or "TP: OFF"
        b.BackgroundColor3 = clickTpEnabled and Color3.fromRGB(45, 175, 55) or Color3.fromRGB(205, 55, 45)
    end)
end)

UIS.InputBegan:Connect(function(input, gameProcessed)
    if gameProcessed or not clickTpEnabled or _G.ScriptPaused or _G.ScriptDestroyed then return end
    if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
        local cam = workspace.CurrentCamera
        local unitRay = cam:ViewportPointToRay(input.Position.X, input.Position.Y)
        local rayParams = RaycastParams.new()
        local ignore = {Player.Character}
        if ghostVisualClone then table.insert(ignore, ghostVisualClone) end
        if ghostSimulationCube then table.insert(ignore, ghostSimulationCube) end
        rayParams.FilterDescendantsInstances = ignore
        rayParams.FilterType = Enum.RaycastFilterType.Exclude

        local result = workspace:Raycast(unitRay.Origin, unitRay.Direction * 1000, rayParams)
        if result then
            local targetPos = result.Position + Vector3.new(0, 3.2, 0)
            if phantomRunning and ghostSimulationCube then
                ghostSimulationCube.CFrame = CFrame.new(targetPos)
                if ghostVisualClone and ghostVisualClone.PrimaryPart then
                    ghostVisualClone:SetPrimaryPartCFrame(ghostSimulationCube.CFrame)
                end
            elseif Player.Character and Player.Character:FindFirstChild("HumanoidRootPart") then
                Player.Character.HumanoidRootPart.CFrame = CFrame.new(targetPos)
            end
        end
    end
end)

createToggle(mainPage, "🧱 Noclip (Прохождение сквозь стены)", function(Value)
    noclip = Value
    if not noclip and Player.Character then
        for _, part in pairs(Player.Character:GetDescendants()) do
            if part:IsA("BasePart") and part.Name ~= "HumanoidRootPart" then
                part.CanCollide = true
            end
        end
    end
end)

RunService.Stepped:Connect(function()
    if noclip and not _G.ScriptPaused and not _G.ScriptDestroyed and Player.Character then
        for _, part in pairs(Player.Character:GetDescendants()) do
            if part:IsA("BasePart") then
                part.CanCollide = false
            end
        end
    end
end)

createToggle(mainPage, "🦘 Бесконечный прыжок в воздухе", function(Value)
    infJumpEnabled = Value
end)

UIS.JumpRequest:Connect(function()
    if infJumpEnabled and not _G.ScriptPaused and not _G.ScriptDestroyed then
        if phantomRunning and ghostSimulationCube then
            ghostSimulationCube.CFrame = ghostSimulationCube.CFrame + Vector3.new(0, 8, 0)
        elseif Player.Character then
            local hum = Player.Character:FindFirstChildOfClass("Humanoid")
            if hum then hum:ChangeState(Enum.HumanoidStateType.Jumping) end
        end
    end
end)

-- АНТИ-ОТБРОС БУНКЕР (КОРОБКА-ТОРМОЗ ПРИ ПОЛУЧЕНИИ УРОНА)
local brakeBoxEnabled = false
local brakeBoxFolder = nil

local function destroyBrakeBox()
    if brakeBoxFolder then
        pcall(function() brakeBoxFolder:Destroy() end)
        brakeBoxFolder = nil
    end
end

createToggle(mainPage, "📦 Бункер-тормоз при ударе (Анти-отброс)", function(Value)
    brakeBoxEnabled = Value
    destroyBrakeBox()
    if not brakeBoxEnabled then return end

    local folder = Instance.new("Folder")
    folder.Name = "Prompt_BrakeBunker"
    folder.Parent = workspace
    brakeBoxFolder = folder

    local walls = {}
    local wallOffsets = {
        {name = "Front", pos = Vector3.new(0, 1.5, -5.5), size = Vector3.new(12, 11, 1.5)},
        {name = "Back",  pos = Vector3.new(0, 1.5,  5.5), size = Vector3.new(12, 11, 1.5)},
        {name = "Left",  pos = Vector3.new(-5.5, 1.5, 0), size = Vector3.new(1.5, 11, 12)},
        {name = "Right", pos = Vector3.new( 5.5, 1.5, 0), size = Vector3.new(1.5, 11, 12)},
        {name = "Floor", pos = Vector3.new(0, -4.3,   0), size = Vector3.new(12, 1.5, 12)}
    }

    for _, cfg in ipairs(wallOffsets) do
        local p = Instance.new("Part")
        p.Name = "Bunker_" .. cfg.name
        p.Size = cfg.size
        p.Anchored = true
        p.CanCollide = false
        p.Transparency = 1
        p.Parent = folder

        local sel = Instance.new("SelectionBox")
        sel.Name = "Edge"
        sel.Adornee = p
        sel.Color3 = Color3.fromRGB(70, 210, 255)
        sel.SurfaceTransparency = 1
        sel.LineThickness = 0.04
        sel.Parent = p

        table.insert(walls, {part = p, offset = cfg.pos, edge = sel})
    end

    task.spawn(function()
        local lastHealth = nil
        local lockedUntil = 0
        local lockedCenter = nil

        while brakeBoxEnabled and folder and folder.Parent and not _G.ScriptDestroyed do
            local char = Player.Character
            local hrp = char and char:FindFirstChild("HumanoidRootPart")
            local hum = char and char:FindFirstChildOfClass("Humanoid")

            if hrp and hum and hum.Health > 0 then
                if lastHealth and hum.Health < lastHealth - 0.5 then
                    lockedUntil = tick() + 1.0
                    lockedCenter = hrp.Position
                end
                lastHealth = hum.Health

                local isLocked = (tick() < lockedUntil)
                local centerPos = isLocked and lockedCenter or hrp.Position

                for _, item in ipairs(walls) do
                    item.part.Position = centerPos + item.offset
                    item.part.CanCollide = isLocked
                    item.edge.Color3 = isLocked and Color3.fromRGB(255, 75, 45) or Color3.fromRGB(70, 210, 255)
                    item.edge.LineThickness = isLocked and 0.08 or 0.04
                end
            else
                lastHealth = nil
            end
            RunService.RenderStepped:Wait()
        end

        destroyBrakeBox()
    end)
end)
-- ЛИЧНОЕ РАДИО / СВОЯ МУЗЫКА В ИГРЕ (🎧)
local customRadioSound = nil
local radioSoundId = "1848354536"
local radioVolume = 1.5

createInput(mainPage, "🎧 ID трека для Радио (Цифры из Roblox)", "Вставь ID звука...", function(Text)
    local cleanId = Text:gsub("%D", "")
    if cleanId ~= "" then
        radioSoundId = cleanId
        if customRadioSound then
            customRadioSound.SoundId = "rbxassetid://" .. radioSoundId
            customRadioSound:Play()
        end
    end
end)

createInput(mainPage, "🔊 Громкость Радио (от 0.1 до 5)", "Число (дефолт 1.5)...", function(Text)
    local vol = tonumber(Text)
    if vol and vol >= 0 and vol <= 10 then
        radioVolume = vol
        if customRadioSound then customRadioSound.Volume = radioVolume end
    end
end)

createToggle(mainPage, "📻 Включить личное Радио", function(Value)
    if customRadioSound then
        pcall(function() customRadioSound:Stop(); customRadioSound:Destroy() end)
        customRadioSound = nil
    end

    if Value then
        local snd = Instance.new("Sound")
        snd.Name = "PromptPersonalRadio"
        snd.SoundId = "rbxassetid://" .. radioSoundId
        snd.Volume = radioVolume
        snd.Looped = true
        snd.Parent = game:GetService("SoundService")
        snd:Play()
        customRadioSound = snd
    end
end)

-- ТУМБЛЕР: ВЫКЛЮЧИТЬ ВСЕ ЗВУКИ КРОМЕ ЛИЧНОГО РАДИО (🔇)
do
    local muteAll = false
    local originalVolumes = setmetatable({}, {__mode = "k"})
    local muteConns = {}

    local function isMyRadio(snd)
        return snd.Name == "PromptPersonalRadio" or snd == customRadioSound
    end

    local function muteSound(obj)
        if not obj:IsA("Sound") or isMyRadio(obj) then return end
        if originalVolumes[obj] == nil then originalVolumes[obj] = obj.Volume end
        pcall(function() obj.Volume = 0 end)
        -- если игра сама поднимет громкость, сразу возвращаем в 0
        table.insert(muteConns, obj:GetPropertyChangedSignal("Volume"):Connect(function()
            if muteAll and obj.Volume ~= 0 and not isMyRadio(obj) then
                pcall(function() obj.Volume = 0 end)
            end
        end))
    end

    createToggle(mainPage, "🔇 Выключить все звуки (кроме радио)", function(Value)
        muteAll = Value
        for _, c in ipairs(muteConns) do pcall(function() c:Disconnect() end) end
        muteConns = {}

        if muteAll then
            for _, d in ipairs(game:GetDescendants()) do muteSound(d) end
            table.insert(muteConns, game.DescendantAdded:Connect(function(d)
                if muteAll then muteSound(d) end
            end))
        else
            for snd, vol in pairs(originalVolumes) do
                if snd.Parent then pcall(function() snd.Volume = vol end) end
            end
            originalVolumes = setmetatable({}, {__mode = "k"})
        end
    end)
end

-- ПРОСТОЕ ОКОШКО КОМПАСА И КООРДИНАТ (🧭 XYZ + КУДА СМОТРЮ)
local compassEnabled = false
local compassBox = nil

createToggle(mainPage, "🧭 Окошко координат (XYZ + Направление)", function(Value)
    compassEnabled = Value
    if compassBox then
        pcall(function() compassBox:Destroy() end)
        compassBox = nil
    end

    if not compassEnabled then return end
    if ScreenGui then ScreenGui.DisplayOrder = 999 end

    local box = Instance.new("Frame")
    box.Name = "PromptSimpleCompass"
    box.Size = UDim2.new(0, 210, 0, 50)
    box.Position = UDim2.new(0.5, -105, 0.02, 0)
    box.BackgroundColor3 = Color3.fromRGB(22, 25, 30)
    box.BackgroundTransparency = 0.15
    box.Active = true
    box.Draggable = true
    box.ZIndex = 70
    box.Parent = ScreenGui
    Instance.new("UICorner", box).CornerRadius = UDim.new(0, 8)

    local stroke = Instance.new("UIStroke", box)
    stroke.Thickness = 1.8
    stroke.Color = Color3.fromRGB(80, 200, 255)

    local dirLabel = Instance.new("TextLabel", box)
    dirLabel.Size = UDim2.new(1, -10, 0, 22)
    dirLabel.Position = UDim2.new(0, 5, 0, 3)
    dirLabel.BackgroundTransparency = 1
    dirLabel.Text = "🧭 Смотрю: Север"
    dirLabel.TextColor3 = Color3.fromRGB(255, 220, 70)
    dirLabel.Font = Enum.Font.SourceSansBold
    dirLabel.TextSize = 14
    dirLabel.ZIndex = 71

    local xyzLabel = Instance.new("TextLabel", box)
    xyzLabel.Size = UDim2.new(1, -10, 0, 22)
    xyzLabel.Position = UDim2.new(0, 5, 0, 25)
    xyzLabel.BackgroundTransparency = 1
    xyzLabel.Text = "X: 0   Y: 0   Z: 0"
    xyzLabel.TextColor3 = Color3.fromRGB(130, 240, 255)
    xyzLabel.Font = Enum.Font.SourceSansBold
    xyzLabel.TextSize = 13
    xyzLabel.ZIndex = 71

    compassBox = box

    local dirNames = {
        "Север", "Северо-Восток", "Восток", "Юго-Восток",
        "Юг", "Юго-Запад", "Запад", "Северо-Запад"
    }

    task.spawn(function()
        while compassEnabled and box and box.Parent and not _G.ScriptDestroyed do
            local char = Player.Character
            local myRoot = (phantomRunning and ghostSimulationCube) or (char and char:FindFirstChild("HumanoidRootPart"))
            local cam = workspace.CurrentCamera

            if myRoot and cam then
                local pos = myRoot.Position
                local look = cam.CFrame.LookVector
                local deg = (math.deg(math.atan2(look.X, -look.Z)) + 360) % 360
                local idx = (math.floor((deg + 22.5) / 45) % 8) + 1

                dirLabel.Text = "🧭 Смотрю: " .. dirNames[idx]
                xyzLabel.Text = string.format("X: %d   Y: %d   Z: %d", math.floor(pos.X), math.floor(pos.Y), math.floor(pos.Z))
            end
            RunService.RenderStepped:Wait()
        end

        if box and box.Parent then box:Destroy() end
    end)
end)

-- СЕКУНДОМЕР / ТАЙМЕР НА ЭКРАНЕ (⏱ СТАРТ / ПАУЗА / СБРОС)
local stopwatchToggleEnabled = false
local stopwatchBox = nil

createToggle(mainPage, "⏱ Секундомер на экране (Старт / Сброс)", function(Value)
    stopwatchToggleEnabled = Value
    if stopwatchBox then
        pcall(function() stopwatchBox:Destroy() end)
        stopwatchBox = nil
    end

    if not stopwatchToggleEnabled then return end
    if ScreenGui then ScreenGui.DisplayOrder = 999 end

    local box = Instance.new("Frame")
    box.Name = "PromptStopwatchBox"
    box.Size = UDim2.new(0, 175, 0, 68)
    box.Position = UDim2.new(0.04, 0, 0.22, 0)
    box.BackgroundColor3 = Color3.fromRGB(22, 25, 32)
    box.BackgroundTransparency = 0.12
    box.Active = true
    box.Draggable = true
    box.ZIndex = 70
    box.Parent = ScreenGui
    Instance.new("UICorner", box).CornerRadius = UDim.new(0, 8)

    local stroke = Instance.new("UIStroke", box)
    stroke.Thickness = 1.8
    stroke.Color = Color3.fromRGB(255, 200, 60)

    local timeLbl = Instance.new("TextLabel", box)
    timeLbl.Size = UDim2.new(1, -10, 0, 28)
    timeLbl.Position = UDim2.new(0, 5, 0, 4)
    timeLbl.BackgroundTransparency = 1
    timeLbl.Text = "⏱ 00:00.0"
    timeLbl.TextColor3 = Color3.fromRGB(255, 255, 255)
    timeLbl.Font = Enum.Font.SourceSansBold
    timeLbl.TextSize = 18
    timeLbl.ZIndex = 71

    local startBtn = Instance.new("TextButton", box)
    startBtn.Size = UDim2.new(0.46, 0, 0, 26)
    startBtn.Position = UDim2.new(0.03, 0, 0, 36)
    startBtn.BackgroundColor3 = Color3.fromRGB(45, 175, 65)
    startBtn.Text = "▶ Старт"
    startBtn.TextColor3 = Color3.fromRGB(255, 255, 255)
    startBtn.Font = Enum.Font.SourceSansBold
    startBtn.TextSize = 13
    startBtn.ZIndex = 71
    Instance.new("UICorner", startBtn).CornerRadius = UDim.new(0, 5)

    local resetBtn = Instance.new("TextButton", box)
    resetBtn.Size = UDim2.new(0.46, 0, 0, 26)
    resetBtn.Position = UDim2.new(0.51, 0, 0, 36)
    resetBtn.BackgroundColor3 = Color3.fromRGB(195, 55, 55)
    resetBtn.Text = "🔄 Сброс"
    resetBtn.TextColor3 = Color3.fromRGB(255, 255, 255)
    resetBtn.Font = Enum.Font.SourceSansBold
    resetBtn.TextSize = 13
    resetBtn.ZIndex = 71
    Instance.new("UICorner", resetBtn).CornerRadius = UDim.new(0, 5)

    stopwatchBox = box

    local isRunning = false
    local elapsed = 0
    local lastTick = tick()

    startBtn.MouseButton1Click:Connect(function()
        isRunning = not isRunning
        if isRunning then
            lastTick = tick()
            startBtn.Text = "⏸ Пауза"
            startBtn.BackgroundColor3 = Color3.fromRGB(220, 165, 35)
        else
            startBtn.Text = "▶ Старт"
            startBtn.BackgroundColor3 = Color3.fromRGB(45, 175, 65)
        end
    end)

    resetBtn.MouseButton1Click:Connect(function()
        isRunning = false
        elapsed = 0
        timeLbl.Text = "⏱ 00:00.0"
        startBtn.Text = "▶ Старт"
        startBtn.BackgroundColor3 = Color3.fromRGB(45, 175, 65)
    end)

    task.spawn(function()
        while stopwatchToggleEnabled and box and box.Parent and not _G.ScriptDestroyed do
            if isRunning then
                local now = tick()
                elapsed = elapsed + (now - lastTick)
                lastTick = now

                local mins = math.floor(elapsed / 60)
                local secs = elapsed % 60
                timeLbl.Text = string.format("⏱ %02d:%04.1f", mins, secs)
            else
                lastTick = tick()
            end
            RunService.RenderStepped:Wait()
        end

        if box and box.Parent then box:Destroy() end
    end)
end)

-- =========================================================
-- ----- КОНЕЦ ЧАСТИ 5.2 -----
-- =========================================================
-- =========================================================
-- ----- НАЧАЛО ЧАСТИ 6.1 -----
-- =========================================================

local keysPressed = {w = false, a = false, s = false, d = false}
local flyVelocity = nil
local flyGyro = nil
local flyActiveState = false

local function destroyAllWasdFrames()
    pcall(function()
        for _, v in pairs(game:GetService("CoreGui"):GetDescendants()) do
            if v.Name == "WASD_FlyFrame" then v:Destroy() end
        end
    end)
    pcall(function()
        if Player and Player:FindFirstChild("PlayerGui") then
            for _, v in pairs(Player.PlayerGui:GetDescendants()) do
                if v.Name == "WASD_FlyFrame" then v:Destroy() end
            end
        end
    end)
    if ScreenGui then
        for _, v in pairs(ScreenGui:GetChildren()) do
            if v.Name == "WASD_FlyFrame" then v:Destroy() end
        end
    end
end

local function createFlyButton(parent, text, pos, size, key)
    local btn = Instance.new("TextButton")
    btn.Size = size
    btn.Position = pos
    btn.BackgroundColor3 = Color3.fromRGB(45, 45, 45)
    btn.Text = text
    btn.TextColor3 = Color3.fromRGB(255, 255, 255)
    btn.Font = Enum.Font.SourceSansBold
    btn.TextSize = 14
    btn.Active = true
    btn.Parent = parent
    Instance.new("UICorner", btn).CornerRadius = UDim.new(0, 4)
    
    btn.MouseButton1Down:Connect(function()
        keysPressed[key] = true
        btn.BackgroundColor3 = Color3.fromRGB(220, 180, 40)
        btn.TextColor3 = Color3.fromRGB(25, 25, 25)
    end)
    btn.MouseButton1Up:Connect(function()
        keysPressed[key] = false
        btn.BackgroundColor3 = Color3.fromRGB(45, 45, 45)
        btn.TextColor3 = Color3.fromRGB(255, 255, 255)
    end)
    btn.MouseLeave:Connect(function()
        keysPressed[key] = false
        btn.BackgroundColor3 = Color3.fromRGB(45, 45, 45)
        btn.TextColor3 = Color3.fromRGB(255, 255, 255)
    end)
end

local function stopFlyPhysics()
    flyActiveState = false
    keysPressed = {w = false, a = false, s = false, d = false}
    if flyVelocity then pcall(function() flyVelocity:Destroy() end) flyVelocity = nil end
    if flyGyro then pcall(function() flyGyro:Destroy() end) flyGyro = nil end

    local char = Player.Character
    if char then
        local hrp = char:FindFirstChild("HumanoidRootPart")
        local hum = char:FindFirstChildOfClass("Humanoid")

        if hrp then
            local look = hrp.CFrame.LookVector
            local flatLook = Vector3.new(look.X, 0, look.Z)
            if flatLook.Magnitude > 0.01 then
                hrp.CFrame = CFrame.new(hrp.Position + Vector3.new(0, 1.2, 0), hrp.Position + Vector3.new(0, 1.2, 0) + flatLook.Unit)
            else
                hrp.CFrame = CFrame.new(hrp.Position + Vector3.new(0, 1.2, 0))
            end
            hrp.AssemblyLinearVelocity = Vector3.new(0, 2, 0)
            hrp.AssemblyAngularVelocity = Vector3.new(0, 0, 0)
            for _, obj in pairs(hrp:GetChildren()) do
                if obj:IsA("BodyVelocity") or obj:IsA("BodyGyro") then obj:Destroy() end
            end
        end

        if hum then
            local animator = hum:FindFirstChildOfClass("Animator")
            if animator then
                for _, track in pairs(animator:GetPlayingAnimationTracks()) do track.Speed = 1 end
            end
            hum.PlatformStand = false
            hum.Sit = false
            hum.AutoRotate = true
            hum:ChangeState(Enum.HumanoidStateType.GettingUp)
            task.delay(0.05, function()
                if hum and hum.Parent and not flyActiveState then
                    hum.PlatformStand = false
                    hum.AutoRotate = true
                    hum:ChangeState(Enum.HumanoidStateType.Running)
                    hum:Move(Vector3.new(0, 0, 0))
                end
            end)
        end
    end
end

local function startFlyPhysics()
    if flyVelocity then pcall(function() flyVelocity:Destroy() end) flyVelocity = nil end
    if flyGyro then pcall(function() flyGyro:Destroy() end) flyGyro = nil end
    
    local char = Player.Character
    local hrp = char and char:FindFirstChild("HumanoidRootPart")
    local hum = char and char:FindFirstChildOfClass("Humanoid")
    if not hrp or not hum then return end
    
    flyActiveState = true
    flyVelocity = Instance.new("BodyVelocity")
    flyVelocity.MaxForce = Vector3.new(9e9, 9e9, 9e9)
    flyVelocity.P = 12500
    flyVelocity.Velocity = Vector3.new(0, 0, 0)
    flyVelocity.Parent = hrp
    
    flyGyro = Instance.new("BodyGyro")
    flyGyro.MaxTorque = Vector3.new(9e9, 9e9, 9e9)
    flyGyro.P = 15000
    flyGyro.CFrame = hrp.CFrame
    flyGyro.Parent = hrp
    
    task.spawn(function()
        local camera = workspace.CurrentCamera
        local lastFlyTick = tick()
        while flyActiveState and flying and char and hrp and hum and not _G.ScriptDestroyed do
            local dt = tick() - lastFlyTick
            lastFlyTick = tick()

            if not _G.ScriptPaused then
                hum.PlatformStand = true
                
                if noclip then
                    for _, part in pairs(char:GetDescendants()) do
                        if part:IsA("BasePart") then part.CanCollide = false end
                    end
                end
                
                local animator = hum:FindFirstChildOfClass("Animator")
                if animator then
                    for _, track in pairs(animator:GetPlayingAnimationTracks()) do 
                        local n = track.Animation.Name:lower()
                        if n:find("fall") or n:find("jump") or n:find("run") then
                            track.Speed = 0 
                        end
                    end
                end
                
                if flyGyro then flyGyro.CFrame = camera.CFrame end
                
                local flyVector = Vector3.new(0, 0, 0)
                local camLook = camera.CFrame.LookVector
                local camRight = camera.CFrame.RightVector
                local UIS = game:GetService("UserInputService")
                
                if keysPressed.w or UIS:IsKeyDown(Enum.KeyCode.W) then flyVector = flyVector + camLook end 
                if keysPressed.s or UIS:IsKeyDown(Enum.KeyCode.S) then flyVector = flyVector - camLook end 
                if keysPressed.a or UIS:IsKeyDown(Enum.KeyCode.A) then flyVector = flyVector - camRight end 
                if keysPressed.d or UIS:IsKeyDown(Enum.KeyCode.D) then flyVector = flyVector + camRight end
                
                -- Прямой сдвиг CFrame + обнуление скорости (пробивает кастомный контроллер в SCP-3008)
                hrp.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
                if flyVector.Magnitude > 0 then
                    local dir = flyVector.Unit
                    if flyVelocity then flyVelocity.Velocity = dir * flySpeedValue end
                    hrp.CFrame = CFrame.new(hrp.Position + dir * (flySpeedValue * dt)) * (camera.CFrame - camera.CFrame.Position)
                else
                    if flyVelocity then flyVelocity.Velocity = Vector3.new(0, 0, 0) end
                    hrp.CFrame = CFrame.new(hrp.Position) * (camera.CFrame - camera.CFrame.Position)
                end
            else
                if flyVelocity then flyVelocity.Velocity = Vector3.new(0, 0, 0) end
            end
            RunService.RenderStepped:Wait()
        end
    end)
end

-- =========================================================
-- ----- КОНЕЦ ЧАСТИ 6.1 -----
-- =========================================================
-- =========================================================
-- ----- НАЧАЛО ЧАСТИ 6.2 -----
-- =========================================================
do

local freecamEnabled = false

createToggle(movePage, "✈ Активировать WASD-Полет Кнопками", function(Value)
    flying = Value
    if flying and freecamEnabled then
        freecamEnabled = false
    end
    destroyAllWasdFrames()
    
    if flying then
        if ScreenGui then ScreenGui.DisplayOrder = 999 end
        
        local wasdFrame = Instance.new("Frame")
        wasdFrame.Name = "WASD_FlyFrame"
        wasdFrame.Size = UDim2.new(0, 156, 0, 158)
        wasdFrame.AnchorPoint = Vector2.new(0, 1)
        wasdFrame.Position = UDim2.new(0.04, 0, 0.92, 0)
        wasdFrame.BackgroundTransparency = 1
        wasdFrame.ZIndex = 50
        wasdFrame.Parent = ScreenGui
        
        createFlyButton(wasdFrame, "W", UDim2.new(0.5, -19, 0, 0), UDim2.new(0, 38, 0, 34), "w")
        createFlyButton(wasdFrame, "A", UDim2.new(0, 12, 0, 40), UDim2.new(0, 38, 0, 34), "a")
        createFlyButton(wasdFrame, "S", UDim2.new(0.5, -19, 0, 40), UDim2.new(0, 38, 0, 34), "s")
        createFlyButton(wasdFrame, "D", UDim2.new(1, -50, 0, 40), UDim2.new(0, 38, 0, 34), "d")
        
        local flySpeedBox = Instance.new("TextBox", wasdFrame)
        flySpeedBox.Name = "FlySpeedInput"
        flySpeedBox.Size = UDim2.new(1, -24, 0, 28)
        flySpeedBox.Position = UDim2.new(0, 12, 0, 82)
        flySpeedBox.BackgroundColor3 = Color3.fromRGB(35, 35, 35)
        flySpeedBox.Text = "Скорость: " .. flySpeedValue
        flySpeedBox.PlaceholderText = "Число..."
        flySpeedBox.TextColor3 = Color3.fromRGB(255, 220, 60)
        flySpeedBox.Font = Enum.Font.SourceSansBold
        flySpeedBox.TextSize = 13
        flySpeedBox.ClearTextOnFocus = true
        flySpeedBox.ZIndex = 55
        Instance.new("UICorner", flySpeedBox).CornerRadius = UDim.new(0, 5)
        
        flySpeedBox.FocusLost:Connect(function()
            local num = tonumber(flySpeedBox.Text)
            if num and num > 0 then flySpeedValue = num end
            flySpeedBox.Text = "Скорость: " .. flySpeedValue
        end)
        
        local quickFlyBtn = Instance.new("TextButton", wasdFrame)
        quickFlyBtn.Name = "QuickFlyToggle"
        quickFlyBtn.Size = UDim2.new(1, -24, 0, 32)
        quickFlyBtn.Position = UDim2.new(0, 12, 0, 116)
        quickFlyBtn.BackgroundColor3 = Color3.fromRGB(50, 180, 50)
        quickFlyBtn.Text = "Полет: ВКЛ"
        quickFlyBtn.TextColor3 = Color3.fromRGB(255, 255, 255)
        quickFlyBtn.Font = Enum.Font.SourceSansBold
        quickFlyBtn.TextSize = 13
        quickFlyBtn.Active = true
        quickFlyBtn.ZIndex = 55
        Instance.new("UICorner", quickFlyBtn).CornerRadius = UDim.new(0, 5)
        
        startFlyPhysics()
        
        local lastClickTime = 0
        local function onQuickBtnPress()
            if tick() - lastClickTime < 0.25 then return end
            lastClickTime = tick()
            if flyActiveState then stopFlyPhysics() else startFlyPhysics() end
        end
        
        quickFlyBtn.MouseButton1Down:Connect(onQuickBtnPress)
        quickFlyBtn.TouchTap:Connect(onQuickBtnPress)
        
        task.spawn(function()
            while wasdFrame and wasdFrame.Parent and not _G.ScriptDestroyed do
                if flyActiveState and not _G.ScriptPaused then
                    quickFlyBtn.Text = "Полет: ВКЛ"
                    quickFlyBtn.BackgroundColor3 = Color3.fromRGB(50, 180, 50)
                else
                    quickFlyBtn.Text = "Полет: ВЫКЛ"
                    quickFlyBtn.BackgroundColor3 = Color3.fromRGB(200, 50, 50)
                end
                task.wait(0.1)
            end
        end)
    else 
        stopFlyPhysics()
        destroyAllWasdFrames()
    end
end)

-- СВОБОДНАЯ КАМЕРА (FREECAM С ПОВОРОТОМ ПАЛЬЦЕМ / МЫШЬЮ И WASD)
createToggle(visualsPage, "🎥 Свободная камера (Freecam)", function(Value)
    freecamEnabled = Value
    if freecamEnabled and flying then
        flying = false
        stopFlyPhysics()
    end
    destroyAllWasdFrames()

    local cam = workspace.CurrentCamera
    local char = Player.Character
    local hrp = char and char:FindFirstChild("HumanoidRootPart")
    local hum = char and char:FindFirstChildOfClass("Humanoid")

    if freecamEnabled then
        if ScreenGui then ScreenGui.DisplayOrder = 999 end

        local wasdFrame = Instance.new("Frame")
        wasdFrame.Name = "WASD_FlyFrame"
        wasdFrame.Size = UDim2.new(0, 156, 0, 124)
        wasdFrame.AnchorPoint = Vector2.new(0, 1)
        wasdFrame.Position = UDim2.new(0.04, 0, 0.92, 0)
        wasdFrame.BackgroundTransparency = 1
        wasdFrame.ZIndex = 50
        wasdFrame.Parent = ScreenGui

        createFlyButton(wasdFrame, "W", UDim2.new(0.5, -19, 0, 0), UDim2.new(0, 38, 0, 34), "w")
        createFlyButton(wasdFrame, "A", UDim2.new(0, 12, 0, 40), UDim2.new(0, 38, 0, 34), "a")
        createFlyButton(wasdFrame, "S", UDim2.new(0.5, -19, 0, 40), UDim2.new(0, 38, 0, 34), "s")
        createFlyButton(wasdFrame, "D", UDim2.new(1, -50, 0, 40), UDim2.new(0, 38, 0, 34), "d")

        local camSpeedBox = Instance.new("TextBox", wasdFrame)
        camSpeedBox.Name = "FreecamSpeedInput"
        camSpeedBox.Size = UDim2.new(1, -24, 0, 28)
        camSpeedBox.Position = UDim2.new(0, 12, 0, 82)
        camSpeedBox.BackgroundColor3 = Color3.fromRGB(35, 35, 35)
        camSpeedBox.Text = "Скорость: " .. flySpeedValue
        camSpeedBox.PlaceholderText = "Число..."
        camSpeedBox.TextColor3 = Color3.fromRGB(100, 220, 255)
        camSpeedBox.Font = Enum.Font.SourceSansBold
        camSpeedBox.TextSize = 13
        camSpeedBox.ClearTextOnFocus = true
        camSpeedBox.ZIndex = 55
        Instance.new("UICorner", camSpeedBox).CornerRadius = UDim.new(0, 5)

        camSpeedBox.FocusLost:Connect(function()
            local num = tonumber(camSpeedBox.Text)
            if num and num > 0 then flySpeedValue = num end
            camSpeedBox.Text = "Скорость: " .. flySpeedValue
        end)

        local wasAnchored = hrp and hrp.Anchored or false
        if hrp and not phantomRunning then
            hrp.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
            hrp.Anchored = true
        end

        local camPos = cam.CFrame.Position
        local rx, ry, _ = cam.CFrame:ToEulerAnglesYXZ()
        local pitch = rx
        local yaw = ry
        cam.CameraType = Enum.CameraType.Scriptable

        local UIS = game:GetService("UserInputService")
        local lookConn = UIS.InputChanged:Connect(function(input, gp)
            if not freecamEnabled or gp then return end
            if input.UserInputType == Enum.UserInputType.Touch or input.UserInputType == Enum.UserInputType.MouseMovement then
                if input.Position.X < 200 and input.Position.Y > (cam.ViewportSize.Y - 200) then return end
                yaw = yaw - (input.Delta.X * 0.0045)
                pitch = math.clamp(pitch - (input.Delta.Y * 0.0045), -1.45, 1.45)
            end
        end)

        task.spawn(function()
            local lastT = tick()
            while freecamEnabled and not _G.ScriptDestroyed do
                local dt = tick() - lastT
                lastT = tick()

                local rot = CFrame.fromEulerAnglesYXZ(pitch, yaw, 0)
                if not _G.ScriptPaused then
                    local moveVec = Vector3.new(0, 0, 0)
                    if keysPressed.w or UIS:IsKeyDown(Enum.KeyCode.W) then moveVec = moveVec + rot.LookVector end
                    if keysPressed.s or UIS:IsKeyDown(Enum.KeyCode.S) then moveVec = moveVec - rot.LookVector end
                    if keysPressed.a or UIS:IsKeyDown(Enum.KeyCode.A) then moveVec = moveVec - rot.RightVector end
                    if keysPressed.d or UIS:IsKeyDown(Enum.KeyCode.D) then moveVec = moveVec + rot.RightVector end

                    if moveVec.Magnitude > 0 then
                        camPos = camPos + moveVec.Unit * (flySpeedValue * dt)
                    end
                end
                cam.CFrame = CFrame.new(camPos) * rot
                RunService.RenderStepped:Wait()
            end

            if lookConn then lookConn:Disconnect() end
            keysPressed = {w = false, a = false, s = false, d = false}
            destroyAllWasdFrames()
            cam.CameraType = Enum.CameraType.Custom
            if hrp and hrp.Parent and not phantomRunning and not airFreezeEnabled then
                hrp.Anchored = wasAnchored
            end
            if phantomRunning and ghostVisualClone then
                cam.CameraSubject = ghostVisualClone:FindFirstChild("Head") or ghostSimulationCube
            elseif hum and hum.Parent then
                cam.CameraSubject = hum
            end
        end)
    else
        keysPressed = {w = false, a = false, s = false, d = false}
        destroyAllWasdFrames()
        cam.CameraType = Enum.CameraType.Custom
        if hrp and hrp.Parent and not phantomRunning and not airFreezeEnabled then
            hrp.Anchored = false
        end
        if phantomRunning and ghostVisualClone then
            cam.CameraSubject = ghostVisualClone:FindFirstChild("Head") or ghostSimulationCube
        elseif hum and hum.Parent then
            cam.CameraSubject = hum
        end
    end
end)
-- 🏗️ РЕЖИМ СТРОЙКИ (BUILDER MODE)
local builderModeEnabled = false
local builderGui = nil
local topNotif = nil
local selectedType = nil
local blockSizeValue = 5

-- 🏗️ РЕЖИМ СТРОЙКИ (BUILDER MODE - 3D ROTATION)
local builderModeEnabled = false
local builderGui = nil
local topNotif = nil
local selectedType = nil
local blockSizeValue = 5

-- Переменные для 3D-поворота
local rotX = 0
local rotY = 0
local rotZ = 0

local placedBlocksList = {}
local wallCount = 0
local floorCount = 0
local currentlySelectedBlock = nil
local dragActive = false
local currentPreviewPart = nil

createToggle(movePage, "🏗️ Режим Стройки (Builder)", function(Value)
    builderModeEnabled = Value

    -- 🎵 МУЗЫКА РЕЖИМА СТРОЙКИ: впиши ID аудио ИЛИ прямую ссылку на .mp3 (если обе строки пустые - музыки нет)
    local BUILDER_MUSIC_ID = ""      -- например "rbxassetid://123456789" или просто 123456789
    local BUILDER_MUSIC_URL = ""     -- прямая ссылка на .mp3 (нужны writefile и getcustomasset в экзекьюторе)
    local BUILDER_MUSIC_VOLUME = 0.5

    local function stopBuilderMusic()
        if _G.PromptBuilderMusic then
            pcall(function() _G.PromptBuilderMusic:Destroy() end)
            _G.PromptBuilderMusic = nil
        end
    end

    local function startBuilderMusic()
        stopBuilderMusic()
        local id = tostring(BUILDER_MUSIC_ID)
        if id == "" and BUILDER_MUSIC_URL ~= "" then
            pcall(function()
                writefile("PromptBuilderMusic.mp3", game:HttpGet(BUILDER_MUSIC_URL))
                id = getcustomasset("PromptBuilderMusic.mp3")
            end)
        end
        if id == "" then return end
        if tonumber(id) then id = "rbxassetid://" .. id end
        local snd = Instance.new("Sound")
        snd.Name = "PromptBuilderMusic"
        snd.SoundId = id
        snd.Looped = true
        snd.Volume = BUILDER_MUSIC_VOLUME
        snd.Parent = game:GetService("SoundService")
        snd:Play()
        _G.PromptBuilderMusic = snd
    end
    
    if builderModeEnabled then
        startBuilderMusic()
        if not topNotif then
            topNotif = Instance.new("TextLabel")
            topNotif.Size = UDim2.new(0, 250, 0, 40)
            topNotif.Position = UDim2.new(0.5, -125, 0.05, 0)
            topNotif.BackgroundColor3 = Color3.fromRGB(25, 30, 35)
            topNotif.Text = "🏗️ РЕЖИМ СТРОЙКИ 👷"
            topNotif.TextColor3 = Color3.fromRGB(255, 220, 60)
            topNotif.Font = Enum.Font.SourceSansBold
            topNotif.TextSize = 16
            topNotif.Parent = ScreenGui
            topNotif.ZIndex = 80
            Instance.new("UICorner", topNotif).CornerRadius = UDim.new(0, 8)
        end
        topNotif.Visible = true
        
        if not builderGui then
            builderGui = Instance.new("Frame")
            builderGui.Size = UDim2.new(0, 150, 0, 300) -- Компактная панель
            builderGui.Position = UDim2.new(0, 10, 0.5, -150)
            builderGui.BackgroundColor3 = Color3.fromRGB(25, 25, 25)
            builderGui.Parent = ScreenGui
            builderGui.ZIndex = 75
            builderGui.ClipsDescendants = true
            Instance.new("UICorner", builderGui).CornerRadius = UDim.new(0, 10)
            
            local stroke = Instance.new("UIStroke", builderGui)
            stroke.Color = Color3.fromRGB(255, 220, 60)
            stroke.Thickness = 2
            
            local title = Instance.new("TextLabel", builderGui)
            title.Size = UDim2.new(1, -34, 0, 24)
            title.Position = UDim2.new(0, 6, 0, 0)
            title.BackgroundTransparency = 1
            title.Text = "🛠️ Инструменты"
            title.TextColor3 = Color3.fromRGB(255, 255, 255)
            title.Font = Enum.Font.SourceSansBold
            title.TextSize = 13
            title.TextXAlignment = Enum.TextXAlignment.Left
            title.ZIndex = 76
            
            -- Тело панели (можно свернуть кнопкой справа сверху)
            local body = Instance.new("Frame", builderGui)
            body.Size = UDim2.new(1, 0, 1, -24)
            body.Position = UDim2.new(0, 0, 0, 24)
            body.BackgroundTransparency = 1
            body.ZIndex = 76
            
            local collapseBtn = Instance.new("TextButton", builderGui)
            collapseBtn.Size = UDim2.new(0, 22, 0, 18)
            collapseBtn.Position = UDim2.new(1, -28, 0, 3)
            collapseBtn.BackgroundColor3 = Color3.fromRGB(50, 50, 50)
            collapseBtn.Text = "▲"
            collapseBtn.TextColor3 = Color3.fromRGB(255, 255, 255)
            collapseBtn.Font = Enum.Font.SourceSansBold
            collapseBtn.TextSize = 11
            collapseBtn.ZIndex = 77
            Instance.new("UICorner", collapseBtn).CornerRadius = UDim.new(0, 5)
            collapseBtn.MouseButton1Click:Connect(function()
                local open = not body.Visible
                body.Visible = open
                builderGui.Size = open and UDim2.new(0, 150, 0, 300) or UDim2.new(0, 150, 0, 24)
                collapseBtn.Text = open and "▲" or "▼"
            end)
            
            local function mkBtn(x, y, w, h, text, color, textSize)
                local b = Instance.new("TextButton", body)
                b.Size = UDim2.new(0, w, 0, h)
                b.Position = UDim2.new(0, x, 0, y)
                b.BackgroundColor3 = color
                b.Text = text
                b.TextColor3 = Color3.fromRGB(255, 255, 255)
                b.Font = Enum.Font.SourceSansBold
                b.TextSize = textSize or 12
                b.ZIndex = 76
                Instance.new("UICorner", b).CornerRadius = UDim.new(0, 5)
                return b
            end
            
            local sizeBox = Instance.new("TextBox", body)
            sizeBox.Size = UDim2.new(0, 138, 0, 24)
            sizeBox.Position = UDim2.new(0, 6, 0, 2)
            sizeBox.BackgroundColor3 = Color3.fromRGB(40, 40, 40)
            sizeBox.Text = "Размер: " .. blockSizeValue
            sizeBox.TextColor3 = Color3.fromRGB(255, 255, 255)
            sizeBox.TextSize = 13
            sizeBox.ZIndex = 76
            Instance.new("UICorner", sizeBox).CornerRadius = UDim.new(0, 5)
            
            sizeBox.FocusLost:Connect(function()
                local num = tonumber(sizeBox.Text:match("%d+"))
                if num then blockSizeValue = num end
                sizeBox.Text = "Размер: " .. blockSizeValue
            end)
            
            -- Выбор типа
            local wallBtn = mkBtn(6, 30, 67, 24, "Стенка", Color3.fromRGB(50, 50, 50), 13)
            local floorBtn = mkBtn(77, 30, 67, 24, "Пол", Color3.fromRGB(50, 50, 50), 13)

            -- КНОПКИ ВРАЩЕНИЯ (3 ОСИ): красные = наклон (X), зелёные = поворот (Y), синие = крен (Z)
            local pitchU = mkBtn(6, 58, 44, 22, "↑ X", Color3.fromRGB(150, 50, 50))
            local yawL = mkBtn(53, 58, 44, 22, "↺ Y", Color3.fromRGB(50, 150, 50))
            local rollL = mkBtn(100, 58, 44, 22, "↶ Z", Color3.fromRGB(50, 50, 150))
            local pitchD = mkBtn(6, 82, 44, 22, "↓ X", Color3.fromRGB(150, 50, 50))
            local yawR = mkBtn(53, 82, 44, 22, "↻ Y", Color3.fromRGB(50, 150, 50))
            local rollR = mkBtn(100, 82, 44, 22, "↷ Z", Color3.fromRGB(50, 50, 150))
            pitchU.Visible = false
            pitchD.Visible = false
            yawL.Visible = false
            yawR.Visible = false
            rollL.Visible = false
            rollR.Visible = false

            -- Кнопки подтверждения и отмены
            local confirmBtn = mkBtn(6, 108, 67, 24, "✅", Color3.fromRGB(50, 180, 50), 16)
            confirmBtn.Visible = false
            local cancelBtn = mkBtn(77, 108, 67, 24, "❌", Color3.fromRGB(200, 50, 50), 16)
            cancelBtn.Visible = false

            local deleteBtn = mkBtn(6, 136, 138, 22, "🗑️ Удалить выбранное", Color3.fromRGB(200, 50, 50), 11)
            deleteBtn.Visible = false

            local listLabel = Instance.new("TextLabel", body)
            listLabel.Size = UDim2.new(0, 138, 0, 16)
            listLabel.Position = UDim2.new(0, 6, 0, 162)
            listLabel.BackgroundTransparency = 1
            listLabel.Text = "📦 Поставленные блоки:"
            listLabel.TextColor3 = Color3.fromRGB(200, 200, 200)
            listLabel.Font = Enum.Font.SourceSansBold
            listLabel.TextSize = 11
            listLabel.TextXAlignment = Enum.TextXAlignment.Left
            listLabel.ZIndex = 76

            -- Список со скроллом (высота растёт сама, листается пальцем)
            local listScroll = Instance.new("ScrollingFrame", body)
            listScroll.Size = UDim2.new(0, 138, 0, 94)
            listScroll.Position = UDim2.new(0, 6, 0, 178)
            listScroll.BackgroundColor3 = Color3.fromRGB(15, 15, 15)
            listScroll.BorderSizePixel = 0
            listScroll.ScrollBarThickness = 4
            listScroll.ScrollingDirection = Enum.ScrollingDirection.Y
            listScroll.CanvasSize = UDim2.new(0, 0, 0, 0)
            listScroll.AutomaticCanvasSize = Enum.AutomaticSize.Y
            listScroll.ZIndex = 76
            Instance.new("UICorner", listScroll).CornerRadius = UDim.new(0, 5)
            
            local listLayout = Instance.new("UIListLayout", listScroll)
            listLayout.Padding = UDim.new(0, 3)
            listLayout.SortOrder = Enum.SortOrder.LayoutOrder

            -- МАГНИТ: прилипание призрака к уже поставленным блокам (чтобы коробка была без швов)
            local snapDistance = 2
            local function halfExtent(cf, size, dir)
                return math.abs(cf.RightVector:Dot(dir)) * size.X / 2
                    + math.abs(cf.UpVector:Dot(dir)) * size.Y / 2
                    + math.abs(cf.LookVector:Dot(dir)) * size.Z / 2
            end

            local function snapToBlocks(pos, rot, size)
                local nearList = {}
                for _, data in ipairs(placedBlocksList) do
                    local part = data.Part
                    if part and part.Parent then
                        local dist = (part.Position - pos).Magnitude
                        if dist < (part.Size.Magnitude + size.Magnitude) / 2 + snapDistance * 2 then
                            table.insert(nearList, {part = part, dist = dist})
                        end
                    end
                end
                table.sort(nearList, function(a, b) return a.dist < b.dist end)

                for k = 1, math.min(#nearList, 4) do
                    local part = nearList[k].part
                    local cfB = part.CFrame
                    local axes = {cfB.RightVector, cfB.UpVector, cfB.LookVector}
                    local sB = {part.Size.X / 2, part.Size.Y / 2, part.Size.Z / 2}
                    local d = cfB:PointToObjectSpace(pos)
                    local dv = {d.X, d.Y, d.Z}
                    local hP = {}
                    local isNear = true
                    local contact, worstGap = 1, -math.huge
                    for i = 1, 3 do
                        hP[i] = halfExtent(rot, size, axes[i])
                        local gap = math.abs(dv[i]) - (sB[i] + hP[i])
                        if gap > snapDistance then isNear = false end
                        if gap > worstGap then worstGap = gap; contact = i end
                    end

                    if isNear then
                        for i = 1, 3 do
                            local cands
                            if i == contact then
                                -- ось касания: вплотную к грани соседнего блока
                                cands = {sB[i] + hP[i], -(sB[i] + hP[i])}
                            else
                                -- остальные оси: выровнять края/центр с соседним блоком
                                local a, b = sB[i] + hP[i], sB[i] - hP[i]
                                cands = {0, a, -a, b, -b}
                            end
                            local bestV, bestD = dv[i], snapDistance
                            for _, c in ipairs(cands) do
                                local dd = math.abs(dv[i] - c)
                                if dd < bestD then bestD = dd; bestV = c end
                            end
                            dv[i] = bestV
                        end
                        pos = cfB:PointToWorldSpace(Vector3.new(dv[1], dv[2], dv[3]))
                    end
                end
                return pos
            end

            -- Функция обновления позиции с учетом 3D-углов (+ магнит)
            local function updatePreviewPos(targetPos)
                if currentPreviewPart then
                    local rot = CFrame.Angles(math.rad(rotX), math.rad(rotY), math.rad(rotZ))
                    targetPos = snapToBlocks(targetPos, rot, currentPreviewPart.Size)
                    currentPreviewPart.CFrame = CFrame.new(targetPos) * rot
                end
            end

            local function refreshList()
                for _, child in ipairs(listScroll:GetChildren()) do
                    if child:IsA("TextButton") then child:Destroy() end
                end
                
                for i, data in ipairs(placedBlocksList) do
                    local itemBtn = Instance.new("TextButton", listScroll)
                    itemBtn.Size = UDim2.new(1, -5, 0, 22)
                    itemBtn.LayoutOrder = i
                    itemBtn.BackgroundColor3 = Color3.fromRGB(40, 40, 40)
                    itemBtn.Text = data.Name
                    itemBtn.TextColor3 = Color3.fromRGB(255, 255, 255)
                    itemBtn.Font = Enum.Font.SourceSans
                    itemBtn.TextSize = 11
                    itemBtn.ZIndex = 77
                    Instance.new("UICorner", itemBtn).CornerRadius = UDim.new(0, 4)
                    
                    itemBtn.MouseButton1Click:Connect(function()
                        if currentlySelectedBlock and currentlySelectedBlock.Highlight then
                            currentlySelectedBlock.Highlight:Destroy()
                        end
                        currentlySelectedBlock = data
                        
                        local hl = Instance.new("SelectionBox")
                        hl.Name = "Highlight"
                        hl.Adornee = data.Part
                        hl.Color3 = Color3.fromRGB(50, 255, 50)
                        hl.LineThickness = 0.1
                        hl.Parent = data.Part
                        data.Highlight = hl
                        
                        deleteBtn.Visible = true
                    end)
                end
            end

            deleteBtn.MouseButton1Click:Connect(function()
                if currentlySelectedBlock then
                    currentlySelectedBlock.Part:Destroy()
                    for i, data in ipairs(placedBlocksList) do
                        if data == currentlySelectedBlock then
                            table.remove(placedBlocksList, i)
                            break
                        end
                    end
                    currentlySelectedBlock = nil
                    deleteBtn.Visible = false
                    refreshList()
                end
            end)

            local function resetSelection()
                selectedType = nil
                wallBtn.BackgroundColor3 = Color3.fromRGB(50, 50, 50)
                floorBtn.BackgroundColor3 = Color3.fromRGB(50, 50, 50)
                pitchU.Visible = false
                pitchD.Visible = false
                yawL.Visible = false
                yawR.Visible = false
                rollL.Visible = false
                rollR.Visible = false
                confirmBtn.Visible = false
                cancelBtn.Visible = false
                rotX, rotY, rotZ = 0, 0, 0
                if currentPreviewPart then
                    currentPreviewPart:Destroy()
                    currentPreviewPart = nil
                end
            end

            local function selectType(t)
                selectedType = t
                wallBtn.BackgroundColor3 = (t == "wall") and Color3.fromRGB(50, 180, 50) or Color3.fromRGB(50, 50, 50)
                floorBtn.BackgroundColor3 = (t == "floor") and Color3.fromRGB(50, 180, 50) or Color3.fromRGB(50, 50, 50)
                pitchU.Visible = true
                pitchD.Visible = true
                yawL.Visible = true
                yawR.Visible = true
                rollL.Visible = true
                rollR.Visible = true
                confirmBtn.Visible = true
                cancelBtn.Visible = true
                
                if currentPreviewPart then currentPreviewPart:Destroy() end
                
                local p = Instance.new("Part")
                p.Anchored = true
                p.CanCollide = false
                p.Material = Enum.Material.ForceField
                p.Color = Color3.fromRGB(255, 40, 40)
                p.Transparency = 0.35
                
                if selectedType == "wall" then
                    p.Size = Vector3.new(blockSizeValue, blockSizeValue * 2, 1)
                else
                    p.Size = Vector3.new(blockSizeValue, 1, blockSizeValue)
                end
                
                local char = Player.Character
                local hrp = char and char:FindFirstChild("HumanoidRootPart")
                if hrp then
                    p.Position = hrp.Position + hrp.CFrame.LookVector * 10
                end
                
                p.Parent = workspace
                currentPreviewPart = p
                rotX, rotY, rotZ = 0, 0, 0
            end
            
            wallBtn.MouseButton1Click:Connect(function() selectType("wall") end)
            floorBtn.MouseButton1Click:Connect(function() selectType("floor") end)
            
            -- Обработчики 3D-вращения
            pitchU.MouseButton1Click:Connect(function() rotX = rotX + 15; updatePreviewPos(currentPreviewPart.Position) end)
            pitchD.MouseButton1Click:Connect(function() rotX = rotX - 15; updatePreviewPos(currentPreviewPart.Position) end)
            yawL.MouseButton1Click:Connect(function() rotY = rotY + 15; updatePreviewPos(currentPreviewPart.Position) end)
            yawR.MouseButton1Click:Connect(function() rotY = rotY - 15; updatePreviewPos(currentPreviewPart.Position) end)
            rollL.MouseButton1Click:Connect(function() rotZ = rotZ + 15; updatePreviewPos(currentPreviewPart.Position) end)
            rollR.MouseButton1Click:Connect(function() rotZ = rotZ - 15; updatePreviewPos(currentPreviewPart.Position) end)

            confirmBtn.MouseButton1Click:Connect(function()
                if not currentPreviewPart then return end
                
                local placedBlock = Instance.new("Part")
                placedBlock.Anchored = true
                placedBlock.CanCollide = true
                placedBlock.Material = Enum.Material.SmoothPlastic
                placedBlock.Color = Color3.fromRGB(150, 150, 150)
                placedBlock.Size = currentPreviewPart.Size
                placedBlock.CFrame = currentPreviewPart.CFrame
                placedBlock.Parent = workspace
                
                local bName = ""
                if selectedType == "wall" then
                    wallCount = wallCount + 1
                    bName = "Стена " .. wallCount
                else
                    floorCount = floorCount + 1
                    bName = "Пол " .. floorCount
                end

                table.insert(placedBlocksList, {Part = placedBlock, Name = bName})
                refreshList()
                resetSelection()
            end)
            
            cancelBtn.MouseButton1Click:Connect(function() resetSelection() end)

            -- Логика перетаскивания пальцем
            local UIS = game:GetService("UserInputService")
            local lastMousePos = nil
            
            UIS.InputBegan:Connect(function(input, gameProcessed)
                if gameProcessed or not builderModeEnabled or not selectedType then return end
                if input.UserInputType == Enum.UserInputType.Touch or input.UserInputType == Enum.UserInputType.MouseButton1 then
                    dragActive = true
                    lastMousePos = Vector2.new(input.Position.X, input.Position.Y)
                end
            end)

            UIS.InputChanged:Connect(function(input, gameProcessed)
                if not dragActive or not builderModeEnabled or not currentPreviewPart then return end
                if input.UserInputType == Enum.UserInputType.Touch or input.UserInputType == Enum.UserInputType.MouseMovement then
                    local cam = workspace.CurrentCamera
                    local unitRay = cam:ViewportPointToRay(input.Position.X, input.Position.Y)
                    local rayParams = RaycastParams.new()
                    rayParams.FilterType = Enum.RaycastFilterType.Exclude
                    rayParams.FilterDescendantsInstances = {currentPreviewPart, Player.Character, builderGui}
                    
                    local result = workspace:Raycast(unitRay.Origin, unitRay.Direction * 1000, rayParams)
                    if result then
                        -- Ставим призрака вплотную к поверхности, на которую указал палец
                        local rot = CFrame.Angles(math.rad(rotX), math.rad(rotY), math.rad(rotZ))
                        local n = result.Normal
                        local targetPos = result.Position + n * halfExtent(rot, currentPreviewPart.Size, n)
                        updatePreviewPos(targetPos)
                    end
                end
            end)

            UIS.InputEnded:Connect(function(input, gameProcessed)
                if not dragActive or not builderModeEnabled then return end
                if input.UserInputType == Enum.UserInputType.Touch or input.UserInputType == Enum.UserInputType.MouseButton1 then
                    dragActive = false
                end
            end)
        end
        builderGui.Visible = true
    else
        stopBuilderMusic()
        if builderGui then builderGui.Visible = false end
        if topNotif then topNotif.Visible = false end
        if currentPreviewPart then currentPreviewPart:Destroy() currentPreviewPart = nil end
    end
end)

-- 3. ПЛАТФОРМА ПОД НОГАМИ (ПОСТОЯННАЯ ХОДЬБА ПО ВОЗДУХУ + РАЗОВОЕ СОЗДАНИЕ)
local underFeetWalkEnabled = false
local underFeetPlatform = nil
local staticFeetPlatforms = {}

createToggle(movePage, "☁️ Ходьба по воздуху (Платформа под ногами)", function(Value)
    underFeetWalkEnabled = Value
    if underFeetPlatform then
        pcall(function() underFeetPlatform:Destroy() end)
        underFeetPlatform = nil
    end

    if underFeetWalkEnabled then
        underFeetPlatform = Instance.new("Part")
        underFeetPlatform.Name = "Prompt_AirWalkPlatform"
        underFeetPlatform.Size = Vector3.new(24, 1.5, 24)
        underFeetPlatform.Anchored = true
        underFeetPlatform.CanCollide = true
        underFeetPlatform.Transparency = 1
        underFeetPlatform.Parent = workspace

        local edge = Instance.new("SelectionBox")
        edge.Adornee = underFeetPlatform
        edge.Color3 = Color3.fromRGB(90, 200, 255)
        edge.SurfaceTransparency = 1
        edge.LineThickness = 0.06
        edge.Parent = underFeetPlatform

        task.spawn(function()
            while underFeetWalkEnabled and underFeetPlatform and underFeetPlatform.Parent and not _G.ScriptDestroyed do
                if not _G.ScriptPaused then
                    local char = Player.Character
                    local hrp = char and char:FindFirstChild("HumanoidRootPart")
                    local hum = char and char:FindFirstChildOfClass("Humanoid")
                    local currentRoot = (phantomRunning and ghostSimulationCube) or hrp

                    if currentRoot then
                        local footOffset = 3.75
                        if hum and hum.RigType == Enum.HumanoidRigType.R15 then
                            footOffset = hum.HipHeight + (currentRoot.Size.Y * 0.5) + 0.75
                        end
                        underFeetPlatform.Position = Vector3.new(
                            currentRoot.Position.X,
                            currentRoot.Position.Y - footOffset,
                            currentRoot.Position.Z
                        )
                    end
                end
                RunService.RenderStepped:Wait()
            end

            if underFeetPlatform then
                pcall(function() underFeetPlatform:Destroy() end)
                underFeetPlatform = nil
            end
        end)
    end
end)

createButton(movePage, "🧱 Поставить платформу под ногами сейчас", function()
    local char = Player.Character
    local hrp = char and char:FindFirstChild("HumanoidRootPart")
    local hum = char and char:FindFirstChildOfClass("Humanoid")
    local currentRoot = (phantomRunning and ghostSimulationCube) or hrp
    if not currentRoot then return end

    local footOffset = 3.75
    if hum and hum.RigType == Enum.HumanoidRigType.R15 then
        footOffset = hum.HipHeight + (currentRoot.Size.Y * 0.5) + 0.75
    end

    local plat = Instance.new("Part")
    plat.Name = "Prompt_StaticFootPlatform"
    plat.Size = Vector3.new(30, 1.5, 30)
    plat.Position = Vector3.new(currentRoot.Position.X, currentRoot.Position.Y - footOffset, currentRoot.Position.Z)
    plat.Anchored = true
    plat.CanCollide = true
    plat.Transparency = 1
    plat.Parent = workspace

    local edge = Instance.new("SelectionBox")
    edge.Adornee = plat
    edge.Color3 = Color3.fromRGB(255, 210, 60)
    edge.SurfaceTransparency = 1
    edge.LineThickness = 0.06
    edge.Parent = plat

    table.insert(staticFeetPlatforms, plat)
end)

createButton(movePage, "🧹 Удалить все поставленные платформы", function()
    for _, p in ipairs(staticFeetPlatforms) do
        if p and p.Parent then pcall(function() p:Destroy() end) end
    end
    staticFeetPlatforms = {}
end)

-- 4. ВЕЧНЫЙ ДЕНЬ И УДАЛЕНИЕ ТУМАНА
createToggle(visualsPage, "☀️ Включить Вечный День (Full Bright)", function(Value)
    fullBrightEnabled = Value
    if fullBrightEnabled then
        task.spawn(function()
            while fullBrightEnabled and not _G.ScriptDestroyed do
                Lighting.Brightness = 2
                Lighting.ClockTime = 14
                Lighting.GlobalShadows = false
                Lighting.Ambient = Color3.fromRGB(255, 255, 255)
                Lighting.OutdoorAmbient = Color3.fromRGB(255, 255, 255)
                task.wait(0.3)
            end
        end)
    else
        Lighting.Brightness = defaultBrightness
        Lighting.ClockTime = defaultClockTime
        Lighting.GlobalShadows = defaultGlobalShadows
        Lighting.Ambient = defaultAmbient
        Lighting.OutdoorAmbient = defaultOutdoorAmbient
    end
end)

createToggle(visualsPage, "🌫️ Полностью удалить туман (Remove Fog)", function(Value)
    removeFogEnabled = Value
    if removeFogEnabled then
        task.spawn(function()
            while removeFogEnabled and not _G.ScriptDestroyed do
                Lighting.FogStart = 9e9
                Lighting.FogEnd = 9e9
                for _, v in pairs(Lighting:GetDescendants()) do if v:IsA("Atmosphere") or v:IsA("Sky") then v:Destroy() end end
                task.wait(0.3)
            end
        end)
    else
        Lighting.FogStart = defaultFogStart
        Lighting.FogEnd = defaultFogEnd
        if defaultAtmosphere and not Lighting:FindFirstChildOfClass("Atmosphere") then defaultAtmosphere:Clone().Parent = Lighting end
        if defaultSky and not Lighting:FindFirstChildOfClass("Sky") then defaultSky:Clone().Parent = Lighting end
    end
end)

end
-- =========================================================
-- ----- КОНЕЦ ЧАСТИ 6.2 -----
-- =========================================================
-- =========================================================
-- ----- НАЧАЛО ЧАСТИ 7.1 -----
-- =========================================================
do

local targetPlayerInput = ""
local followBehindEnabled = false
local spectatingPlayer = nil

local function findExactOrPrefixPlayer(query)
    if not query or query == "" then return nil end
    local q = query:lower():gsub("^%s*(.-)%s*$", "%1")
    if q == "" then return nil end

    -- Сначала ищем точное совпадение по нику или DisplayName
    for _, plr in ipairs(Players:GetPlayers()) do
        if plr ~= Player then
            if plr.Name:lower() == q or plr.DisplayName:lower() == q then
                return plr
            end
        end
    end

    -- Затем ищем по началу ника или DisplayName
    for _, plr in ipairs(Players:GetPlayers()) do
        if plr ~= Player then
            if plr.Name:lower():sub(1, #q) == q or plr.DisplayName:lower():sub(1, #q) == q then
                return plr
            end
        end
    end
    return nil
end

local _, targetStatusLabel = createParagraph(playersPage, "🎯 Выбранная цель", "Никто не выбран (введите ник ниже)")

createInput(playersPage, "Ник игрока (первые буквы или полный)", "Введите ник...", function(Text)
    targetPlayerInput = Text
    local found = findExactOrPrefixPlayer(targetPlayerInput)
    if found then
        targetStatusLabel.Text = "Цель найдена: " .. found.DisplayName .. " (@" .. found.Name .. ")"
    else
        targetStatusLabel.Text = (Text == "") and "Никто не выбран" or ("Игрок '" .. Text .. "' не найден")
    end
end)

createButton(playersPage, "🌀 Телепортироваться к игроку", function()
    local target = findExactOrPrefixPlayer(targetPlayerInput)
    if target and target.Character and target.Character:FindFirstChild("HumanoidRootPart") then
        local targetHrp = target.Character.HumanoidRootPart
        local destCFrame = targetHrp.CFrame * CFrame.new(0, 0, 3)

        if phantomRunning and ghostSimulationCube then
            ghostSimulationCube.CFrame = destCFrame
        else
            local char = Player.Character
            if char and char:FindFirstChild("HumanoidRootPart") then
                char.HumanoidRootPart.CFrame = destCFrame
            end
        end
    end
end)

createToggle(playersPage, "👁 Наблюдать за игроком (Spectate)", function(Value)
    if Value then
        local target = findExactOrPrefixPlayer(targetPlayerInput)
        if target and target.Character and target.Character:FindFirstChildOfClass("Humanoid") then
            spectatingPlayer = target
            workspace.CurrentCamera.CameraSubject = target.Character:FindFirstChildOfClass("Humanoid")
        end
    else
        spectatingPlayer = nil
        if phantomRunning and ghostVisualClone then
            local camTarget = ghostVisualClone:FindFirstChild("Head") or ghostVisualClone.PrimaryPart or ghostSimulationCube
            workspace.CurrentCamera.CameraSubject = camTarget
        elseif Player.Character and Player.Character:FindFirstChildOfClass("Humanoid") then
            workspace.CurrentCamera.CameraSubject = Player.Character:FindFirstChildOfClass("Humanoid")
        end
    end
end)

createToggle(playersPage, "🧲 Быть сзади выбранного игрока", function(Value)
    followBehindEnabled = Value
    if followBehindEnabled then
        local lockedTarget = findExactOrPrefixPlayer(targetPlayerInput)
        if not lockedTarget then
            followBehindEnabled = false
            return
        end

        task.spawn(function()
            while followBehindEnabled and not _G.ScriptDestroyed do
                if not _G.ScriptPaused then
                    -- Если в поле ввели новый ник, обновляем цель; иначе держимся строго за выбранным игроком
                    local currentQueryTarget = findExactOrPrefixPlayer(targetPlayerInput)
                    if currentQueryTarget then
                        lockedTarget = currentQueryTarget
                    end

                    if not lockedTarget or not lockedTarget.Parent then
                        followBehindEnabled = false
                        break
                    end

                    local tChar = lockedTarget.Character
                    local tHrp = tChar and tChar:FindFirstChild("HumanoidRootPart")
                    if tHrp then
                        local behindCFrame = tHrp.CFrame * CFrame.new(0, 0, 3.2)
                        if phantomRunning and ghostSimulationCube then
                            ghostSimulationCube.CFrame = behindCFrame
                        else
                            local myChar = Player.Character
                            local myHrp = myChar and myChar:FindFirstChild("HumanoidRootPart")
                            if myHrp then
                                myHrp.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
                                myHrp.CFrame = behindCFrame
                            end
                        end
                    end
                end
                RunService.RenderStepped:Wait()
            end
        end)
    end
end)

end
-- =========================================================
-- ----- КОНЕЦ ЧАСТИ 7.1 -----
-- =========================================================
-- =========================================================
-- ----- НАЧАЛО ЧАСТИ 7.2 -----
-- =========================================================
do

local espEnabled = false
local hitboxEnabled = false
local hitboxSizeValue = 15
local killAuraEnabled = false
local camLockMiniEnabled = false
local shiftLockMiniEnabled = false

local function clearAllEsp()
    for _, plr in ipairs(Players:GetPlayers()) do
        if plr.Character then
            local hl = plr.Character:FindFirstChild("PromptPlayerHighlight")
            if hl then pcall(function() hl:Destroy() end) end
            local head = plr.Character:FindFirstChild("Head")
            if head then
                local bbg = head:FindFirstChild("PromptPlayerDotESP")
                if bbg then pcall(function() bbg:Destroy() end) end
            end
        end
    end
end

createToggle(visualsPage, "👁 Дальний ESP игроков (Ник + Точка •)", function(Value)
    espEnabled = Value
    clearAllEsp()

    if not espEnabled then return end

    task.spawn(function()
        while espEnabled and not _G.ScriptDestroyed do
            local myChar = Player.Character
            local myRoot = (phantomRunning and ghostSimulationCube) or (myChar and myChar:FindFirstChild("HumanoidRootPart"))

            for _, plr in ipairs(Players:GetPlayers()) do
                if plr ~= Player and plr.Character then
                    local char = plr.Character
                    local head = char:FindFirstChild("Head")
                    local hrp = char:FindFirstChild("HumanoidRootPart")
                    local hum = char:FindFirstChildOfClass("Humanoid")

                    if head and hrp and hum and hum.Health > 0 then
                        local hl = char:FindFirstChild("PromptPlayerHighlight")
                        if not hl then
                            hl = Instance.new("Highlight")
                            hl.Name = "PromptPlayerHighlight"
                            hl.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop
                            hl.FillColor = Color3.fromRGB(255, 50, 50)
                            hl.FillTransparency = 0.72
                            hl.OutlineColor = Color3.fromRGB(255, 220, 60)
                            hl.OutlineTransparency = 0.15
                            hl.Parent = char
                        end

                        local bbg = head:FindFirstChild("PromptPlayerDotESP")
                        if not bbg then
                            bbg = Instance.new("BillboardGui")
                            bbg.Name = "PromptPlayerDotESP"
                            bbg.Adornee = head
                            bbg.Size = UDim2.new(0, 180, 0, 46)
                            bbg.StudsOffset = Vector3.new(0, 2.3, 0)
                            bbg.AlwaysOnTop = true
                            bbg.MaxDistance = 5000
                            bbg.Parent = head

                            local nameLbl = Instance.new("TextLabel", bbg)
                            nameLbl.Name = "NameText"
                            nameLbl.Size = UDim2.new(1, 0, 0, 22)
                            nameLbl.Position = UDim2.new(0, 0, 0, 0)
                            nameLbl.BackgroundTransparency = 1
                            nameLbl.TextColor3 = Color3.fromRGB(255, 255, 255)
                            nameLbl.TextStrokeTransparency = 0.15
                            nameLbl.Font = Enum.Font.SourceSansBold
                            nameLbl.TextSize = 13

                            local dotLbl = Instance.new("TextLabel", bbg)
                            dotLbl.Name = "DotText"
                            dotLbl.Size = UDim2.new(1, 0, 0, 24)
                            dotLbl.Position = UDim2.new(0, 0, 0, 16)
                            dotLbl.BackgroundTransparency = 1
                            dotLbl.Text = "•"
                            dotLbl.TextColor3 = Color3.fromRGB(255, 50, 50)
                            dotLbl.TextStrokeTransparency = 0
                            dotLbl.Font = Enum.Font.SourceSansBold
                            dotLbl.TextSize = 26
                        end

                        local dist = myRoot and math.floor((myRoot.Position - hrp.Position).Magnitude) or 0
                        local nameLbl = bbg:FindFirstChild("NameText")
                        if nameLbl then
                            nameLbl.Text = string.format("%s [%d HP] (%dм)", plr.DisplayName, math.floor(hum.Health), dist)
                        end
                    end
                end
            end
            task.wait(0.25)
        end

        clearAllEsp()
    end)
end)

createInput(visualsPage, "Размер хитбоксов врагов (Дефолт: 15)", "Число от 2 до 100...", function(Text)
    local num = tonumber(Text)
    if num and num >= 2 and num <= 100 then
        hitboxSizeValue = num
    end
end)

createToggle(movePage, "📦 Увеличить хитбоксы врагов (С подсветкой)", function(Value)
    hitboxEnabled = Value
    
    -- Очистка при выключении
    if not hitboxEnabled then
        for _, plr in ipairs(Players:GetPlayers()) do
            if plr.Character then
                local hb = plr.Character:FindFirstChild("PromptHitbox")
                if hb then hb:Destroy() end
            end
        end
        return 
    end

    task.spawn(function()
        while hitboxEnabled and not _G.ScriptDestroyed do
            if not _G.ScriptPaused then
                for _, plr in ipairs(Players:GetPlayers()) do
                    if plr ~= Player and plr.Character then
                        local hrp = plr.Character:FindFirstChild("HumanoidRootPart")
                        local hum = plr.Character:FindFirstChildOfClass("Humanoid")
                        if hrp and hum and hum.Health > 0 then
                            local hb = plr.Character:FindFirstChild("PromptHitbox")
                            if not hb then
                                hb = Instance.new("Part")
                                hb.Name = "PromptHitbox"
                                hb.Transparency = 0.65
                                hb.Color = Color3.fromRGB(255, 45, 45)
                                hb.Material = Enum.Material.Neon
                                hb.CanCollide = false
                                hb.CanQuery = true
                                hb.CanTouch = true
                                hb.Massless = true
                                hb.Parent = plr.Character
                                
                                local weld = Instance.new("WeldConstraint")
                                weld.Part0 = hb
                                weld.Part1 = hrp
                                weld.Parent = hb
                                
                                local sel = Instance.new("SelectionBox")
                                sel.Name = "PromptBigHitboxVis"
                                sel.Adornee = hb
                                sel.Color3 = Color3.fromRGB(255, 60, 60)
                                sel.SurfaceColor3 = Color3.fromRGB(255, 60, 60)
                                sel.SurfaceTransparency = 0.8
                                sel.LineThickness = 0.05
                                sel.Parent = hb
                            end
                            hb.Size = Vector3.new(hitboxSizeValue, hitboxSizeValue, hitboxSizeValue)
                            hb.Position = hrp.Position
                        end
                    end
                end
            end
            RunService.Heartbeat:Wait()
        end
    end)
end)

-- вот тут находится конец 1 блока (части 7.2)
-- Анти-хитбокс: рабочий переключатель расположен в блоке визуальных функций ниже.

createToggle(mainPage, "🎯 Мини-кнопка Auto-Aim камеры (CamLock)", function(Value)
    camLockMiniEnabled = Value
    camLockTarget = nil
    pcall(function() RunService:UnbindFromRenderStep("PromptCamLockStep") end)

    if camLockMiniBtn then
        pcall(function() camLockMiniBtn:Destroy() end)
        camLockMiniBtn = nil
    end

    if not camLockMiniEnabled then return end
    if ScreenGui then ScreenGui.DisplayOrder = 999 end

    local btn = Instance.new("TextButton")
    btn.Name = "CamLockMiniBtn"
    btn.Size = UDim2.new(0, 52, 0, 52)
    btn.Position = UDim2.new(0.84, 0, 0.38, 0)
    btn.BackgroundColor3 = Color3.fromRGB(210, 55, 45)
    btn.Text = "🎯"
    btn.TextColor3 = Color3.fromRGB(255, 255, 255)
    btn.Font = Enum.Font.SourceSansBold
    btn.TextSize = 26
    btn.Active = true
    btn.Draggable = true
    btn.ZIndex = 65
    btn.Parent = ScreenGui
    Instance.new("UICorner", btn).CornerRadius = UDim.new(1, 0)

    local stroke = Instance.new("UIStroke", btn)
    stroke.Thickness = 2.5
    stroke.Color = Color3.fromRGB(255, 220, 60)

    camLockMiniBtn = btn

    local lastTap = 0
    local function toggleLock()
        if tick() - lastTap < 0.25 then return end
        lastTap = tick()

        if camLockTarget then
            camLockTarget = nil
            btn.BackgroundColor3 = Color3.fromRGB(210, 55, 45)
        else
            local found = findNearestEnemyToCenter()
            if found then
                camLockTarget = found
                btn.BackgroundColor3 = Color3.fromRGB(50, 180, 70)
            end
        end
    end

    btn.InputBegan:Connect(function(input)
        if input.UserInputType == Enum.UserInputType.Touch or input.UserInputType == Enum.UserInputType.MouseButton1 then
            toggleLock()
        end
    end)

    RunService:BindToRenderStep("PromptCamLockStep", Enum.RenderPriority.Camera.Value + 1, function()
        if not camLockMiniEnabled or not btn or not btn.Parent or _G.ScriptDestroyed then
            pcall(function() RunService:UnbindFromRenderStep("PromptCamLockStep") end)
            return
        end

        if camLockTarget and not _G.ScriptPaused then
            local tChar = camLockTarget.Character
            local tHrp = tChar and tChar:FindFirstChild("HumanoidRootPart")
            local tHum = tChar and tChar:FindFirstChildOfClass("Humanoid")

            if tHrp and tHum and tHum.Health > 0 then
                btn.BackgroundColor3 = Color3.fromRGB(50, 180, 70)
                local cam = workspace.CurrentCamera
                cam.CFrame = CFrame.new(cam.CFrame.Position, tHrp.Position + Vector3.new(0, 1.2, 0))
            else
                camLockTarget = nil
                btn.BackgroundColor3 = Color3.fromRGB(210, 55, 45)
            end
        else
            btn.BackgroundColor3 = Color3.fromRGB(210, 55, 45)
        end
    end)
end)

-- вот тут находится конец 2 блока (части 7.2)
local shiftLockBtn = nil
local crosshairFrame = nil
local shiftLockActive = false

createToggle(visualsPage, "🔒 Мобильный Шифтлок с прицелом (Точный центр)", function(Value)
    shiftLockMiniEnabled = Value
    shiftLockActive = false

    local UIS = game:GetService("UserInputService")
    local GuiService = game:GetService("GuiService")
    UIS.MouseBehavior = Enum.MouseBehavior.Default

    if shiftLockBtn then pcall(function() shiftLockBtn:Destroy() end) shiftLockBtn = nil end
    if crosshairFrame then pcall(function() crosshairFrame:Destroy() end) crosshairFrame = nil end

    if not shiftLockMiniEnabled then return end
    if ScreenGui then ScreenGui.DisplayOrder = 999 end

    local btn = Instance.new("TextButton")
    btn.Name = "ShiftLockMiniBtn"
    btn.Size = UDim2.new(0, 48, 0, 48)
    btn.Position = UDim2.new(0.84, 0, 0.51, 0)
    btn.BackgroundColor3 = Color3.fromRGB(210, 55, 45)
    btn.Text = "🔒"
    btn.TextColor3 = Color3.fromRGB(255, 255, 255)
    btn.Font = Enum.Font.SourceSansBold
    btn.TextSize = 22
    btn.Active = true
    btn.Draggable = true
    btn.ZIndex = 65
    btn.Parent = ScreenGui
    Instance.new("UICorner", btn).CornerRadius = UDim.new(1, 0)

    local stroke = Instance.new("UIStroke", btn)
    stroke.Thickness = 2.5
    stroke.Color = Color3.fromRGB(100, 220, 255)

    shiftLockBtn = btn

    local ch = Instance.new("Frame")
    ch.Name = "PromptCrosshair"
    ch.Size = UDim2.new(0, 26, 0, 26)
    ch.AnchorPoint = Vector2.new(0.5, 0.5)
    ch.BackgroundTransparency = 1
    ch.Visible = false
    ch.ZIndex = 75
    ch.Parent = ScreenGui

    local hLine = Instance.new("Frame", ch)
    hLine.Size = UDim2.new(1, 0, 0, 2)
    hLine.Position = UDim2.new(0, 0, 0.5, -1)
    hLine.BackgroundColor3 = Color3.fromRGB(80, 255, 120)
    hLine.BorderSizePixel = 0

    local vLine = Instance.new("Frame", ch)
    vLine.Size = UDim2.new(0, 2, 1, 0)
    vLine.Position = UDim2.new(0.5, -1, 0, 0)
    vLine.BackgroundColor3 = Color3.fromRGB(80, 255, 120)
    vLine.BorderSizePixel = 0

    local centerDot = Instance.new("Frame", ch)
    centerDot.Size = UDim2.new(0, 4, 0, 4)
    centerDot.AnchorPoint = Vector2.new(0.5, 0.5)
    centerDot.Position = UDim2.new(0.5, 0, 0.5, 0)
    centerDot.BackgroundColor3 = Color3.fromRGB(255, 60, 60)
    centerDot.BorderSizePixel = 0
    Instance.new("UICorner", centerDot).CornerRadius = UDim.new(1, 0)

    crosshairFrame = ch

    local lastTap = 0
    local function toggleShift()
        if tick() - lastTap < 0.25 then return end
        lastTap = tick()
        shiftLockActive = not shiftLockActive
        ch.Visible = shiftLockActive
        btn.BackgroundColor3 = shiftLockActive and Color3.fromRGB(50, 180, 70) or Color3.fromRGB(210, 55, 45)
        if not shiftLockActive then
            UIS.MouseBehavior = Enum.MouseBehavior.Default
        end
    end

    btn.InputBegan:Connect(function(input)
        if input.UserInputType == Enum.UserInputType.Touch or input.UserInputType == Enum.UserInputType.MouseButton1 then
            toggleShift()
        end
    end)

    task.spawn(function()
        local cam = workspace.CurrentCamera
        while shiftLockMiniEnabled and btn and btn.Parent and not _G.ScriptDestroyed do
            local char = Player.Character
            local hum = char and char:FindFirstChildOfClass("Humanoid")
            local hrp = char and char:FindFirstChild("HumanoidRootPart")

            if shiftLockActive and not _G.ScriptPaused and hum and hrp then
                local inset = GuiService:GetGuiInset()
                local realCenterX = (cam.ViewportSize.X * 0.5) - inset.X
                local realCenterY = (cam.ViewportSize.Y * 0.5) - inset.Y
                ch.Position = UDim2.new(0, realCenterX, 0, realCenterY)

                UIS.MouseBehavior = Enum.MouseBehavior.LockCenter
                hum.AutoRotate = false
                hum.CameraOffset = Vector3.new(1.75, 0.35, 0)

                local look = cam.CFrame.LookVector
                local flatLook = Vector3.new(look.X, 0, look.Z)
                if flatLook.Magnitude > 0.01 then
                    hrp.CFrame = CFrame.new(hrp.Position, hrp.Position + flatLook.Unit)
                end
                if phantomRunning and ghostSimulationCube then
                    ghostSimulationCube.CFrame = CFrame.new(ghostSimulationCube.Position, ghostSimulationCube.Position + flatLook.Unit)
                end
            elseif hum then
                UIS.MouseBehavior = Enum.MouseBehavior.Default
                hum.AutoRotate = true
                hum.CameraOffset = Vector3.new(0, 0, 0)
            end
            RunService.RenderStepped:Wait()
        end

        UIS.MouseBehavior = Enum.MouseBehavior.Default
        local char = Player.Character
        local hum = char and char:FindFirstChildOfClass("Humanoid")
        if hum then
            hum.AutoRotate = true
            hum.CameraOffset = Vector3.new(0, 0, 0)
        end
    end)
end)

-- ШИФТЛОК: пока он включён, "мышь" для игры = центр экрана (как заблокированная мышь на ПК)
-- Работает через hookmetamethod; без него шифтлок просто остаётся камерой/поворотом как раньше.
task.spawn(function()
    repeat task.wait(0.5) until shiftLockActive or _G.ScriptDestroyed
    if _G.ScriptDestroyed then return end
    if not (hookmetamethod and checkcaller and getnamecallmethod) then
        warn("[Шифтлок] Экзекутор не поддерживает hookmetamethod: выстрелы в центр недоступны")
        return
    end

    local GuiService = game:GetService("GuiService")
    local UIS = game:GetService("UserInputService")
    local mouse = Player:GetMouse()
    local wrap = newcclosure or function(f) return f end

    local function centerPoint()
        local vs = workspace.CurrentCamera.ViewportSize
        return Vector2.new(vs.X * 0.5, vs.Y * 0.5)
    end

    local function centerRay()
        local c = centerPoint()
        return workspace.CurrentCamera:ViewportPointToRay(c.X, c.Y)
    end

    local function centerRaycast()
        local ray = centerRay()
        local params = RaycastParams.new()
        params.FilterType = Enum.RaycastFilterType.Exclude
        local ignore = {}
        if Player.Character then table.insert(ignore, Player.Character) end
        if ghostVisualClone then table.insert(ignore, ghostVisualClone) end
        if ghostSimulationCube then table.insert(ignore, ghostSimulationCube) end
        params.FilterDescendantsInstances = ignore
        local result = workspace:Raycast(ray.Origin, ray.Direction * 1000, params)
        return ray, result
    end

    local function redirectActive()
        return shiftLockActive and not _G.ScriptPaused and not _G.ScriptDestroyed
    end

    local oldIndex
    oldIndex = hookmetamethod(game, "__index", wrap(function(self, key)
        if self == mouse and not checkcaller() and redirectActive() then
            if key == "Hit" then
                local ray, result = centerRaycast()
                return CFrame.new(result and result.Position or (ray.Origin + ray.Direction * 1000))
            elseif key == "Target" then
                local _, result = centerRaycast()
                return result and result.Instance or nil
            elseif key == "X" then
                return centerPoint().X - GuiService:GetGuiInset().X
            elseif key == "Y" then
                return centerPoint().Y - GuiService:GetGuiInset().Y
            elseif key == "UnitRay" then
                return centerRay()
            end
        end
        return oldIndex(self, key)
    end))

    local oldNamecall
    oldNamecall = hookmetamethod(game, "__namecall", wrap(function(self, ...)
        if self == UIS and not checkcaller() and redirectActive() and getnamecallmethod() == "GetMouseLocation" then
            return centerPoint()
        end
        return oldNamecall(self, ...)
    end))
end)

end
-- =========================================================
-- ----- КОНЕЦ ЧАСТИ 7.2 -----
-- =========================================================
-- =========================================================
-- ----- НАЧАЛО ЧАСТИ 7.3 -----
-- =========================================================
do

local hiddenHitboxesEnabled = false
local cdTrackerEnabled = false

-- =========================================================
-- ОБЩИЙ КЛАССИФИКАТОР ОПАСНЫХ ДЕТАЛЕЙ (его используют и показ хитбоксов, и подушка)
-- Категории: lethal (смерть/лава/ловушки), attack (урон/хитбоксы атак),
--            control (торнадо/притяжение), trigger (невидимые контактные зоны)
-- =========================================================
local hazardLearnedParts = setmetatable({}, {__mode = "k"}) -- детали, на которых вы реально получили урон
local hazardLearnedNames = {}                               -- имена таких деталей (кроме общих вроде "Part")
local hazardCache = setmetatable({}, {__mode = "k"})
local hitboxCandidates = {}                                 -- [part] = true, кандидаты для показа

local HAZARD_OWN_PREFIXES = {
    "Prompt", "Phantom_", "Bunker_", "ZoneMarker_", "ZoneBoxVisual_",
    "Cushion_", "BendySurfacePuppet"
}
local LETHAL_WORDS = {
    "kill", "instantkill", "lethal", "deadly", "death", "killbrick", "void",
    "lava", "magma", "acid", "poison", "spike", "fire", "burn", "hazard",
    "danger", "trap", "onehit", "oneshot"
}
local WALL_ATTACK_WORDS = {"hitbox", "damage", "dmg", "hurt"}
local ATTACK_WORDS = {"hitbox", "damage", "dmg", "hurt", "slash", "blast", "shock", "wave", "aura", "explosion",
    "attack", "projectile", "bullet", "laser", "bomb", "missile", "beam", "strike", "slam", "swing", "knockback", "stun"}
local CONTROL_WORDS = {"tornado", "hurricane", "vortex", "pull", "wind"}
local HAZARD_GENERIC_NAMES = {
    part = true, meshpart = true, union = true, unionoperation = true, wedge = true,
    floor = true, ground = true, wall = true, base = true, baseplate = true,
    platform = true, block = true, brick = true, plate = true, model = true,
    handle = true, terrain = true, spawn = true, spawnlocation = true
}

local function hazardSanitize(text)
    -- "skill" содержит "kill", "avoid" содержит "void", "window" содержит "wind" — это не опасные зоны
    text = text:lower()
    text = (text:gsub("skill", ""))
    text = (text:gsub("avoid", ""))
    text = (text:gsub("window", ""))
    return text
end

local function hazardHasWord(text, list)
    if text == "" then return false end
    for _, word in ipairs(list) do
        if text:find(word, 1, true) then return true end
    end
    return false
end

local function getHazardHumanoidModel(obj)
    local model = obj:FindFirstAncestorOfClass("Model")
    while model do
        if model:FindFirstChildOfClass("Humanoid") then return model end
        model = model:FindFirstAncestorOfClass("Model")
    end
    return nil
end

-- Детали самого скрипта (PromptHitbox расширителя, платформы, маркеры, стенки подушки) не трогаем
local function isHazardOwnObject(obj)
    local roots = {godAirPlatform, godGroundCube, godVisualClone, ghostSimulationCube, ghostVisualClone, zoneBoxVisual, markerA, markerB}
    for i = 1, 8 do
        local root = roots[i]
        if root and (obj == root or obj:IsDescendantOf(root)) then return true end
    end
    local cur = obj
    while cur and cur ~= workspace do
        local n = cur.Name
        for _, prefix in ipairs(HAZARD_OWN_PREFIXES) do
            if n:sub(1, #prefix) == prefix then return true end
        end
        cur = cur.Parent
    end
    return false
end

-- Лава "на вид": CrackedLava или красно-оранжевый цвет
local function looksLikeLava(obj)
    if obj.Material == Enum.Material.CrackedLava then return true end
    local h, s, v = obj.Color:ToHSV()
    return (h <= 0.1 or h >= 0.97) and s >= 0.65 and v >= 0.55
end

local function computeHazard(obj)
    if not obj:IsA("BasePart") or obj:IsA("Terrain") then return nil, false end
    if obj.Name == "Baseplate" or not obj:IsDescendantOf(workspace) then return nil, false end
    if Player.Character and obj:IsDescendantOf(Player.Character) then return nil, false end
    if isHazardOwnObject(obj) then return nil, false end

    local size = obj.Size
    local maxAxis = math.max(size.X, size.Y, size.Z)
    local rawName = obj.Name:lower()
    local name = hazardSanitize(obj.Name)
    local humModel = getHazardHumanoidModel(obj)

    -- Внутри персонажей/NPC имя модели — это ник/имя босса, поэтому смотрим только на имя самой детали
    local parentName, grandName, parentRaw = "", "", ""
    if not humModel and obj.Parent then
        parentRaw = obj.Parent.Name:lower()
        parentName = hazardSanitize(obj.Parent.Name)
        if obj.Parent.Parent then grandName = hazardSanitize(obj.Parent.Parent.Name) end
    end

    local touch = obj:FindFirstChildOfClass("TouchTransmitter") ~= nil
    local cat, wall = nil, false

    if hazardLearnedNames[rawName] then
        cat, wall = "lethal", true
    elseif hazardHasWord(name, LETHAL_WORDS) or hazardHasWord(parentName, LETHAL_WORDS) or hazardHasWord(grandName, LETHAL_WORDS) then
        cat, wall = "lethal", true
    elseif hazardHasWord(name, WALL_ATTACK_WORDS) or hazardHasWord(parentName, WALL_ATTACK_WORDS) or hazardHasWord(grandName, WALL_ATTACK_WORDS) then
        cat, wall = "attack", true
    end

    -- Атрибуты, которыми разработчики помечают опасные детали
    if not cat then
        for attributeName, attributeValue in pairs(obj:GetAttributes()) do
            local key = attributeName:lower()
            local isKill = key:find("kill", 1, true) or key:find("lethal", 1, true)
                or key:find("oneshot", 1, true) or key:find("instant", 1, true)
            if isKill or key:find("damage", 1, true) or key:find("dmg", 1, true) then
                if attributeValue == true or (type(attributeValue) == "number" and attributeValue > 0) then
                    cat, wall = (isKill and "lethal" or "attack"), true
                    break
                end
            end
        end
    end

    -- Лава без понятного названия: большая красно-оранжевая деталь с контактным триггером или материал CrackedLava
    if not cat and ((touch and maxAxis >= 4 and obj.Transparency < 0.9 and looksLikeLava(obj))
        or obj.Material == Enum.Material.CrackedLava) then
        cat, wall = "lethal", true
    end

    -- Только для показа (стенки вокруг них не строятся)
    if not cat then
        if hazardHasWord(name, ATTACK_WORDS) then
            cat = "attack"
        elseif hazardHasWord(name, CONTROL_WORDS) then
            cat = "control"
        elseif not humModel and not obj.CanCollide and (parentRaw:find("effect", 1, true) or parentRaw:find("skill", 1, true)
            or parentRaw:find("ability", 1, true) or parentRaw:find("projectile", 1, true)
            or parentRaw:find("attack", 1, true) or parentRaw:find("vfx", 1, true)) then
            cat = "attack"
        elseif not humModel and touch and not obj.CanCollide then
            cat = "trigger"
        elseif not humModel and not obj.CanCollide and obj.Transparency >= 0.9 and maxAxis >= 1 then
            cat = "trigger" -- любая невидимая неколлизионная деталь (скрытые зоны)
        end
    end

    if wall and maxAxis > 2040 then wall = false end -- стенка = размер + 2, лимит Part 2048
    return cat, wall
end

local function classifyHazard(obj, now)
    if hazardLearnedParts[obj] then return "lethal", true end
    now = now or tick()
    local cached = hazardCache[obj]
    if cached and now - cached.t < 2 then return cached.cat, cached.wall end
    local cat, wall = computeHazard(obj)
    hazardCache[obj] = {t = now, cat = cat, wall = wall}
    return cat, wall
end

-- =========================================================
-- ПОКАЗ ХИТБОКСОВ (цветные категории, подписи с расстоянием, без лимита Highlight=31)
-- =========================================================
local HAZARD_STYLE = {
    lethal  = {color = Color3.fromRGB(255, 45, 45),  icon = "☠", fill = 0.72},
    attack  = {color = Color3.fromRGB(255, 150, 30), icon = "⚔", fill = 0.78},
    control = {color = Color3.fromRGB(175, 95, 255), icon = "🌀", fill = 0.80},
    trigger = {color = Color3.fromRGB(255, 225, 70), icon = "◇", fill = 0.88}
}
local HITBOX_RANGE = math.huge   -- без лимита дальности
local HITBOX_MAX_VISUALS = 6000  -- практически без лимита количества

local hitboxFolder = nil
local hitboxVisuals = {}
local hitboxConns = {}
local hitboxSession = 0

local function destroyHitboxVisual(part)
    local v = hitboxVisuals[part]
    if not v then return end
    if v.box then v.box:Destroy() end
    if v.outline then v.outline:Destroy() end
    if v.gui then v.gui:Destroy() end
    hitboxVisuals[part] = nil
end

local function clearHitboxVisuals()
    for part in pairs(hitboxVisuals) do destroyHitboxVisual(part) end
    table.clear(hitboxVisuals)
    if hitboxFolder then hitboxFolder:Destroy() hitboxFolder = nil end
end

local function createHitboxVisual(part, cat)
    local style = HAZARD_STYLE[cat]
    local s = part.Size
    local big = math.max(s.X, s.Y, s.Z) > 60

    local box = Instance.new("BoxHandleAdornment")
    box.Name = "PromptHitboxFill"
    box.Adornee = part
    box.Size = s
    box.Color3 = style.color
    box.Transparency = big and 0.93 or style.fill
    box.AlwaysOnTop = true
    box.ZIndex = 2
    box.Parent = hitboxFolder

    local outline = Instance.new("SelectionBox")
    outline.Name = "PromptHitboxOutline"
    outline.Adornee = part
    outline.Color3 = style.color
    outline.LineThickness = 0.04
    outline.SurfaceTransparency = 1
    outline.Parent = hitboxFolder

    local gui = Instance.new("BillboardGui")
    gui.Name = "PromptHitboxInfo"
    gui.Adornee = part
    gui.AlwaysOnTop = true
    gui.LightInfluence = 0
    gui.MaxDistance = math.huge
    gui.Size = UDim2.fromOffset(170, 30)
    gui.StudsOffsetWorldSpace = Vector3.new(0, math.min(s.Y * 0.5, 15) + 2, 0)
    gui.Enabled = (cat ~= "trigger")
    gui.Parent = hitboxFolder

    local label = Instance.new("TextLabel")
    label.Size = UDim2.fromScale(1, 1)
    label.BackgroundTransparency = 1
    label.TextColor3 = style.color
    label.TextStrokeColor3 = Color3.new(0, 0, 0)
    label.TextStrokeTransparency = 0.3
    label.Font = Enum.Font.GothamBold
    label.TextSize = 13
    label.Text = ""
    label.Parent = gui

    return {cat = cat, box = box, outline = outline, gui = gui, label = label, text = ""}
end

local function considerHitboxPart(part, now)
    if hitboxCandidates[part] then return end
    local cat = classifyHazard(part, now)
    if cat then hitboxCandidates[part] = true end
end

local function updateHitboxes()
    local cam = workspace.CurrentCamera
    if not cam or not hitboxFolder then return end
    if not hitboxFolder.Parent then
        -- игра очистила workspace — пересоздаём папку и визуалы
        table.clear(hitboxVisuals)
        hitboxFolder = Instance.new("Folder")
        hitboxFolder.Name = "PromptHitboxFolder"
        hitboxFolder.Parent = workspace
    end
    local camPos = cam.CFrame.Position
    local now = tick()
    local list = {}

    for part in pairs(hitboxCandidates) do
        if not part.Parent or not part:IsDescendantOf(workspace) then
            hitboxCandidates[part] = nil
        else
            local cat = classifyHazard(part, now)
            if cat then
                local s = part.Size
                local d = (part.Position - camPos).Magnitude
                local dEdge = math.max(0, d - math.max(s.X, s.Y, s.Z) * 0.5)
                if dEdge <= HITBOX_RANGE then
                    list[#list + 1] = {part = part, cat = cat, d = d, de = dEdge}
                end
            else
                hitboxCandidates[part] = nil -- перестала подходить; вернётся при следующем пересканировании
            end
        end
    end

    table.sort(list, function(a, b) return a.de < b.de end)

    local wanted = {}
    for i = 1, math.min(#list, HITBOX_MAX_VISUALS) do
        local e = list[i]
        local part = e.part
        wanted[part] = true

        local v = hitboxVisuals[part]
        if v and (v.cat ~= e.cat or not v.box.Parent) then
            destroyHitboxVisual(part)
            v = nil
        end
        if not v then
            v = createHitboxVisual(part, e.cat)
            hitboxVisuals[part] = v
        end

        local s = part.Size
        if v.box.Size ~= s then v.box.Size = s end -- растущие хитбоксы подстраиваются
        local nm = part.Name
        if #nm > 18 then nm = nm:sub(1, 17) .. "…" end
        local text = HAZARD_STYLE[e.cat].icon .. " " .. nm .. "  " .. math.floor(e.d)
        if v.text ~= text then
            v.text = text
            v.label.Text = text
        end
    end

    for part in pairs(hitboxVisuals) do
        if not wanted[part] then destroyHitboxVisual(part) end
    end
end

createToggle(visualsPage, "🔮 Скрытые хитбоксы (☠ смерть  ⚔ урон  🌀 притяжение)", function(Value)
    hiddenHitboxesEnabled = Value
    hitboxSession = hitboxSession + 1
    local session = hitboxSession

    for _, c in ipairs(hitboxConns) do
        if c and c.Connected then c:Disconnect() end
    end
    table.clear(hitboxConns)

    if not Value then
        clearHitboxVisuals()
        table.clear(hitboxCandidates)
        return
    end

    if hitboxFolder then hitboxFolder:Destroy() end
    hitboxFolder = Instance.new("Folder")
    hitboxFolder.Name = "PromptHitboxFolder"
    hitboxFolder.Parent = workspace

    table.insert(hitboxConns, workspace.DescendantAdded:Connect(function(obj)
        if not obj:IsA("BasePart") then return end
        task.defer(function()
            if hiddenHitboxesEnabled and hitboxSession == session and obj.Parent then
                considerHitboxPart(obj, tick())
            end
        end)
    end))

    task.spawn(function()
        local lastRescan = 0
        while hiddenHitboxesEnabled and hitboxSession == session and not _G.ScriptDestroyed do
            local t = tick()
            if t - lastRescan > 2 then
                lastRescan = t
                local n = 0
                for _, obj in ipairs(workspace:GetDescendants()) do
                    if not hiddenHitboxesEnabled or hitboxSession ~= session or _G.ScriptDestroyed then break end
                    if obj:IsA("BasePart") then considerHitboxPart(obj, t) end
                    n = n + 1
                    if n % 400 == 0 then task.wait() end -- без фриза на больших картах
                end
            end
            updateHitboxes()
            task.wait(0.1)
        end
        if hitboxSession == session then clearHitboxVisuals() end -- закрытие скрипта
    end)
end)

-- =========================================================
-- 🛡️ АНТИ-ХИТБОКС ПОДУШКА (HITBOX DEFLECTOR)
-- Прозрачные локальные коллизионные стенки вокруг найденных хитбоксов и лавы. Серверный урон они гарантированно отключить не могут.
-- Самообучение: если вы получили урон, детали, на которых вы стояли/которых касались (контактные или "лавовые"), запоминаются и обносятся стенкой.
-- =========================================================
local cushionEnabled = false
local cushionSession = 0
local cushionConnections = {}
local cushionVisuals = {}
local cushionCount = 0

local CUSHION_PAD = 6 -- по 3 стада с каждой стороны: тело/руки/ноги не дотягиваются до хитбокса
local CUSHION_MAX_PART_SIZE = 2040
local CUSHION_MAX_WALLS = 500

local function disconnectCushionConnections()
    for _, connection in ipairs(cushionConnections) do
        if connection and connection.Connected then connection:Disconnect() end
    end
    table.clear(cushionConnections)
end

local function clearCushionVisuals()
    for _, visual in pairs(cushionVisuals) do
        if visual and visual.Parent then visual:Destroy() end
    end
    table.clear(cushionVisuals)
    cushionCount = 0
end

local function isCushionHitbox(obj)
    if not obj or not obj:IsA("BasePart") then return false end
    local _, wall = classifyHazard(obj)
    return wall == true
end

local function getCushionWallSize(part)
    local s = part.Size
    return Vector3.new(s.X + CUSHION_PAD, s.Y + CUSHION_PAD, s.Z + CUSHION_PAD)
end

local function addCushionVisual(part)
    if not cushionEnabled or not isCushionHitbox(part) then return end
    if cushionVisuals[part] and cushionVisuals[part].Parent then return end
    local s = part.Size
    if math.max(s.X, s.Y, s.Z) > CUSHION_MAX_PART_SIZE then return end
    if cushionCount >= CUSHION_MAX_WALLS and not cushionVisuals[part] then return end

    local visual = Instance.new("Part")
    visual.Name = "Cushion_Shield"
    -- Чуть больший прозрачный блок работает как стенка между игроком и хитбоксом.
    visual.Size = getCushionWallSize(part)
    visual.CFrame = part.CFrame
    visual.Anchored = true
    visual.CanCollide = true
    visual.CanTouch = false
    visual.CanQuery = true -- иначе Humanoid не видит стенку как пол: нельзя прыгать/ходить по ней над лавой
    visual.CastShadow = false
    visual.Massless = true
    visual.Transparency = 1
    visual.Parent = workspace

    if not cushionVisuals[part] then cushionCount = cushionCount + 1 end
    cushionVisuals[part] = visual
end

local function disableCushion()
    cushionEnabled = false
    cushionSession = cushionSession + 1
    disconnectCushionConnections()
    clearCushionVisuals()
end

-- Стенка ВСЕГДА твёрдая (как деталь режима стройки). Если хитбокс появился прямо на вас и центр персонажа
-- оказался внутри стенки, вас без импульсов и "вылетов" переносит на ближайшую внешнюю грань (верх — приоритет, можно стоять).
local function isLocalRootInsideWall(root, wall)
    if not root or not root.Parent then return false end
    local rel = wall.CFrame:PointToObjectSpace(root.Position)
    local half = wall.Size * 0.5
    return math.abs(rel.X) < half.X and math.abs(rel.Y) < half.Y and math.abs(rel.Z) < half.Z
end

local function ejectRootFromWall(root, wall)
    local rel = wall.CFrame:PointToObjectSpace(root.Position)
    local half = wall.Size * 0.5
    local sideMargin, topMargin = 2.6, 3.4
    local best, bestDist = nil, math.huge
    local function try(name, dist)
        if dist < bestDist then best, bestDist = name, dist end
    end
    try("px", half.X - rel.X)
    try("nx", half.X + rel.X)
    try("pz", half.Z - rel.Z)
    try("nz", half.Z + rel.Z)
    try("py", (half.Y - rel.Y) * 0.6) -- верх выгоднее: можно встать на стенку
    try("ny", half.Y + rel.Y)
    local r = Vector3.new(rel.X, rel.Y, rel.Z)
    if best == "px" then r = Vector3.new(half.X + sideMargin, rel.Y, rel.Z)
    elseif best == "nx" then r = Vector3.new(-half.X - sideMargin, rel.Y, rel.Z)
    elseif best == "pz" then r = Vector3.new(rel.X, rel.Y, half.Z + sideMargin)
    elseif best == "nz" then r = Vector3.new(rel.X, rel.Y, -half.Z - sideMargin)
    elseif best == "py" then r = Vector3.new(rel.X, half.Y + topMargin, rel.Z)
    else r = Vector3.new(rel.X, -half.Y - topMargin, rel.Z) end
    local worldPos = wall.CFrame:PointToWorldSpace(r)
    local rot = root.CFrame - root.CFrame.Position
    root.CFrame = CFrame.new(worldPos) * rot
    root.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
end

-- Самообучение: запоминаем то, что рядом с персонажем в момент урона
local lastCushionNotify = 0
local function learnTouchingHazards(char)
    if not char or not char.Parent then return end
    local ok, cf, size = pcall(function() return char:GetBoundingBox() end)
    if not ok or not cf then return end

    local params = OverlapParams.new()
    params.FilterType = Enum.RaycastFilterType.Exclude
    params.FilterDescendantsInstances = {char}
    local parts = workspace:GetPartBoundsInBox(cf, size + Vector3.new(3, 3, 3), params)

    local learnedNames = {}
    for _, p in ipairs(parts) do
        if p:IsA("BasePart") and not p:IsA("Terrain") and p.Name ~= "Baseplate"
            and not hazardLearnedParts[p] and not isHazardOwnObject(p) and not getHazardHumanoidModel(p) then
            local touch = p:FindFirstChildOfClass("TouchTransmitter") ~= nil
            local lavaish = looksLikeLava(p)
            if touch or lavaish then
                hazardLearnedParts[p] = true
                hazardCache[p] = nil
                hitboxCandidates[p] = true
                local lname = p.Name:lower()
                local s = p.Size
                local m = math.max(s.X, s.Y, s.Z)
                if #lname >= 4 and not HAZARD_GENERIC_NAMES[lname] and not lname:match("^%d+$")
                    and (lavaish or m >= 6) then
                    hazardLearnedNames[lname] = true
                end
                addCushionVisual(p)
                table.insert(learnedNames, p.Name)
            end
        end
    end

    if #learnedNames > 0 and tick() - lastCushionNotify > 2 then
        lastCushionNotify = tick()
        pcall(function()
            game:GetService("StarterGui"):SetCore("SendNotification", {
                Title = "🛡 Подушка",
                Text = "Запомнил опасное: " .. table.concat(learnedNames, ", ", 1, math.min(#learnedNames, 3)),
                Duration = 4
            })
        end)
    end
end

local function hookCushionHumanoid(char, session)
    task.spawn(function()
        local hum = char:WaitForChild("Humanoid", 5)
        if not hum or not cushionEnabled or cushionSession ~= session then return end
        local last = hum.Health
        table.insert(cushionConnections, hum.HealthChanged:Connect(function(h)
            local drop = last - h
            last = h
            if drop > 0 and cushionEnabled and cushionSession == session then
                learnTouchingHazards(char)
            end
        end))
    end)
end

createToggle(visualsPage, "🛡 Анти-Хитбокс Подушка (Стены вокруг хитбоксов и лавы)", function(value)
    if not value then
        disableCushion()
        return
    end
    if cushionEnabled then return end
    cushionEnabled = true
    cushionSession = cushionSession + 1
    local session = cushionSession

    -- Сначала подписка на новые детали, потом первичный скан — ничего не теряется (дубли отсекает addCushionVisual)
    table.insert(cushionConnections, workspace.DescendantAdded:Connect(function(obj)
        if cushionEnabled and obj:IsA("BasePart") then
            task.defer(function()
                if cushionEnabled and cushionSession == session and obj and obj.Parent then addCushionVisual(obj) end
            end)
        end
    end))

    task.spawn(function()
        local n = 0
        for _, obj in ipairs(workspace:GetDescendants()) do
            if not cushionEnabled or cushionSession ~= session or _G.ScriptDestroyed then return end
            if obj:IsA("BasePart") then addCushionVisual(obj) end
            n = n + 1
            if n % 400 == 0 then task.wait() end -- без фриза на больших картах
        end
    end)

    if Player.Character then hookCushionHumanoid(Player.Character, session) end
    table.insert(cushionConnections, Player.CharacterAdded:Connect(function(c)
        hookCushionHumanoid(c, session)
    end))

    table.insert(cushionConnections, RunService.Heartbeat:Connect(function()
        if not cushionEnabled or _G.ScriptDestroyed then
            disableCushion()
            return
        end

        local char = Player.Character
        local root = char and char:FindFirstChild("HumanoidRootPart")
        -- в режиме бога/инвиза реальное тело — куб-симуляция, его и защищаем
        local ctrlRoot = (invisActive and ghostSimulationCube) or (godmodeEnabled and godGroundCube) or root
        local toRebuild = nil

        for part, wall in pairs(cushionVisuals) do
            if not part or not part.Parent or not part:IsDescendantOf(workspace) then
                if wall and wall.Parent then wall:Destroy() end
                cushionVisuals[part] = nil
                cushionCount = cushionCount - 1
            elseif not wall or not wall.Parent then
                -- стенку удалила игра/очистка карты — пересоздаём
                cushionVisuals[part] = nil
                cushionCount = cushionCount - 1
                toRebuild = toRebuild or {}
                table.insert(toRebuild, part)
            else
                -- Стенка следует за движущимся хитбоксом/растущей лавой; никаких импульсов игроку не применяется.
                local newSize = getCushionWallSize(part)
                if wall.Size ~= newSize then wall.Size = newSize end
                if wall.CFrame ~= part.CFrame then wall.CFrame = part.CFrame end

                if not wall.CanCollide then wall.CanCollide = true end
                if ctrlRoot and isLocalRootInsideWall(ctrlRoot, wall) then
                    ejectRootFromWall(ctrlRoot, wall)
                end
            end
        end

        if toRebuild then
            for _, part in ipairs(toRebuild) do addCushionVisual(part) end
        end
    end))
end)

-- вот тут находится конец 1 блока (части 7.3)
local playerCooldownData = {}

local function registerPlayerTool(pData, toolObj)
    if not toolObj or not toolObj:IsA("Tool") then return end
    local toolName = toolObj.Name
    local slotIdx = pData.NameToSlot[toolName]

    if not slotIdx then
        if #pData.SlotNames < 9 then
            table.insert(pData.SlotNames, toolName)
            slotIdx = #pData.SlotNames
            pData.NameToSlot[toolName] = slotIdx
        else
            slotIdx = 9
        end
    end

    if not pData.HookedTools[toolObj] then
        pData.HookedTools[toolObj] = true
        table.insert(pData.Connections, toolObj.Activated:Connect(function()
            local cd = toolObj:GetAttribute("Cooldown") or toolObj:GetAttribute("CD") or 4
            if type(cd) ~= "number" or cd <= 0 then cd = 4 end
            pData.Cooldowns[slotIdx] = tick() + cd
        end))
    end
end

local function setupPlayerCdTracker(plr, char, hum)
    local pData = {
        Char = char,
        SlotNames = {},
        NameToSlot = {},
        Cooldowns = {},
        HookedTools = {},
        LastAnimTime = 0,
        Connections = {}
    }
    playerCooldownData[plr] = pData

    table.insert(pData.Connections, char.ChildAdded:Connect(function(child)
        if child:IsA("Tool") then registerPlayerTool(pData, child) end
    end))

    local animator = hum:FindFirstChildOfClass("Animator")
    if animator then
        table.insert(pData.Connections, animator.AnimationPlayed:Connect(function(track)
            if tick() - pData.LastAnimTime < 0.45 then return end
            local animName = track.Animation and track.Animation.Name:lower() or ""
            if animName:find("walk") or animName:find("run") or animName:find("idle") or animName:find("jump") or animName:find("fall") then
                return
            end
            pData.LastAnimTime = tick()

            local heldTool = char:FindFirstChildOfClass("Tool")
            if heldTool then
                registerPlayerTool(pData, heldTool)
                local sIdx = pData.NameToSlot[heldTool.Name]
                if sIdx and (not pData.Cooldowns[sIdx] or pData.Cooldowns[sIdx] < tick()) then
                    local cd = heldTool:GetAttribute("Cooldown") or heldTool:GetAttribute("CD") or 4
                    if type(cd) ~= "number" or cd <= 0 then cd = 4 end
                    pData.Cooldowns[sIdx] = tick() + cd
                end
            end
        end))
    end

    return pData
end

local function renderPlayerCdSlots(head, pData, equippedTool)
    local totalSlots = #pData.SlotNames
    local bbg = head:FindFirstChild("PromptCDTracker")
    
    if totalSlots == 0 then
        if bbg then bbg.Enabled = false end
        return
    end

    if not bbg then
        bbg = Instance.new("BillboardGui")
        bbg.Name = "PromptCDTracker"
        bbg.AlwaysOnTop = true
        bbg.MaxDistance = 400
        bbg.StudsOffset = Vector3.new(0, 3.6, 0)
        bbg.Parent = head

        local container = Instance.new("Frame", bbg)
        container.Name = "SlotsRow"
        container.Size = UDim2.new(1, 0, 1, 0)
        container.BackgroundTransparency = 1

        local layout = Instance.new("UIListLayout", container)
        layout.FillDirection = Enum.FillDirection.Horizontal
        layout.HorizontalAlignment = Enum.HorizontalAlignment.Center
        layout.Padding = UDim.new(0, 3)
    end
    
    bbg.Enabled = true
    bbg.Size = UDim2.new(0, totalSlots * 34 + 12, 0, 34)
    local container = bbg:FindFirstChild("SlotsRow")
    
    -- Пересоздаем слоты только если изменилось их количество
    local currentFrames = 0
    for _, ch in ipairs(container:GetChildren()) do
        if ch:IsA("Frame") then currentFrames = currentFrames + 1 end
    end

    if currentFrames ~= totalSlots then
        for _, ch in ipairs(container:GetChildren()) do
            if ch:IsA("Frame") then ch:Destroy() end
        end

        for i = 1, totalSlots do
            local slotFrame = Instance.new("Frame", container)
            slotFrame.Size = UDim2.new(0, 30, 0, 30)
            Instance.new("UICorner", slotFrame).CornerRadius = UDim.new(0, 5)

            local topNum = Instance.new("TextLabel", slotFrame)
            topNum.Name = "Num"
            topNum.Size = UDim2.new(1, 0, 0, 11)
            topNum.BackgroundTransparency = 1
            topNum.Text = tostring(i)
            topNum.TextColor3 = Color3.fromRGB(230, 230, 230)
            topNum.Font = Enum.Font.SourceSansBold
            topNum.TextSize = 9

            local statusTxt = Instance.new("TextLabel", slotFrame)
            statusTxt.Name = "Status"
            statusTxt.Size = UDim2.new(1, 0, 0, 18)
            statusTxt.Position = UDim2.new(0, 0, 0, 11)
            statusTxt.BackgroundTransparency = 1
            statusTxt.Font = Enum.Font.SourceSansBold
            statusTxt.TextSize = 10
        end
    end

    -- Обновляем инфу в существующих слотах
    local idx = 0
    for _, slotFrame in ipairs(container:GetChildren()) do
        if slotFrame:IsA("Frame") then
            idx = idx + 1
            local sName = pData.SlotNames[idx]
            local statusTxt = slotFrame:FindFirstChild("Status")
            
            local cdEnd = pData.Cooldowns[idx]
            local rem = cdEnd and (cdEnd - tick()) or 0
            local isHeld = equippedTool and (equippedTool.Name == sName)

            if rem > 0 then
                slotFrame.BackgroundColor3 = Color3.fromRGB(195, 45, 45)
                statusTxt.Text = string.format("%.1f", rem)
                statusTxt.TextColor3 = Color3.fromRGB(255, 255, 255)
            elseif isHeld then
                slotFrame.BackgroundColor3 = Color3.fromRGB(225, 185, 40)
                statusTxt.Text = sName:sub(1, 3)
                statusTxt.TextColor3 = Color3.fromRGB(20, 20, 20)
            else
                slotFrame.BackgroundColor3 = Color3.fromRGB(45, 155, 65)
                statusTxt.Text = sName:sub(1, 3)
                statusTxt.TextColor3 = Color3.fromRGB(255, 255, 255)
            end
        end
    end
end

createToggle(visualsPage, "⏱ Трекер КД над головой (Умные слоты 1–9)", function(Value)
    cdTrackerEnabled = Value
    if not cdTrackerEnabled then return end

    task.spawn(function()
        while cdTrackerEnabled and not _G.ScriptDestroyed do
    for _, plr in ipairs(Players:GetPlayers()) do
               if plr ~= Player and plr.Character then
                 local char = plr.Character
          local head = char:FindFirstChild("Head")
                    local hum = char:FindFirstChildOfClass("Humanoid")
                    if head and hum and hum.Health > 0 then
                        local pData = playerCooldownData[plr]
                        if not pData or pData.Char ~= char then
                            pData = setupPlayerCdTracker(plr, char, hum)
                        end
                        local eq = char:FindFirstChildOfClass("Tool")
                        if eq then registerPlayerTool(pData, eq) end
                        local bp = plr:FindFirstChildOfClass("Backpack")
                        if bp then
                            for _, it in ipairs(bp:GetChildren()) do
                                if it:IsA("Tool") then registerPlayerTool(pData, it) end
                            end
                        end
                        renderPlayerCdSlots(head, pData, eq)
                    end
                end
            end
            task.wait(0.15)
        end

        for _, plr in ipairs(Players:GetPlayers()) do
            if plr.Character and plr.Character:FindFirstChild("Head") then
                local gui = plr.Character.Head:FindFirstChild("PromptCDTracker")
                if gui then gui:Destroy() end
            end
        end
    end)
end)

end
-- =========================================================
-- ----- КОНЕЦ ЧАСТИ 7.3 -----
-- =========================================================
-- =========================================================
-- ----- НАЧАЛО ЧАСТИ 7.4 -----
-- =========================================================
do

local minimapEnabled = false
local stealthEyeEnabled = false
local lootEspEnabled = false

local minimapFrame = nil

createToggle(visualsPage, "🛰 Радар-миникарта сверху (Ты зелёный, враги красные)", function(Value)
    minimapEnabled = Value
    if minimapFrame then
        pcall(function() minimapFrame:Destroy() end)
        minimapFrame = nil
    end

    if not minimapEnabled then return end
    if ScreenGui then ScreenGui.DisplayOrder = 999 end

    local container = Instance.new("Frame")
    container.Name = "Prompt3DMinimap"
    container.Size = UDim2.new(0, 150, 0, 150)
    container.Position = UDim2.new(1, -162, 0.04, 0)
    container.BackgroundColor3 = Color3.fromRGB(16, 20, 26)
    container.BackgroundTransparency = 0.15
    container.ClipsDescendants = true
    container.Active = true
    container.Draggable = true
    container.ZIndex = 55
    container.Parent = ScreenGui
    Instance.new("UICorner", container).CornerRadius = UDim.new(0, 12)

    local stroke = Instance.new("UIStroke", container)
    stroke.Thickness = 2
    stroke.Color = Color3.fromRGB(70, 220, 130)

    local hGrid = Instance.new("Frame", container)
    hGrid.Size = UDim2.new(1, 0, 0, 1)
    hGrid.Position = UDim2.new(0, 0, 0.5, 0)
    hGrid.BackgroundColor3 = Color3.fromRGB(55, 75, 65)
    hGrid.BorderSizePixel = 0
    hGrid.ZIndex = 56

    local vGrid = Instance.new("Frame", container)
    vGrid.Size = UDim2.new(0, 1, 1, 0)
    vGrid.Position = UDim2.new(0.5, 0, 0, 0)
    vGrid.BackgroundColor3 = Color3.fromRGB(55, 75, 65)
    vGrid.BorderSizePixel = 0
    vGrid.ZIndex = 56

    local myDot = Instance.new("Frame", container)
    myDot.Name = "MyGreenDot"
    myDot.Size = UDim2.new(0, 10, 0, 10)
    myDot.AnchorPoint = Vector2.new(0.5, 0.5)
    myDot.Position = UDim2.new(0.5, 0, 0.5, 0)
    myDot.BackgroundColor3 = Color3.fromRGB(50, 255, 95)
    myDot.BorderSizePixel = 0
    myDot.ZIndex = 60
    Instance.new("UICorner", myDot).CornerRadius = UDim.new(1, 0)

    minimapFrame = container

    task.spawn(function()
        local enemyMarkers = {}
        local radarRadiusStuds = 200

        while minimapEnabled and container and container.Parent and not _G.ScriptDestroyed do
            local char = Player.Character
            local myRoot = (phantomRunning and ghostSimulationCube) or (char and char:FindFirstChild("HumanoidRootPart"))
            local cam = workspace.CurrentCamera

            if myRoot and cam then
                local myPos = myRoot.Position
                local camLook = cam.CFrame.LookVector
                local camYaw = math.atan2(-camLook.X, -camLook.Z)

                local seen = {}
                for _, plr in ipairs(Players:GetPlayers()) do
                    if plr ~= Player and plr.Character then
                        local eHrp = plr.Character:FindFirstChild("HumanoidRootPart")
                        local eHum = plr.Character:FindFirstChildOfClass("Humanoid")
                        if eHrp and eHum and eHum.Health > 0 then
                            seen[plr] = true
                            local dot = enemyMarkers[plr]
                            if not dot then
                                dot = Instance.new("Frame", container)
                                dot.Size = UDim2.new(0, 9, 0, 9)
                                dot.AnchorPoint = Vector2.new(0.5, 0.5)
                                dot.BackgroundColor3 = Color3.fromRGB(255, 50, 50)
                                dot.BorderSizePixel = 0
                                dot.ZIndex = 58
                                Instance.new("UICorner", dot).CornerRadius = UDim.new(1, 0)

                                local lbl = Instance.new("TextLabel", dot)
                                lbl.Size = UDim2.new(0, 70, 0, 12)
                                lbl.Position = UDim2.new(0.5, -35, 1, 1)
                                lbl.BackgroundTransparency = 1
                                lbl.Text = plr.DisplayName:sub(1, 8)
                                lbl.TextColor3 = Color3.fromRGB(255, 190, 190)
                                lbl.Font = Enum.Font.SourceSansBold
                                lbl.TextSize = 10
                                lbl.ZIndex = 59

                                enemyMarkers[plr] = dot
                            end

                            local relX = eHrp.Position.X - myPos.X
                            local relZ = eHrp.Position.Z - myPos.Z

                            local cosA = math.cos(-camYaw)
                            local sinA = math.sin(-camYaw)
                            local rotX = relX * cosA - relZ * sinA
                            local rotZ = relX * sinA + relZ * cosA

                            local normX = math.clamp(rotX / radarRadiusStuds, -0.92, 0.92)
                            local normY = math.clamp(rotZ / radarRadiusStuds, -0.92, 0.92)

                            dot.Visible = true
                            dot.Position = UDim2.new(0.5 + (normX * 0.46), 0, 0.5 + (normY * 0.46), 0)
                        end
                    end
                end

                for plr, dot in pairs(enemyMarkers) do
                    if not seen[plr] then
                        if dot and dot.Parent then dot:Destroy() end
                        enemyMarkers[plr] = nil
                    end
                end
            end
            RunService.RenderStepped:Wait()
        end

        if container and container.Parent then container:Destroy() end
    end)
end)

local stealthEyeFrame = nil

createToggle(visualsPage, "👁 Индикатор скрытности (Видят ли меня враги)", function(Value)
    stealthEyeEnabled = Value
    if stealthEyeFrame then
        pcall(function() stealthEyeFrame:Destroy() end)
        stealthEyeFrame = nil
    end

    if not stealthEyeEnabled then return end
    if ScreenGui then ScreenGui.DisplayOrder = 999 end

    local box = Instance.new("Frame")
    box.Name = "PromptStealthEye"
    box.Size = UDim2.new(0, 52, 0, 52)
    box.Position = UDim2.new(1, -112, 0.25, 0)
    box.BackgroundColor3 = Color3.fromRGB(25, 28, 34)
    box.Active = true
    box.Draggable = true
    box.ZIndex = 60
    box.Parent = ScreenGui
    Instance.new("UICorner", box).CornerRadius = UDim.new(1, 0)

    local stroke = Instance.new("UIStroke", box)
    stroke.Thickness = 2.5
    stroke.Color = Color3.fromRGB(130, 130, 130)

    local eyeLbl = Instance.new("TextLabel", box)
    eyeLbl.Size = UDim2.new(1, 0, 1, 0)
    eyeLbl.BackgroundTransparency = 1
    eyeLbl.Text = "👁"
    eyeLbl.TextColor3 = Color3.fromRGB(150, 150, 150)
    eyeLbl.Font = Enum.Font.SourceSansBold
    eyeLbl.TextSize = 26
    eyeLbl.ZIndex = 61

    local slashLine = Instance.new("Frame", box)
    slashLine.Name = "SlashBar"
    slashLine.Size = UDim2.new(0, 42, 0, 3.5)
    slashLine.Position = UDim2.new(0.5, -21, 0.5, -2)
    slashLine.Rotation = -45
    slashLine.BackgroundColor3 = Color3.fromRGB(235, 60, 60)
    slashLine.BorderSizePixel = 0
    slashLine.Visible = true
    slashLine.ZIndex = 62
    Instance.new("UICorner", slashLine).CornerRadius = UDim.new(1, 0)

    stealthEyeFrame = box

    task.spawn(function()
        while stealthEyeEnabled and box and box.Parent and not _G.ScriptDestroyed do
            local char = Player.Character
            local myRoot = (phantomRunning and ghostSimulationCube) or (char and char:FindFirstChild("HumanoidRootPart"))
            local status = 0

            if myRoot then
                local myPos = myRoot.Position + Vector3.new(0, 1.5, 0)
                local ignoreList = {}
                if char then table.insert(ignoreList, char) end
                if ghostVisualClone then table.insert(ignoreList, ghostVisualClone) end
                if ghostSimulationCube then table.insert(ignoreList, ghostSimulationCube) end

                for _, plr in ipairs(Players:GetPlayers()) do
                    if plr ~= Player and plr.Character then
                        local eHead = plr.Character:FindFirstChild("Head")
                        local eHrp = plr.Character:FindFirstChild("HumanoidRootPart")
                        local eHum = plr.Character:FindFirstChildOfClass("Humanoid")

                        if eHead and eHrp and eHum and eHum.Health > 0 then
                            local dist = (eHead.Position - myPos).Magnitude
                            if dist <= 220 then
                                local fullIgnore = {plr.Character}
                                for _, item in ipairs(ignoreList) do table.insert(fullIgnore, item) end

                                local toMe = myPos - eHead.Position
                                local dot = eHead.CFrame.LookVector:Dot(toMe.Unit)
                                if dot > -0.1 then
                                    local ray = Ray.new(eHead.Position, toMe)
                                    local hit = workspace:FindPartOnRayWithIgnoreList(ray, fullIgnore)
                                    if not hit or not hit.CanCollide or hit.Transparency >= 0.6 then
                                        status = 2
                                        break
                                    end
                                end

                                if status < 1 and dist <= 150 then
                                    local cam3pPos = eHead.Position - (eHrp.CFrame.LookVector * 12) + Vector3.new(0, 5, 0)
                                    local ray3p = Ray.new(cam3pPos, myPos - cam3pPos)
                                    local hit3p = workspace:FindPartOnRayWithIgnoreList(ray3p, fullIgnore)
                                    if not hit3p or not hit3p.CanCollide or hit3p.Transparency >= 0.6 then
                                        status = 1
                                    end
                                end
                            end
                        end
                    end
                end
            end

            if status == 2 then
                slashLine.Visible = false
                eyeLbl.TextColor3 = Color3.fromRGB(255, 65, 65)
                stroke.Color = Color3.fromRGB(255, 65, 65)
                box.BackgroundColor3 = Color3.fromRGB(55, 20, 20)
            elseif status == 1 then
                slashLine.Visible = false
                eyeLbl.TextColor3 = Color3.fromRGB(255, 215, 60)
                stroke.Color = Color3.fromRGB(255, 215, 60)
                box.BackgroundColor3 = Color3.fromRGB(50, 42, 18)
            else
                slashLine.Visible = true
                eyeLbl.TextColor3 = Color3.fromRGB(150, 150, 150)
                stroke.Color = Color3.fromRGB(110, 110, 110)
                box.BackgroundColor3 = Color3.fromRGB(25, 28, 34)
            end

            task.wait(0.2)
        end

        if box and box.Parent then box:Destroy() end
    end)
end)

createToggle(visualsPage, "💎 Подсветка предметов и лута на карте", function(Value)
    lootEspEnabled = Value
    if not lootEspEnabled then 
        for _, obj in ipairs(workspace:GetDescendants()) do
            local hl = obj:FindFirstChild("PromptLootESP")
            if hl then hl:Destroy() end
        end
        return 
    end

    -- ШИРОКИЙ ПОИСК ЛУТА: по названиям (подстроки и точные имена), по структуре
    -- (ProximityPrompt / ClickDetector / выброшенные Tool / мелкие Touch-пикапы) и по папкам-контейнерам.
    local nameWords = {
        "coin", "cash", "gem", "drop", "item", "loot", "money", "gold", "silver", "crate", "chest",
        "pickup", "pick_up", "pick up", "collect", "treasure", "reward", "gift", "present", "token",
        "ticket", "keycard", "ammo", "medkit", "firstaid", "first aid", "health", "potion", "supply",
        "supplies", "resource", "crystal", "diamond", "scrap", "material", "artifact", "relic", "bonus",
        "powerup", "power up", "dollar", "stash", "cache", "valuable", "jewel", "ruby", "emerald",
        "sapphire", "bandage", "bullet", "armor", "battery", "fuel", "blueprint", "weapon", "pistol",
        "rifle", "shotgun", "grenade", "loot", "booster", "upgrade", "orbs", "shard", "fragment", "soul", "medkit",
    }
    local exactWords = {
        key = true, keys = true, orb = true, star = true, egg = true, bag = true, ore = true,
        box = true, tool = true, gun = true, bill = true, pill = true, pills = true, pearl = true,
        heart = true, apple = true, bone = true, wood = true, stone = true, iron = true, food = true
    }
    local containerWords = {"loot", "drop", "item", "pickup", "collect", "treasure", "reward", "coin", "cash", "money"}
    local excludeWords = {
        "door", "gate", "wall", "floor", "ground", "baseplate", "terrain", "window", "fence", "roof",
        "stair", "ladder", "seat", "chair", "button", "lever", "elevator", "teleport", "portal", "shop",
        "store", "vendor", "npc", "cashier", "register", "kill", "lava", "checkpoint", "tree", "leaf",
        "grass", "road", "bridge", "spawnlocation"
    }
    local promptSkipWords = {
        "door", "enter", "exit", "talk", "sit", "buy", "sell", "trade", "ride", "drive", "leave",
        "shop", "teleport", "elevator", "speak", "dialog", "quest", "button", "lever", "switch"
    }

    local function hasAny(str, list)
        for _, w in ipairs(list) do
            if str:find(w, 1, true) then return true end
        end
        return false
    end

    local function baseName(s)
        return (s:lower():gsub("[%d%s_%-%.]+$", ""))
    end

    local function matchesName(rawName)
        local n = rawName:lower()
        if n:sub(1, 6) == "prompt" or n:sub(1, 8) == "phantom_" then return false end
        if hasAny(n, excludeWords) then return false end
        if hasAny(n, nameWords) then return true end
        return exactWords[baseName(rawName)] == true
    end

    local function isSmallModel(m)
        local ok, size = pcall(function() return m:GetExtentsSize() end)
        return ok and math.max(size.X, size.Y, size.Z) < 30
    end

    local function insideCharacter(inst)
        if inst:IsA("Model") and inst:FindFirstChildOfClass("Humanoid") then return true end
        local p = inst.Parent
        while p and p ~= workspace do
            if p:IsA("Model") and p:FindFirstChildOfClass("Humanoid") then return true end
            p = p.Parent
        end
        return false
    end

    -- возвращает объект, который нужно подсветить (или nil)
    local function getLootTarget(obj)
        if obj:IsA("ProximityPrompt") or obj:IsA("ClickDetector") then
            local t = obj.Parent
            if t and t:IsA("Attachment") then t = t.Parent end
            if not t or not (t:IsA("BasePart") or t:IsA("Model")) then return nil end
            local tn = t.Name:lower()
            if tn:sub(1, 6) == "prompt" or hasAny(tn, excludeWords) then return nil end
            if obj:IsA("ProximityPrompt") then
                local txt = ((obj.ActionText or "") .. " " .. (obj.ObjectText or "")):lower()
                if hasAny(txt, promptSkipWords) then return nil end
            end
            return t
        end

        if obj:IsA("Tool") then return obj end

        if obj:IsA("BasePart") or obj:IsA("Model") then
            local parent = obj.Parent
            if matchesName(obj.Name) then
                if obj:IsA("Model") and not isSmallModel(obj) then return nil end
                if obj:IsA("BasePart") and parent and parent:IsA("Model") and parent ~= workspace
                    and matchesName(parent.Name) and isSmallModel(parent) then
                    return nil -- подсветится вся модель целиком
                end
                return obj
            end

            if parent and parent ~= workspace and (parent:IsA("Folder") or parent:IsA("Model")) then
                local pn = parent.Name:lower()
                if hasAny(pn, containerWords) and not hasAny(obj.Name:lower(), excludeWords) then
                    if obj:IsA("BasePart") and parent:IsA("Model") and isSmallModel(parent) then return nil end
                    return obj
                end
            end

            if obj:IsA("BasePart") and not obj.CanCollide and obj.Size.Magnitude < 8
                and obj:FindFirstChildOfClass("TouchTransmitter") and not hasAny(obj.Name:lower(), excludeWords) then
                return obj
            end
        end
        return nil
    end

    local function posOf(inst)
        if inst:IsA("BasePart") then return inst.Position end
        if inst:IsA("Model") then return inst:GetPivot().Position end
        local part = inst:FindFirstChild("Handle") or inst:FindFirstChildWhichIsA("BasePart", true)
        return part and part.Position or nil
    end

    local function adorneeOf(inst)
        if inst:IsA("Tool") then
            return inst:FindFirstChild("Handle") or inst:FindFirstChildWhichIsA("BasePart", true)
        end
        return inst
    end

    local MAX_HIGHLIGHTS = 30 -- Roblox рисует не больше ~31 Highlight одновременно, поэтому берём ближайшие
    local lootHL = {}
    local notLoot = setmetatable({}, {__mode = "k"})

    task.spawn(function()
        while lootEspEnabled and not _G.ScriptDestroyed do
            if not _G.ScriptPaused then
                local char = Player.Character
                local root = char and char:FindFirstChild("HumanoidRootPart")
                local origin = root and root.Position or workspace.CurrentCamera.CFrame.Position

                local found, list, counter = {}, {}, 0
                for _, obj in ipairs(workspace:GetDescendants()) do
                    counter = counter + 1
                    if counter % 2500 == 0 then
                        task.wait()
                        if not lootEspEnabled then break end
                    end
                    if not notLoot[obj] then
                        local ok, t = pcall(getLootTarget, obj)
                        if ok and t then
                            if not found[t] and t.Parent and not insideCharacter(t) then
                                local pos = posOf(t)
                                if pos then
                                    found[t] = true
                                    table.insert(list, {inst = t, d = (pos - origin).Magnitude})
                                end
                            end
                        else
                            notLoot[obj] = true
                        end
                    end
                end

                if lootEspEnabled then
                    table.sort(list, function(a, b) return a.d < b.d end)
                    local keep = {}
                    for i = 1, math.min(#list, MAX_HIGHLIGHTS) do
                        local t = list[i].inst
                        keep[t] = true
                        local old = lootHL[t]
                        if not old or not old.Parent then
                            local adornee = adorneeOf(t)
                            if adornee then
                                local hl = Instance.new("Highlight")
                                hl.Name = "PromptLootESP"
                                hl.Adornee = adornee
                                hl.FillColor = Color3.fromRGB(60, 220, 255)
                                hl.OutlineColor = Color3.fromRGB(255, 255, 255)
                                hl.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop
                                hl.Parent = t
                                lootHL[t] = hl
                            end
                        end
                    end
                    for t, hl in pairs(lootHL) do
                        if not keep[t] then
                            if hl then pcall(function() hl:Destroy() end) end
                            lootHL[t] = nil
                        end
                    end
                end
            end
            task.wait(1.5)
        end

        for t, hl in pairs(lootHL) do
            if hl then pcall(function() hl:Destroy() end) end
            lootHL[t] = nil
        end
    end)
end)

end
-- =========================================================
-- ----- КОНЕЦ ЧАСТИ 7.4 -----
-- =========================================================
-- =========================================================
-- ----- НАЧАЛО ЧАСТИ 8.1 -----
-- =========================================================
do
do
local autoClickerEnabled = false
local autoCollectEnabled = false
local instantPromptEnabled = false

local autoClickToggleObj = nil
local autoClickBanner = nil
local autoClickTargetMarker = nil

local function cleanupAutoClickerUI()
    if autoClickBanner then pcall(function() autoClickBanner:Destroy() end) autoClickBanner = nil end
    if autoClickTargetMarker then pcall(function() autoClickTargetMarker:Destroy() end) autoClickTargetMarker = nil end
end

local function isMainMenuVisible()
    if not ScreenGui then return false end
    for _, child in ipairs(ScreenGui:GetChildren()) do
        if child:IsA("Frame") and child.Size.X.Offset >= 300 and child.Size.Y.Offset >= 200 then
            return child.Visible
        end
    end
    return false
end

autoClickToggleObj = createToggle(farmPage, "🖱 Автокликер (Тапни точку после сворачивания -)", function(Value)
    autoClickerEnabled = Value
    cleanupAutoClickerUI()

    if not autoClickerEnabled then return end
    if ScreenGui then ScreenGui.DisplayOrder = 999 end

    local banner = Instance.new("TextLabel")
    banner.Name = "AutoClickHintBanner"
    banner.Size = UDim2.new(0, 310, 0, 36)
    banner.Position = UDim2.new(0.5, -155, 0.04, 0)
    banner.BackgroundColor3 = Color3.fromRGB(25, 30, 38)
    banner.Text = "🖱 Сверни меню (-) и нажми в точку клика"
    banner.TextColor3 = Color3.fromRGB(255, 220, 60)
    banner.Font = Enum.Font.SourceSansBold
    banner.TextSize = 14
    banner.ZIndex = 80
    banner.Parent = ScreenGui
    Instance.new("UICorner", banner).CornerRadius = UDim.new(0, 8)

    local stroke = Instance.new("UIStroke", banner)
    stroke.Thickness = 2
    stroke.Color = Color3.fromRGB(255, 200, 50)
    autoClickBanner = banner

    task.spawn(function()
        local UIS = game:GetService("UserInputService")
        local VIM = game:GetService("VirtualInputManager")
        local GuiService = game:GetService("GuiService")

        while autoClickerEnabled and isMainMenuVisible() and not _G.ScriptDestroyed do
            task.wait(0.1)
        end
        if not autoClickerEnabled or _G.ScriptDestroyed then
            cleanupAutoClickerUI()
            return
        end

        if banner and banner.Parent then
            banner.Text = "🎯 Нажми на экране место, куда кликать!"
            banner.TextColor3 = Color3.fromRGB(100, 255, 130)
            stroke.Color = Color3.fromRGB(80, 220, 120)
        end

        local targetPos = nil
        local tapConn
        tapConn = UIS.InputBegan:Connect(function(input)
            if not autoClickerEnabled or targetPos then return end
            if isMainMenuVisible() then return end
            if input.UserInputType == Enum.UserInputType.Touch or input.UserInputType == Enum.UserInputType.MouseButton1 then
                targetPos = Vector2.new(input.Position.X, input.Position.Y)
            end
        end)

        while autoClickerEnabled and not targetPos and not _G.ScriptDestroyed do
            if isMainMenuVisible() then
                autoClickerEnabled = false
                if autoClickToggleObj and autoClickToggleObj.Set then autoClickToggleObj.Set(false) end
                break
            end
            task.wait(0.05)
        end

        if tapConn then tapConn:Disconnect() end

        if not autoClickerEnabled or not targetPos or _G.ScriptDestroyed then
            cleanupAutoClickerUI()
            return
        end

        if banner and banner.Parent then
            pcall(function() banner:Destroy() end)
            autoClickBanner = nil
        end

        local marker = Instance.new("Frame")
        marker.Name = "AutoClickTargetDot"
        marker.Size = UDim2.new(0, 26, 0, 26)
        marker.AnchorPoint = Vector2.new(0.5, 0.5)
        marker.Position = UDim2.new(0, targetPos.X, 0, targetPos.Y)
        marker.BackgroundColor3 = Color3.fromRGB(50, 255, 100)
        marker.BackgroundTransparency = 0.55
        marker.ZIndex = 80
        marker.Parent = ScreenGui
        Instance.new("UICorner", marker).CornerRadius = UDim.new(1, 0)

        local mStroke = Instance.new("UIStroke", marker)
        mStroke.Thickness = 2
        mStroke.Color = Color3.fromRGB(255, 255, 255)
        autoClickTargetMarker = marker

        local inset = GuiService:GetGuiInset()
        local clickX = targetPos.X + inset.X
        local clickY = targetPos.Y + inset.Y

        while autoClickerEnabled and not _G.ScriptDestroyed do
            if isMainMenuVisible() then
                autoClickerEnabled = false
                if autoClickToggleObj and autoClickToggleObj.Set then autoClickToggleObj.Set(false) end
                break
            end

            if not _G.ScriptPaused then
                local char = Player.Character
                local tool = char and char:FindFirstChildOfClass("Tool")
                if tool then pcall(function() tool:Activate() end) end

                pcall(function()
                    VIM:SendMouseButtonEvent(clickX, clickY, 0, true, game, 1)
                    task.wait(0.02)
                    VIM:SendMouseButtonEvent(clickX, clickY, 0, false, game, 1)
                end)
            end
            task.wait(0.1)
        end

        cleanupAutoClickerUI()
    end)
end)

-- вот тут находится конец 1 блока (части 8.1)
createToggle(farmPage, "🧲 Автосбор предметов и монет вокруг", function(Value)
    autoCollectEnabled = Value
    if not autoCollectEnabled then return end

    task.spawn(function()
        while autoCollectEnabled and not _G.ScriptDestroyed do
            if not _G.ScriptPaused then
                local char = Player.Character
                local hrp = (phantomRunning and ghostSimulationCube) or (char and char:FindFirstChild("HumanoidRootPart"))
                if hrp then
                    for _, obj in ipairs(workspace:GetDescendants()) do
                        if obj:IsA("TouchTransmitter") and obj.Parent and obj.Parent:IsA("BasePart") then
                            local part = obj.Parent
                            local lowerName = part.Name:lower()
                            local parentName = part.Parent and part.Parent.Name:lower() or ""
                            if lowerName:find("coin") or lowerName:find("cash") or lowerName:find("drop")
                                or lowerName:find("gem") or lowerName:find("orb") or lowerName:find("star")
                                or lowerName:find("reward") or lowerName:find("collect") or parentName:find("drop") then
                                if (part.Position - hrp.Position).Magnitude <= 120 then
                                    pcall(function()
                                        firetouchinterest(hrp, part, 0)
                                        firetouchinterest(hrp, part, 1)
                                    end)
                                end
                            end
                        end
                    end
                end
            end
            task.wait(0.3)
        end
    end)
end)

local savedPromptStats = {}

local function applyInstantPrompt(prompt)
    if not prompt or not prompt:IsA("ProximityPrompt") then return end
    if not savedPromptStats[prompt] then
        savedPromptStats[prompt] = {
            Hold = prompt.HoldDuration,
            Dist = prompt.MaxActivationDistance
        }
    end
    prompt.HoldDuration = 0
    if prompt.MaxActivationDistance < 25 then
        prompt.MaxActivationDistance = 25
    end
end

createToggle(movePage, "⚡ Мгновенное взаимодействие (Без удержания)", function(Value)
    instantPromptEnabled = Value
    if instantPromptEnabled then
        for _, obj in ipairs(workspace:GetDescendants()) do
            if obj:IsA("ProximityPrompt") then applyInstantPrompt(obj) end
        end

        local promptConn
        promptConn = workspace.DescendantAdded:Connect(function(obj)
            if not instantPromptEnabled or _G.ScriptDestroyed then
                if promptConn then promptConn:Disconnect() end
                return
            end
            if obj:IsA("ProximityPrompt") then
                task.defer(function()
                    if instantPromptEnabled and obj and obj.Parent then applyInstantPrompt(obj) end
                end)
            end
        end)

        task.spawn(function()
            while instantPromptEnabled and not _G.ScriptDestroyed do task.wait(1) end
            if promptConn then promptConn:Disconnect() end
            for prompt, orig in pairs(savedPromptStats) do
                if prompt and prompt.Parent then
                    pcall(function()
                        prompt.HoldDuration = orig.Hold
                        prompt.MaxActivationDistance = orig.Dist
                    end)
                end
            end
            savedPromptStats = {}
        end)
    else
        for prompt, orig in pairs(savedPromptStats) do
            if prompt and prompt.Parent then
                pcall(function()
                    prompt.HoldDuration = orig.Hold
                    prompt.MaxActivationDistance = orig.Dist
                end)
            end
        end
        savedPromptStats = {}
    end
end)

end
-- =========================================================
-- ----- КОНЕЦ ЧАСТИ 8.1 -----
-- =========================================================
-- =========================================================
-- ----- НАЧАЛО ЧАСТИ 8.2 -----
-- =========================================================
do

local autoMathSolverEnabled = false

local function evaluateMathExpression(rawText)
    if type(rawText) ~= "string" or #rawText > 160 then return nil, nil end
    local s = rawText:gsub("×", "*"):gsub("[хХxX]", "*"):gsub("÷", "/"):gsub(":", "/"):gsub(",", ".")
    local pos, len = 1, #s
    local function spaces() while pos <= len and s:sub(pos,pos):match("%s") do pos = pos + 1 end end
    local expression
    local function primary()
        spaces()
        if s:sub(pos,pos) == "(" then
            pos = pos + 1; local v = expression(); spaces()
            if s:sub(pos,pos) ~= ")" then error("Ожидалась )", 0) end
            pos = pos + 1; return v
        end
        local name = s:sub(pos):match("^([%a_]+)")
        if name then
            pos = pos + #name; name = name:lower()
            local constants = {pi = math.pi, e = math.exp(1)}
            if constants[name] then return constants[name] end
            local funcs = {sqrt=math.sqrt, abs=math.abs, sin=math.sin, cos=math.cos,
                tan=math.tan, floor=math.floor, ceil=math.ceil, log=math.log}
            local f = funcs[name]
            if not f then error("Неизвестная функция/константа: " .. name, 0) end
            spaces(); if s:sub(pos,pos) ~= "(" then error("После функции нужна скобка", 0) end
            pos = pos + 1; local v = expression(); spaces()
            if s:sub(pos,pos) ~= ")" then error("Ожидалась )", 0) end
            pos = pos + 1; return f(v)
        end
        local rest = s:sub(pos)
        local token = rest:match("^(%d+%.?%d*)") or rest:match("^(%.%d+")
        if not token then error("Ожидалось число", 0) end
        pos = pos + #token
        return tonumber(token)
    end
    local function power()
        local v = primary(); spaces()
        if s:sub(pos,pos) == "^" then pos = pos + 1; v = v ^ power() end
        return v
    end
    local function unary()
        spaces(); local c = s:sub(pos,pos)
        if c == "+" then pos=pos+1; return unary() end
        if c == "-" then pos=pos+1; return -unary() end
        return power()
    end
    local function term()
        local v = unary()
        while true do
            spaces(); local op=s:sub(pos,pos)
            if op ~= "*" and op ~= "/" then break end
            pos=pos+1; local r=unary()
            if op=="/" and r==0 then error("Деление на ноль",0) end
            v = op=="*" and v*r or v/r
        end
        return v
    end
    expression = function()
        local v=term()
        while true do
            spaces(); local op=s:sub(pos,pos)
            if op~="+" and op~="-" then break end
            pos=pos+1; local r=term(); v=op=="+" and v+r or v-r
        end
        return v
    end
    local ok, value = pcall(function()
        local v=expression(); spaces()
        if pos<=len then error("Лишние символы",0) end
        if type(v)~="number" or v~=v or math.abs(v)==math.huge or math.abs(v)>1e15 then error("Результат вне диапазона",0) end
        return v
    end)
    if not ok then return nil,nil end
    local nearest = value >= 0 and math.floor(value + 0.5) or math.ceil(value - 0.5)
    local formatted = math.abs(value-nearest)<1e-10 and tostring(nearest) or string.format("%.6g",value)
    return s, formatted
end

local mathOverlayBanner = nil
local worldMathBillboards = {}

local function clearWorldMathBillboards()
    for _, bbg in ipairs(worldMathBillboards) do
        if bbg and bbg.Parent then pcall(function() bbg:Destroy() end) end
    end
    worldMathBillboards = {}
end

createToggle(visualsPage, "🧮 Авто-решатель примеров (Экран + Мир)", function(Value)
    autoMathSolverEnabled = Value
    if mathOverlayBanner then
        pcall(function() mathOverlayBanner:Destroy() end)
        mathOverlayBanner = nil
    end
    clearWorldMathBillboards()

    if not autoMathSolverEnabled then return end
    if ScreenGui then ScreenGui.DisplayOrder = 999 end

    local banner = Instance.new("TextLabel")
    banner.Name = "PromptMathBanner"
    banner.Size = UDim2.new(0, 220, 0, 38)
    banner.Position = UDim2.new(0.5, -110, 0.04, 0)
    banner.BackgroundColor3 = Color3.fromRGB(25, 30, 35)
    banner.Text = "🧮 Жду пример..."
    banner.TextColor3 = Color3.fromRGB(100, 255, 130)
    banner.Font = Enum.Font.SourceSansBold
    banner.TextSize = 16
    banner.Active = true
    banner.Draggable = true
    banner.ZIndex = 70
    banner.Parent = ScreenGui
    Instance.new("UICorner", banner).CornerRadius = UDim.new(0, 8)

    local stroke = Instance.new("UIStroke", banner)
    stroke.Thickness = 2
    stroke.Color = Color3.fromRGB(80, 220, 120)

    mathOverlayBanner = banner

    task.spawn(function()
        while autoMathSolverEnabled and not _G.ScriptDestroyed do
            if not _G.ScriptPaused then
                local foundExpr, foundAns = nil, nil

                local pGui = Player:FindFirstChild("PlayerGui")
                if pGui then
                    for _, uiObj in ipairs(pGui:GetDescendants()) do
                        if (uiObj:IsA("TextLabel") or uiObj:IsA("TextButton")) and uiObj.Visible then
                            local txt = uiObj.Text
                            if txt and #txt >= 3 and #txt <= 40 and not txt:find("🧮") then
                                local expr, ans = evaluateMathExpression(txt)
                                if expr and ans then
                                    foundExpr, foundAns = expr, ans
                                    break
                                end
                            end
                        end
                    end
                end

                local char = Player.Character
                local myRoot = (phantomRunning and ghostSimulationCube) or (char and char:FindFirstChild("HumanoidRootPart"))
                if myRoot then
                    for _, obj in ipairs(workspace:GetDescendants()) do
                        if obj:IsA("TextLabel") and obj.Visible then
                            local guiHolder = obj:FindFirstAncestorWhichIsA("SurfaceGui") or obj:FindFirstAncestorWhichIsA("BillboardGui")
                            local adorneePart = guiHolder and (guiHolder.Adornee or guiHolder.Parent)
                            if adorneePart and adorneePart:IsA("BasePart") then
                                if (adorneePart.Position - myRoot.Position).Magnitude <= 130 then
                                    local expr, ans = evaluateMathExpression(obj.Text)
                                    if expr and ans then
                                        foundExpr, foundAns = expr, ans
                                        if not adorneePart:FindFirstChild("PromptWorldMathHint") then
                                            local hint = Instance.new("BillboardGui")
                                            hint.Name = "PromptWorldMathHint"
                                            hint.Adornee = adorneePart
                                            hint.Size = UDim2.new(0, 140, 0, 34)
                                            hint.StudsOffset = Vector3.new(0, (adorneePart.Size.Y * 0.5) + 2.2, 0)
                                            hint.AlwaysOnTop = true
                                            hint.Parent = adorneePart

                                            local hLbl = Instance.new("TextLabel", hint)
                                            hLbl.Size = UDim2.new(1, 0, 1, 0)
                                            hLbl.BackgroundColor3 = Color3.fromRGB(20, 140, 55)
                                            hLbl.Text = "= " .. ans
                                            hLbl.TextColor3 = Color3.fromRGB(255, 255, 255)
                                            hLbl.Font = Enum.Font.SourceSansBold
                                            hLbl.TextSize = 18
                                            Instance.new("UICorner", hLbl).CornerRadius = UDim.new(0, 6)

                                            table.insert(worldMathBillboards, hint)
                                        else
                                            local existingLbl = adorneePart.PromptWorldMathHint:FindFirstChildOfClass("TextLabel")
                                            if existingLbl then existingLbl.Text = "= " .. ans end
                                        end
                                    end
                                end
                            end
                        end
                    end
                end

                if foundExpr and foundAns and banner and banner.Parent then
                    banner.Text = "🧮 " .. foundExpr .. " = " .. foundAns
                    banner.TextColor3 = Color3.fromRGB(100, 255, 130)
                elseif banner and banner.Parent then
                    banner.Text = "🧮 Жду пример..."
                    banner.TextColor3 = Color3.fromRGB(180, 180, 180)
                end
            end
            task.wait(0.35)
        end

        if mathOverlayBanner then
            pcall(function() mathOverlayBanner:Destroy() end)
            mathOverlayBanner = nil
        end
        clearWorldMathBillboards()
    end)
end)

local calcBaseTitle = "🔢 Калькулятор (ответ рядом с заголовком)"
local calcParaFrame = createParagraph(farmPage, calcBaseTitle, "Введите пример ниже (например: 16*3)")

local calcTitleLabel = nil
local calcContentLabel = nil
local searchTarget = calcParaFrame or farmPage
for _, ch in ipairs(searchTarget:GetDescendants()) do
    if ch:IsA("TextLabel") then
        if ch.Text == calcBaseTitle then
            calcTitleLabel = ch
        elseif ch.Text == "Введите пример ниже (например: 16*3)" then
            calcContentLabel = ch
        end
    end
end

local function updateCalcDisplay(answerText, exprText)
    if not calcTitleLabel then return end
    if answerText then
        calcTitleLabel.Text = calcBaseTitle .. "  ->  ОТВЕТ: " .. answerText
        if calcContentLabel then
            calcContentLabel.Text = "Пример: " .. (exprText or "")
        end
    else
        calcTitleLabel.Text = calcBaseTitle
        if calcContentLabel then
            calcContentLabel.Text = "Введите пример ниже (например: 16*3)"
        end
    end
end

createInput(farmPage, "Ввести пример вручную", "Пример: 16*3 или (12+8)/4...", function(Text)
    if not Text or Text == "" then
        updateCalcDisplay(nil, nil)
        return
    end
    local expr, ans = evaluateMathExpression(Text)
    if expr and ans then
        updateCalcDisplay(ans, expr)
    else
        updateCalcDisplay("Ошибка", Text)
    end
end)

-- ❄️ ЗАВИСАНИЕ В ВОЗДУХЕ (AIR FREEZE)
local airFreezeEnabled = false
local airFreezeConnection = nil

createToggle(movePage, "❄️ Зависание в воздухе (Air Freeze)", function(Value)
    airFreezeEnabled = Value
    
    if airFreezeConnection then
        airFreezeConnection:Disconnect()
        airFreezeConnection = nil
    end

    local char = Player.Character
    local hrp = char and char:FindFirstChild("HumanoidRootPart")
    local hum = char and char:FindFirstChildOfClass("Humanoid")

    if airFreezeEnabled then
        if hrp then
            hrp.Anchored = true
            hrp.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
            hrp.AssemblyAngularVelocity = Vector3.new(0, 0, 0)
        end
        if hum then
            hum.PlatformStand = true
            local animator = hum:FindFirstChildOfClass("Animator")
            if animator then
                for _, track in pairs(animator:GetPlayingAnimationTracks()) do
                    track.Speed = 0
                end
            end
        end

        airFreezeConnection = RunService.Heartbeat:Connect(function()
            if not airFreezeEnabled or _G.ScriptDestroyed then return end
            local c = Player.Character
            local h = c and c:FindFirstChild("HumanoidRootPart")
            local u = c and c:FindFirstChildOfClass("Humanoid")
            
            if h then
                h.Anchored = true
                h.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
            end
            if u then
                u.PlatformStand = true
            end
        end)
    else
        if hrp then
            hrp.Anchored = false
            hrp.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
        end
        if hum then
            hum.PlatformStand = false
            hum:ChangeState(Enum.HumanoidStateType.GettingUp)
            local animator = hum:FindFirstChildOfClass("Animator")
            if animator then
                for _, track in pairs(animator:GetPlayingAnimationTracks()) do
                    track.Speed = 1
                end
            end
        end
    end
end)

Player.CharacterRemoving:Connect(function()
    if airFreezeConnection then
        airFreezeConnection:Disconnect()
        airFreezeConnection = nil
    end
    airFreezeEnabled = false
end)

-- =========================================================
-- 🖤 ЧЕРНИЛЬНЫЙ ДАЙВИНГ (INK DIVE + ПОЛУПРОЗРАЧНАЯ КУКЛА)
-- =========================================================
local bendyHudEnabled = false
local bendyDiveActive = false
local bendyProxyRig = nil
local bendyConnStepped = nil
local bendyConnHeartbeat = nil
local bendyHudGui = nil
local bendyHudBtnRef = nil

local function stopBendyDive(teleportBack)
    if bendyConnStepped then bendyConnStepped:Disconnect() bendyConnStepped = nil end
    if bendyConnHeartbeat then bendyConnHeartbeat:Disconnect() bendyConnHeartbeat = nil end

    local char = Player.Character
    local realHrp = char and char:FindFirstChild("HumanoidRootPart")
    local realHum = char and char:FindFirstChildOfClass("Humanoid")

    if bendyProxyRig then
        local pHrp = bendyProxyRig:FindFirstChild("HumanoidRootPart")
        if teleportBack and realHrp and pHrp then
            realHrp.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
            realHrp.CFrame = pHrp.CFrame + Vector3.new(0, 1.5, 0)
        end
        pcall(function() bendyProxyRig:Destroy() end)
        bendyProxyRig = nil
    end

    if char then
        for _, part in ipairs(char:GetDescendants()) do
            if part:IsA("BasePart") then
                part.CanCollide = (part.Name == "HumanoidRootPart" or part.Name == "Torso" or part.Name == "UpperTorso" or part.Name == "LowerTorso")
            end
        end
    end

    if realHum then
        realHum.PlatformStand = false
        realHum:ChangeState(Enum.HumanoidStateType.GettingUp)
        workspace.CurrentCamera.CameraSubject = realHum
    end
end

local function startBendyDive(hudBtn)
    local char = Player.Character
    local realHrp = char and char:FindFirstChild("HumanoidRootPart")
    local realHum = char and char:FindFirstChildOfClass("Humanoid")
    if not realHrp or not realHum then return end

    local walkAnim, jumpAnim
    local origAnim = char:FindFirstChild("Animate")
    if origAnim then
        local r = origAnim:FindFirstChild("run") or origAnim:FindFirstChild("walk")
        if r and r:FindFirstChildOfClass("Animation") then
            walkAnim = r:FindFirstChildOfClass("Animation"):Clone()
        end
        local j = origAnim:FindFirstChild("jump")
        if j and j:FindFirstChildOfClass("Animation") then
            jumpAnim = j:FindFirstChildOfClass("Animation"):Clone()
        end
    end

    char.Archivable = true
    local proxy = char:Clone()
    char.Archivable = false
    proxy.Name = "BendySurfacePuppet"

    for _, obj in ipairs(proxy:GetDescendants()) do
        if obj:IsA("LocalScript") or obj:IsA("Script") or obj:IsA("ForceField") then
            obj:Destroy()
        elseif obj:IsA("BasePart") then
            obj.Anchored = false
            obj.Material = Enum.Material.ForceField
            obj.Color = Color3.fromRGB(35, 35, 45)
            obj.Transparency = (obj.Name == "HumanoidRootPart") and 1 or 0.55
            obj.CanCollide = (obj.Name == "HumanoidRootPart" or obj.Name == "Torso" or obj.Name == "UpperTorso" or obj.Name == "LowerTorso")
        elseif obj:IsA("Decal") or obj:IsA("Texture") then
            obj.Transparency = 0.55
        end
    end

    local pHrp = proxy:FindFirstChild("HumanoidRootPart")
    local pHum = proxy:FindFirstChildOfClass("Humanoid")
    if not pHrp or not pHum then
        proxy:Destroy()
        return
    end

    pHum.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.None
    pHum.WalkSpeed = realHum.WalkSpeed
    pHum.JumpPower = realHum.JumpPower
    pHum.UseJumpPower = realHum.UseJumpPower
    pHum.JumpHeight = realHum.JumpHeight
    pHum.AutoRotate = true
    proxy.Parent = workspace
    bendyProxyRig = proxy

    proxy:PivotTo(realHrp.CFrame)
    workspace.CurrentCamera.CameraSubject = pHum

    local animator = pHum:FindFirstChildOfClass("Animator") or Instance.new("Animator", pHum)
    local walkTrack, jumpTrack
    if walkAnim then
        walkAnim.Parent = proxy
        walkTrack = animator:LoadAnimation(walkAnim)
        walkTrack.Looped = true
    end
    if jumpAnim then
        jumpAnim.Parent = proxy
        jumpTrack = animator:LoadAnimation(jumpAnim)
        jumpTrack.Looped = false
    end

    pHum.Running:Connect(function(spd)
        if not walkTrack then return end
        if spd > 1 then
            if not walkTrack.IsPlaying then walkTrack:Play(0.15) end
            walkTrack:AdjustSpeed(spd / 16)
        else
            if walkTrack.IsPlaying then walkTrack:Stop(0.15) end
        end
    end)

    pHum.StateChanged:Connect(function(_, state)
        if not jumpTrack then return end
        if state == Enum.HumanoidStateType.Jumping or state == Enum.HumanoidStateType.Freefall then
            if not jumpTrack.IsPlaying then jumpTrack:Play(0.1) end
        else
            if jumpTrack.IsPlaying then jumpTrack:Stop(0.15) end
        end
    end)

    bendyConnStepped = RunService.Stepped:Connect(function()
        if not bendyDiveActive or not char.Parent then return end
        for _, part in ipairs(char:GetDescendants()) do
            if part:IsA("BasePart") then
                part.CanCollide = false
            end
        end
    end)

    local bob = 0
    bendyConnHeartbeat = RunService.Heartbeat:Connect(function()
        if not bendyDiveActive then return end
        if _G.ScriptDestroyed or not char.Parent or not realHrp.Parent or not proxy.Parent or realHum.Health <= 0 then
            bendyDiveActive = false
            if hudBtn then
                hudBtn.Text = "OFF"
                hudBtn.BackgroundColor3 = Color3.fromRGB(205, 55, 45)
            end
            stopBendyDive(false)
            return
        end

        pHum.WalkSpeed = realHum.WalkSpeed
        pHum:Move(realHum.MoveDirection, false)
        if realHum.Jump then
            pHum.Jump = true
        end

        bob = (bob == 0) and 0.1 or 0
        local voidLimit = workspace.FallenPartsDestroyHeight + 3
        local deepY = math.max(pHrp.Position.Y - 35 + bob, voidLimit)

        realHum:ChangeState(Enum.HumanoidStateType.Physics)
        realHrp.AssemblyLinearVelocity = Vector3.new(0, 0.4, 0)
        realHrp.AssemblyAngularVelocity = Vector3.new(0, 0, 0)
        realHrp.CFrame = CFrame.new(pHrp.Position.X, deepY, pHrp.Position.Z) * (pHrp.CFrame - pHrp.CFrame.Position)
    end)
end

local function destroyBendyHud()
    bendyDiveActive = false
    stopBendyDive(true)
    if bendyHudGui then
        pcall(function() bendyHudGui:Destroy() end)
        bendyHudGui = nil
    end
end

createToggle(mainPage, "🖤 Чернильный дайвинг (Кукла + кнопка OFF/ON)", function(Value)
    bendyHudEnabled = Value
    destroyBendyHud()

    if not bendyHudEnabled then return end

    local hGui = Instance.new("ScreenGui")
    hGui.Name = "PromptBendyDiveHUD"
    hGui.ResetOnSpawn = false
    hGui.Parent = game:GetService("CoreGui") or Player:WaitForChild("PlayerGui")
    bendyHudGui = hGui

    local btn = Instance.new("TextButton")
    btn.Size = UDim2.new(0, 115, 0, 48)
    btn.Position = UDim2.new(1, -135, 0.35, 0)
    btn.BackgroundColor3 = Color3.fromRGB(205, 55, 45)
    btn.TextColor3 = Color3.fromRGB(255, 255, 255)
    btn.Font = Enum.Font.SourceSansBold
    btn.TextSize = 18
    btn.Text = "OFF"
    btn.Active = true
    btn.Draggable = true
    btn.Parent = hGui
    bendyHudBtnRef = btn
    Instance.new("UICorner", btn).CornerRadius = UDim.new(0, 8)

    btn.MouseButton1Click:Connect(function()
        bendyDiveActive = not bendyDiveActive
        if bendyDiveActive then
            btn.Text = "ON"
            btn.BackgroundColor3 = Color3.fromRGB(45, 175, 55)
            startBendyDive(btn)
        else
            btn.Text = "OFF"
            btn.BackgroundColor3 = Color3.fromRGB(205, 55, 45)
            stopBendyDive(true)
        end
    end)
end)


-- =========================================================
-- 🦑 ВЫЛАЗИТЬ ИЗ ЧЕРНИЛЬНОГО ДАЙВИНГА НА УДАР
-- Атакуешь в дайвинге -> тело мгновенно возвращается к кукле (вылез), удар повторяется, ~0.12 с снаружи,
-- затем дайвинг снова включается сам. Кнопка ON/OFF дайвинга остаётся как была (ON не сбрасывается).
-- Удар ловится: предметом (Tool) автоматически, либо экранной кнопкой атаки (выбери её кнопкой в меню).
-- =========================================================
local GuiServicePop = game:GetService("GuiService")
local StarterGuiPop = game:GetService("StarterGui")
local inkPopEnabled = false
local inkPopTime = 0.12     -- сколько быть снаружи
local inkPreDelay = 0.08    -- пауза после выхода до удара (чтобы сервер увидел новую позицию)
local inkBusy = false
local inkSimulating = false
local inkPicking = false
local inkAttackObj = nil
local inkPopToggleObj, inkFloatBtn = nil, nil
local inkHookedTools = setmetatable({}, {__mode = "k"})

local function inkNotify(text)
    pcall(function()
        StarterGuiPop:SetCore("SendNotification", {Title = "🦑 Ink Pop", Text = text, Duration = 4})
    end)
end

local function inkObjectsAt(pos)
    local pg = Player:FindFirstChild("PlayerGui")
    if not pg then return {} end
    local inset = GuiServicePop:GetGuiInset()
    for _, dy in ipairs({0, -inset.Y, inset.Y}) do
        local ok, list = pcall(function() return pg:GetGuiObjectsAtPosition(pos.X, pos.Y + dy) end)
        if ok and list and #list > 0 then return list end
    end
    return {}
end

local function inkPickTarget(list)
    for _, o in ipairs(list) do
        if o:IsA("GuiButton") then return o end
        local anc = o:FindFirstAncestorWhichIsA("GuiButton")
        if anc then return anc end
    end
    return list[1]
end

local function inkHits(obj, pos)
    if not obj or not obj.Parent then return false end
    for _, o in ipairs(inkObjectsAt(pos)) do
        if o == obj or o:IsDescendantOf(obj) then return true end
    end
    return false
end

local function inkTapObj(obj)
    if not obj or not obj.Parent then return end
    local c = obj.AbsolutePosition + obj.AbsoluteSize / 2
    local sg = obj:FindFirstAncestorWhichIsA("ScreenGui")
    if not (sg and sg.IgnoreGuiInset) then c = c + Vector2.new(0, GuiServicePop:GetGuiInset().Y) end
    inkSimulating = true
    pcall(function()
        VirtualInputManager:SendMouseButtonEvent(c.X, c.Y, 0, true, game, 0)
        task.wait(0.03)
        VirtualInputManager:SendMouseButtonEvent(c.X, c.Y, 0, false, game, 0)
    end)
    task.wait(0.03)
    inkSimulating = false
end

local function inkPop(repeatAttack)
    if inkBusy or not inkPopEnabled or not bendyDiveActive or _G.ScriptDestroyed then return end
    inkBusy = true
    task.spawn(function()
        stopBendyDive(true)                 -- вылез: тело возвращается к кукле
        task.wait(inkPreDelay)
        pcall(repeatAttack)                 -- удар
        task.wait(inkPopTime)
        if bendyDiveActive and not _G.ScriptDestroyed then
            startBendyDive(bendyHudBtnRef)  -- нырнул обратно
        end
        task.wait(0.05)
        inkBusy = false
    end)
end

_G.PH_InkPop = inkPop
_G.PH_IsDiving = function() return bendyDiveActive end
_G.PH_GetDiveRoot = function()
    if bendyDiveActive and bendyProxyRig and bendyProxyRig.Parent then
        return bendyProxyRig:FindFirstChild("HumanoidRootPart")
    end
    return nil
end

UIS.InputBegan:Connect(function(input)
    if _G.ScriptDestroyed or inkSimulating then return end
    local t = input.UserInputType
    if t ~= Enum.UserInputType.Touch and t ~= Enum.UserInputType.MouseButton1 then return end
    local pos = Vector2.new(input.Position.X, input.Position.Y)
    if inkPicking then
        local obj = inkPickTarget(inkObjectsAt(pos))
        if obj then
            inkAttackObj = obj
            inkPicking = false
            inkNotify("Кнопка атаки выбрана: " .. obj.Name)
        end
        return
    end
    if inkPopEnabled and inkAttackObj and bendyDiveActive and not inkBusy and inkHits(inkAttackObj, pos) then
        inkPop(function() inkTapObj(inkAttackObj) end)
    end
end)

local function inkHookTool(tool)
    if not tool:IsA("Tool") or inkHookedTools[tool] then return end
    inkHookedTools[tool] = true
    tool.Activated:Connect(function()
        if inkAttackObj then return end
        inkPop(function() tool:Activate() end)
    end)
end
local function inkHookCharacter(char)
    for _, c in ipairs(char:GetChildren()) do inkHookTool(c) end
    char.ChildAdded:Connect(inkHookTool)
    local bp = Player:FindFirstChildOfClass("Backpack")
    if bp then
        for _, c in ipairs(bp:GetChildren()) do inkHookTool(c) end
        bp.ChildAdded:Connect(inkHookTool)
    end
end
if Player.Character then inkHookCharacter(Player.Character) end
Player.CharacterAdded:Connect(inkHookCharacter)

local function inkSetPop(v)
    inkPopEnabled = v and true or false
    if inkFloatBtn then
        inkFloatBtn.Text = inkPopEnabled and "🦑 Pop: ВКЛ" or "🦑 Pop: ВЫКЛ"
        inkFloatBtn.BackgroundColor3 = inkPopEnabled and Color3.fromRGB(50, 180, 50) or Color3.fromRGB(200, 50, 50)
    end
    if inkPopToggleObj and inkPopToggleObj.Set then inkPopToggleObj.Set(inkPopEnabled) end
end

inkPopToggleObj = createToggle(visualsPage, "🦑 Вылезать из чернильного дайвинга на удар", function(v) inkSetPop(v) end)
createButton(visualsPage, "⚔ Выбрать экранную кнопку АТАКИ (если бьёшь не предметом)", function()
    inkPicking = true
    inkNotify("Отодвинь меню и тапни по своей кнопке атаки")
end)
createButton(visualsPage, "♻ Сбросить выбор кнопки атаки (бить предметом)", function()
    inkAttackObj = nil
    inkPicking = false
    inkNotify("Выбор сброшен: ловлю удар предметом")
end)
createInput(visualsPage, "Время вне чернил (сек)", "0.12", function(t)
    local n = tonumber(t)
    if n and n >= 0.03 and n <= 1 then inkPopTime = n end
end)

inkFloatBtn = Instance.new("TextButton")
inkFloatBtn.Name = "InkPopFloat"
inkFloatBtn.Size = UDim2.new(0, 115, 0, 34)
inkFloatBtn.Position = UDim2.new(1, -135, 0.35, 62)
inkFloatBtn.BackgroundColor3 = Color3.fromRGB(200, 50, 50)
inkFloatBtn.Text = "🦑 Pop: ВЫКЛ"
inkFloatBtn.TextColor3 = Color3.fromRGB(255, 255, 255)
inkFloatBtn.TextSize = 13
inkFloatBtn.Font = Enum.Font.SourceSansBold
inkFloatBtn.Active = true
inkFloatBtn.Draggable = true
inkFloatBtn.ZIndex = 90
inkFloatBtn.Parent = ScreenGui
Instance.new("UICorner", inkFloatBtn).CornerRadius = UDim.new(0, 8)
inkFloatBtn.MouseButton1Click:Connect(function()
    if _G.ScriptPaused or _G.ScriptDestroyed then return end
    inkSetPop(not inkPopEnabled)
end)

end
end
-- =========================================================
-- ----- КОНЕЦ ЧАСТИ 8.2 -----
-- =========================================================
-- =========================================================
-- ----- НАЧАЛО ЧАСТИ 9.1 -----
-- =========================================================

_G.SavedZoneBoxes = _G.SavedZoneBoxes or {}
local draftPointA = nil
local draftPointB = nil
local draftMarkerA = nil
local draftMarkerB = nil
local editingBoxData = nil

local creatorFrame = Instance.new("Frame")
creatorFrame.Size = UDim2.new(1, 0, 0, 128)
creatorFrame.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
creatorFrame.Parent = zonesPage
Instance.new("UICorner", creatorFrame).CornerRadius = UDim.new(0, 6)

local statusLbl = Instance.new("TextLabel", creatorFrame)
statusLbl.Size = UDim2.new(1, -10, 0, 20)
statusLbl.Position = UDim2.new(0, 5, 0, 2)
statusLbl.BackgroundTransparency = 1
statusLbl.Text = "Шаг 1: Поставьте Точку А"
statusLbl.TextColor3 = Color3.fromRGB(255, 220, 60)
statusLbl.Font = Enum.Font.SourceSansBold
statusLbl.TextSize = 12
statusLbl.TextXAlignment = Enum.TextXAlignment.Left

local btnA = Instance.new("TextButton", creatorFrame)
btnA.Size = UDim2.new(0.48, -5, 0, 26)
btnA.Position = UDim2.new(0, 5, 0, 24)
btnA.BackgroundColor3 = Color3.fromRGB(50, 140, 50)
btnA.Text = "📍 Точка А"
btnA.TextColor3 = Color3.fromRGB(255, 255, 255)
btnA.Font = Enum.Font.SourceSansBold
btnA.TextSize = 12
Instance.new("UICorner", btnA).CornerRadius = UDim.new(0, 4)

local btnB = Instance.new("TextButton", creatorFrame)
btnB.Size = UDim2.new(0.48, -5, 0, 26)
btnB.Position = UDim2.new(0.52, 0, 0, 24)
btnB.BackgroundColor3 = Color3.fromRGB(60, 60, 60)
btnB.Text = "📍 Точка Б (Блок)"
btnB.TextColor3 = Color3.fromRGB(150, 150, 150)
btnB.Font = Enum.Font.SourceSansBold
btnB.TextSize = 12
btnB.AutoButtonColor = false
Instance.new("UICorner", btnB).CornerRadius = UDim.new(0, 4)

local nameBox = Instance.new("TextBox", creatorFrame)
nameBox.Size = UDim2.new(0.68, -5, 0, 26)
nameBox.Position = UDim2.new(0, 5, 0, 54)
nameBox.BackgroundColor3 = Color3.fromRGB(45, 45, 45)
nameBox.PlaceholderText = "Сначала поставьте А и Б..."
nameBox.Text = ""
nameBox.TextColor3 = Color3.fromRGB(255, 255, 255)
nameBox.Font = Enum.Font.SourceSans
nameBox.TextSize = 12
nameBox.TextEditable = false
Instance.new("UICorner", nameBox).CornerRadius = UDim.new(0, 4)

local saveBoxBtn = Instance.new("TextButton", creatorFrame)
saveBoxBtn.Size = UDim2.new(0.3, -5, 0, 26)
saveBoxBtn.Position = UDim2.new(0.7, 0, 0, 54)
saveBoxBtn.BackgroundColor3 = Color3.fromRGB(60, 60, 60)
saveBoxBtn.Text = "💾 Готово"
saveBoxBtn.TextColor3 = Color3.fromRGB(150, 150, 150)
saveBoxBtn.Font = Enum.Font.SourceSansBold
saveBoxBtn.TextSize = 12
saveBoxBtn.AutoButtonColor = false
Instance.new("UICorner", saveBoxBtn).CornerRadius = UDim.new(0, 4)

local toggleZonesBtn = Instance.new("TextButton", creatorFrame)
toggleZonesBtn.Size = UDim2.new(1, -10, 0, 22)
toggleZonesBtn.Position = UDim2.new(0, 5, 0, 83)
toggleZonesBtn.BackgroundColor3 = Color3.fromRGB(200, 50, 50)
toggleZonesBtn.Text = "Зоны: ВЫКЛ"
toggleZonesBtn.TextColor3 = Color3.fromRGB(255, 255, 255)
toggleZonesBtn.Font = Enum.Font.SourceSansBold
toggleZonesBtn.TextSize = 11
Instance.new("UICorner", toggleZonesBtn).CornerRadius = UDim.new(0, 4)

local legendLbl = Instance.new("TextLabel", creatorFrame)
legendLbl.Size = UDim2.new(1, -10, 0, 18)
legendLbl.Position = UDim2.new(0, 5, 0, 107)
legendLbl.BackgroundTransparency = 1
legendLbl.Text = "[ + ] Только внутри (1 зона)   |   [ - ] Не заходить   |   [   ] Откл."
legendLbl.TextColor3 = Color3.fromRGB(185, 185, 185)
legendLbl.Font = Enum.Font.SourceSansBold
legendLbl.TextSize = 10
legendLbl.TextXAlignment = Enum.TextXAlignment.Center

local function getBoxColorByRule(rule)
    if rule == "+" then return Color3.fromRGB(255, 220, 60)
    elseif rule == "-" then return Color3.fromRGB(255, 60, 60)
    else return Color3.fromRGB(100, 200, 255) end
end

local function createZoneMarker(position, labelText, color)
    local marker = Instance.new("Part")
    marker.Name = "ZoneMarker_" .. tostring(labelText)
    marker.Size = Vector3.new(4, 4, 4)
    marker.Position = position + Vector3.new(0, 2, 0)
    marker.Anchored = true
    marker.CanCollide = false
    marker.CanQuery = false
    marker.CanTouch = false
    marker.Material = Enum.Material.Neon
    marker.Transparency = 0.35
    marker.Color = color or Color3.fromRGB(255, 220, 60)
    marker.Parent = workspace

    local bbg = Instance.new("BillboardGui", marker)
    bbg.Name = "MarkerTitleGui"
    bbg.AlwaysOnTop = true
    bbg.MaxDistance = 15000
    bbg.Size = UDim2.new(0, 220, 0, 36)
    bbg.StudsOffset = Vector3.new(0, 4, 0)

    local lbl = Instance.new("TextLabel", bbg)
    lbl.Size = UDim2.new(1, 0, 1, 0)
    lbl.BackgroundTransparency = 1
    lbl.Text = "📍 " .. tostring(labelText)
    lbl.TextColor3 = color or Color3.fromRGB(255, 220, 60)
    lbl.TextStrokeTransparency = 0.2
    lbl.Font = Enum.Font.SourceSansBold
    lbl.TextSize = 18

    return marker
end

local function buildBoxVisual(ptA, ptB, boxTitle, ruleStr)
    local sizeX = math.abs(ptA.X - ptB.X) + 10
    local sizeZ = math.abs(ptA.Z - ptB.Z) + 10
    local center = Vector3.new((ptA.X + ptB.X)/2, (ptA.Y + ptB.Y)/2, (ptA.Z + ptB.Z)/2)
    local col = getBoxColorByRule(ruleStr)

    local part = Instance.new("Part")
    part.Name = "ZoneBoxVisual_" .. boxTitle
    part.Size = Vector3.new(sizeX, 20, sizeZ)
    part.Position = center
    part.Anchored = true
    part.CanCollide = false
    part.Transparency = 0.8
    part.Material = Enum.Material.ForceField
    part.Color = col
    part.Parent = workspace

    local sel = Instance.new("SelectionBox", part)
    sel.Name = "BoxSel"
    sel.Adornee = part
    sel.Color3 = col
    sel.LineThickness = 0.08

    local bbg = Instance.new("BillboardGui", part)
    bbg.Name = "BoxTitleGui"
    bbg.AlwaysOnTop = true
    bbg.MaxDistance = 15000
    bbg.Size = UDim2.new(0, 260, 0, 50)
    bbg.StudsOffset = Vector3.new(0, 14, 0)

    local lbl = Instance.new("TextLabel", bbg)
    lbl.Name = "TitleLbl"
    lbl.Size = UDim2.new(1, 0, 1, 0)
    lbl.BackgroundTransparency = 1
    lbl.Text = "📦 " .. boxTitle
    lbl.TextColor3 = col
    lbl.TextStrokeTransparency = 0.2
    lbl.Font = Enum.Font.SourceSansBold
    lbl.TextSize = 20

    task.spawn(function()
        local cam = workspace.CurrentCamera
        while part and part.Parent and not _G.ScriptDestroyed do
            local dist = (cam.CFrame.Position - part.Position).Magnitude
            lbl.TextSize = math.clamp(18 + (dist / 40), 18, 95)
            bbg.Size = UDim2.new(0, math.clamp(240 + (dist / 8), 240, 1200), 0, math.clamp(45 + (dist / 30), 45, 250))
            task.wait(0.2)
        end
    end)

    return part
end

local function updateVisualColor(bData)
    if bData.Visual then
        local col = getBoxColorByRule(bData.Rule)
        bData.Visual.Color = col
        local sel = bData.Visual:FindFirstChild("BoxSel")
        if sel then sel.Color3 = col end
        local gui = bData.Visual:FindFirstChild("BoxTitleGui")
        if gui and gui:FindFirstChild("TitleLbl") then gui.TitleLbl.TextColor3 = col end
    end
end

-- =========================================================
-- ----- КОНЕЦ ЧАСТИ 9.1 -----
-- =========================================================
-- =========================================================
-- ----- НАЧАЛО ЧАСТИ 9.2 -----
-- =========================================================

local function updateCreatorUI()
    if editingBoxData then
        nameBox.TextEditable = false
        nameBox.Text = editingBoxData.Name
        saveBoxBtn.BackgroundColor3 = Color3.fromRGB(60, 60, 60)
        saveBoxBtn.TextColor3 = Color3.fromRGB(150, 150, 150)
        if not editingBoxData.PointA then
            statusLbl.Text = "Восстановите Точку А для: " .. editingBoxData.Name
            btnA.BackgroundColor3 = Color3.fromRGB(50, 140, 50)
            btnA.Text = "📍 Поставить А"
            btnA.TextColor3 = Color3.fromRGB(255, 255, 255)
            btnB.BackgroundColor3 = Color3.fromRGB(60, 60, 60)
            btnB.Text = "📍 Точка Б (Есть)"
            btnB.TextColor3 = Color3.fromRGB(150, 150, 150)
        elseif not editingBoxData.PointB then
            statusLbl.Text = "Восстановите Точку Б для: " .. editingBoxData.Name
            btnA.BackgroundColor3 = Color3.fromRGB(60, 60, 60)
            btnA.Text = "📍 Точка А (Есть)"
            btnA.TextColor3 = Color3.fromRGB(150, 150, 150)
            btnB.BackgroundColor3 = Color3.fromRGB(50, 140, 50)
            btnB.Text = "📍 Поставить Б"
            btnB.TextColor3 = Color3.fromRGB(255, 255, 255)
        end
        return
    end

    if not draftPointA then
        statusLbl.Text = "Шаг 1: Поставьте Точку А"
        btnA.BackgroundColor3 = Color3.fromRGB(50, 140, 50)
        btnA.Text = "📍 Точка А"
        btnA.TextColor3 = Color3.fromRGB(255, 255, 255)
        btnB.BackgroundColor3 = Color3.fromRGB(60, 60, 60)
        btnB.Text = "📍 Точка Б (Блок)"
        btnB.TextColor3 = Color3.fromRGB(150, 150, 150)
        nameBox.TextEditable = false
        nameBox.Text = ""
        nameBox.PlaceholderText = "Сначала поставьте А и Б..."
        saveBoxBtn.BackgroundColor3 = Color3.fromRGB(60, 60, 60)
        saveBoxBtn.TextColor3 = Color3.fromRGB(150, 150, 150)
    elseif draftPointA and not draftPointB then
        statusLbl.Text = "Шаг 2: Поставьте Точку Б (А заблокирована)"
        btnA.BackgroundColor3 = Color3.fromRGB(60, 60, 60)
        btnA.Text = "📍 Точка А (Блок)"
        btnA.TextColor3 = Color3.fromRGB(150, 150, 150)
        btnB.BackgroundColor3 = Color3.fromRGB(50, 140, 50)
        btnB.Text = "📍 Точка Б"
        btnB.TextColor3 = Color3.fromRGB(255, 255, 255)
        nameBox.TextEditable = false
        nameBox.PlaceholderText = "Теперь поставьте Точку Б..."
    else
        statusLbl.Text = "Шаг 3: Введите название (Без имени не работает)"
        btnA.BackgroundColor3 = Color3.fromRGB(60, 60, 60)
        btnA.Text = "📍 Точка А (Блок)"
        btnA.TextColor3 = Color3.fromRGB(150, 150, 150)
        btnB.BackgroundColor3 = Color3.fromRGB(60, 60, 60)
        btnB.Text = "📍 Точка Б (Блок)"
        btnB.TextColor3 = Color3.fromRGB(150, 150, 150)
        nameBox.TextEditable = true
        nameBox.PlaceholderText = "Введите название коробки..."
        saveBoxBtn.BackgroundColor3 = Color3.fromRGB(40, 120, 200)
        saveBoxBtn.TextColor3 = Color3.fromRGB(255, 255, 255)
    end
end

local boxesScroll = Instance.new("ScrollingFrame", zonesPage)
boxesScroll.Size = UDim2.new(1, 0, 0, 135)
boxesScroll.BackgroundColor3 = Color3.fromRGB(22, 22, 22)
boxesScroll.BorderSizePixel = 0
boxesScroll.ScrollBarThickness = 4
Instance.new("UICorner", boxesScroll).CornerRadius = UDim.new(0, 6)

local boxesLayout = Instance.new("UIListLayout", boxesScroll)
boxesLayout.Padding = UDim.new(0, 5)
boxesLayout:GetPropertyChangedSignal("AbsoluteContentSize"):Connect(function()
    boxesScroll.CanvasSize = UDim2.new(0, 0, 0, boxesLayout.AbsoluteContentSize.Y + 10)
end)

local function hasAnotherPlusBox(excludeBox)
    for _, item in ipairs(_G.SavedZoneBoxes) do
        if item ~= excludeBox and item.Rule == "+" then return true end
    end
    return false
end

local refreshBoxesList
refreshBoxesList = function()
    for _, ch in pairs(boxesScroll:GetChildren()) do
        if ch:IsA("Frame") then ch:Destroy() end
    end

    for idx, bData in ipairs(_G.SavedZoneBoxes) do
        local row = Instance.new("Frame", boxesScroll)
        row.Size = UDim2.new(1, -6, 0, 32)
        row.BackgroundColor3 = Color3.fromRGB(35, 35, 35)
        Instance.new("UICorner", row).CornerRadius = UDim.new(0, 5)

        local ruleBtn = Instance.new("TextButton", row)
        ruleBtn.Size = UDim2.new(0, 24, 0, 24)
        ruleBtn.Position = UDim2.new(0, 6, 0.5, -12)
        ruleBtn.BackgroundColor3 = Color3.fromRGB(50, 50, 50)
        ruleBtn.Font = Enum.Font.SourceSansBold
        ruleBtn.TextSize = 15
        Instance.new("UICorner", ruleBtn).CornerRadius = UDim.new(0, 4)

        local boxStroke = Instance.new("UIStroke", ruleBtn)
        boxStroke.Thickness = 1.5
        boxStroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border

        local function syncRuleBtnStyle()
            ruleBtn.Text = bData.Rule or ""
            if bData.Rule == "+" then
                ruleBtn.TextColor3 = Color3.fromRGB(255, 220, 60)
                boxStroke.Color = Color3.fromRGB(255, 220, 60)
            elseif bData.Rule == "-" then
                ruleBtn.TextColor3 = Color3.fromRGB(255, 70, 70)
                boxStroke.Color = Color3.fromRGB(255, 70, 70)
            else
                ruleBtn.TextColor3 = Color3.fromRGB(200, 200, 200)
                boxStroke.Color = Color3.fromRGB(90, 90, 90)
            end
        end
        syncRuleBtnStyle()

        ruleBtn.MouseButton1Click:Connect(function()
            local cur = bData.Rule or ""
            if cur == "" then
                bData.Rule = hasAnotherPlusBox(bData) and "-" or "+"
            elseif cur == "+" then
                bData.Rule = "-"
            else
                bData.Rule = ""
            end
            syncRuleBtnStyle()
            updateVisualColor(bData)
        end)

        local title = Instance.new("TextLabel", row)
        title.Size = UDim2.new(1, -165, 1, 0)
        title.Position = UDim2.new(0, 38, 0, 0)
        title.BackgroundTransparency = 1
        title.Text = (bData.Active and "" or "⚠️ ") .. bData.Name
        title.TextColor3 = Color3.fromRGB(255, 255, 255)
        title.Font = Enum.Font.SourceSans
        title.TextSize = 13
        title.TextXAlignment = Enum.TextXAlignment.Left

        local delABtn = Instance.new("TextButton", row)
        delABtn.Size = UDim2.new(0, 38, 0, 22)
        delABtn.Position = UDim2.new(1, -126, 0.5, -11)
        delABtn.BackgroundColor3 = bData.PointA and Color3.fromRGB(160, 110, 30) or Color3.fromRGB(60, 60, 60)
        delABtn.Text = "Уд. А"
        delABtn.TextColor3 = Color3.fromRGB(255, 255, 255)
        delABtn.Font = Enum.Font.SourceSansBold
        delABtn.TextSize = 10
        Instance.new("UICorner", delABtn).CornerRadius = UDim.new(0, 4)
        delABtn.MouseButton1Click:Connect(function()
            if not bData.PointA or editingBoxData then return end
            bData.PointA = nil
            bData.Active = false
            if bData.MarkerA then bData.MarkerA:Destroy() bData.MarkerA = nil end
            if bData.Visual then bData.Visual:Destroy() bData.Visual = nil end
            editingBoxData = bData
            updateCreatorUI()
            refreshBoxesList()
        end)

        local delBBtn = Instance.new("TextButton", row)
        delBBtn.Size = UDim2.new(0, 38, 0, 22)
        delBBtn.Position = UDim2.new(1, -84, 0.5, -11)
        delBBtn.BackgroundColor3 = bData.PointB and Color3.fromRGB(40, 110, 160) or Color3.fromRGB(60, 60, 60)
        delBBtn.Text = "Уд. Б"
        delBBtn.TextColor3 = Color3.fromRGB(255, 255, 255)
        delBBtn.Font = Enum.Font.SourceSansBold
        delBBtn.TextSize = 10
        Instance.new("UICorner", delBBtn).CornerRadius = UDim.new(0, 4)
        delBBtn.MouseButton1Click:Connect(function()
            if not bData.PointB or editingBoxData then return end
            bData.PointB = nil
            bData.Active = false
            if bData.MarkerB then bData.MarkerB:Destroy() bData.MarkerB = nil end
            if bData.Visual then bData.Visual:Destroy() bData.Visual = nil end
            editingBoxData = bData
            updateCreatorUI()
            refreshBoxesList()
        end)

        local delAllBtn = Instance.new("TextButton", row)
        delAllBtn.Size = UDim2.new(0, 35, 0, 22)
        delAllBtn.Position = UDim2.new(1, -42, 0.5, -11)
        delAllBtn.BackgroundColor3 = Color3.fromRGB(160, 40, 40)
        delAllBtn.Text = "🗑️"
        delAllBtn.TextColor3 = Color3.fromRGB(255, 255, 255)
        delAllBtn.Font = Enum.Font.SourceSansBold
        delAllBtn.TextSize = 11
        Instance.new("UICorner", delAllBtn).CornerRadius = UDim.new(0, 4)
        delAllBtn.MouseButton1Click:Connect(function()
            if bData.MarkerA then bData.MarkerA:Destroy() end
            if bData.MarkerB then bData.MarkerB:Destroy() end
            if bData.Visual then bData.Visual:Destroy() end
            if editingBoxData == bData then editingBoxData = nil end
            table.remove(_G.SavedZoneBoxes, idx)
            updateCreatorUI()
            refreshBoxesList()
        end)
    end
end

-- =========================================================
-- ----- КОНЕЦ ЧАСТИ 9.2 -----
-- =========================================================
-- =========================================================
-- ----- НАЧАЛО ЧАСТИ 9.3 -----
-- =========================================================

btnA.MouseButton1Click:Connect(function()
    local char = Player.Character
    local root = (invisActive and ghostSimulationCube) or (godmodeEnabled and godGroundCube) or (char and char:FindFirstChild("HumanoidRootPart"))
    if not root then return end
    if editingBoxData and not editingBoxData.PointA then
        editingBoxData.PointA = root.Position
        editingBoxData.MarkerA = createZoneMarker(editingBoxData.PointA, editingBoxData.Name .. " [А]", Color3.fromRGB(255, 220, 60))
        editingBoxData.Visual = buildBoxVisual(editingBoxData.PointA, editingBoxData.PointB, editingBoxData.Name, editingBoxData.Rule)
        editingBoxData.Active = true
        editingBoxData = nil
        updateCreatorUI()
        refreshBoxesList()
        return
    end
    if not editingBoxData and not draftPointA then
        draftPointA = root.Position
        if draftMarkerA then draftMarkerA:Destroy() end
        draftMarkerA = createZoneMarker(draftPointA, "ЧЕРНОВИК: ТОЧКА А", Color3.fromRGB(255, 220, 60))
        updateCreatorUI()
    end
end)

btnB.MouseButton1Click:Connect(function()
    local char = Player.Character
    local root = (invisActive and ghostSimulationCube) or (godmodeEnabled and godGroundCube) or (char and char:FindFirstChild("HumanoidRootPart"))
    if not root then return end
    if editingBoxData and not editingBoxData.PointB then
        editingBoxData.PointB = root.Position
        editingBoxData.MarkerB = createZoneMarker(editingBoxData.PointB, editingBoxData.Name .. " [Б]", Color3.fromRGB(60, 220, 255))
        editingBoxData.Visual = buildBoxVisual(editingBoxData.PointA, editingBoxData.PointB, editingBoxData.Name, editingBoxData.Rule)
        editingBoxData.Active = true
        editingBoxData = nil
        updateCreatorUI()
        refreshBoxesList()
        return
    end
    if not editingBoxData and draftPointA and not draftPointB then
        draftPointB = root.Position
        if draftMarkerB then draftMarkerB:Destroy() end
        draftMarkerB = createZoneMarker(draftPointB, "ЧЕРНОВИК: ТОЧКА Б", Color3.fromRGB(60, 220, 255))
        updateCreatorUI()
    end
end)

local function finalizeNewBox()
    if editingBoxData or not draftPointA or not draftPointB then return end
    local boxName = nameBox.Text:gsub("^%s*(.-)%s*$", "%1")
    if boxName == "" then return end
    if draftMarkerA then draftMarkerA:Destroy() draftMarkerA = nil end
    if draftMarkerB then draftMarkerB:Destroy() draftMarkerB = nil end
    local mA = createZoneMarker(draftPointA, boxName .. " [А]", Color3.fromRGB(255, 220, 60))
    local mB = createZoneMarker(draftPointB, boxName .. " [Б]", Color3.fromRGB(60, 220, 255))
    local vis = buildBoxVisual(draftPointA, draftPointB, boxName, "")
    table.insert(_G.SavedZoneBoxes, {Name = boxName, PointA = draftPointA, PointB = draftPointB, MarkerA = mA, MarkerB = mB, Visual = vis, Rule = "", Active = true})
    draftPointA, draftPointB, nameBox.Text = nil, nil, ""
    updateCreatorUI()
    refreshBoxesList()
end

saveBoxBtn.MouseButton1Click:Connect(finalizeNewBox)
nameBox.FocusLost:Connect(function(enterPressed) if enterPressed then finalizeNewBox() end end)

toggleZonesBtn.MouseButton1Click:Connect(function()
    zonesEnabled = not zonesEnabled
    toggleZonesBtn.Text = zonesEnabled and "Зоны: ВКЛ (+ внутри / - снаружи)" or "Зоны: ВЫКЛ"
    toggleZonesBtn.BackgroundColor3 = zonesEnabled and Color3.fromRGB(50, 180, 50) or Color3.fromRGB(200, 50, 50)
    if zonesEnabled then
        task.spawn(function()
            while zonesEnabled and not _G.ScriptDestroyed do
                if not _G.ScriptPaused then
                    local char = Player.Character
                    local hrp = (invisActive and ghostSimulationCube) or (godmodeEnabled and godGroundCube) or (char and char:FindFirstChild("HumanoidRootPart"))
                    if hrp then
                        for _, bData in ipairs(_G.SavedZoneBoxes) do
                            if bData.Active and bData.PointA and bData.PointB and (bData.Rule == "+" or bData.Rule == "-") then
                                local minX = math.min(bData.PointA.X, bData.PointB.X) - 5
                                local maxX = math.max(bData.PointA.X, bData.PointB.X) + 5
                                local midY = (bData.PointA.Y + bData.PointB.Y) / 2
                                local minY, maxY = midY - 10, midY + 10
                                local minZ = math.min(bData.PointA.Z, bData.PointB.Z) - 5
                                local maxZ = math.max(bData.PointA.Z, bData.PointB.Z) + 5
                                local pos = hrp.Position
                                local isInside = (pos.X >= minX and pos.X <= maxX) and (pos.Y >= minY and pos.Y <= maxY) and (pos.Z >= minZ and pos.Z <= maxZ)

                                if bData.Rule == "+" and not isInside then
                                    local clamped = Vector3.new(math.clamp(pos.X, minX + 1.5, maxX - 1.5), math.clamp(pos.Y, minY + 1.5, maxY - 1.5), math.clamp(pos.Z, minZ + 1.5, maxZ - 1.5))
                                    hrp.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
                                    hrp.CFrame = CFrame.new(clamped) * (hrp.CFrame - hrp.CFrame.Position)
                                elseif bData.Rule == "-" and isInside then
                                    local dL, dR, dT, dB = math.abs(pos.X - minX), math.abs(maxX - pos.X), math.abs(pos.Z - minZ), math.abs(maxZ - pos.Z)
                                    local mD = math.min(dL, dR, dT, dB)
                                    local pushPos = (mD == dL and Vector3.new(minX - 6, pos.Y, pos.Z)) or (mD == dR and Vector3.new(maxX + 6, pos.Y, pos.Z)) or (mD == dT and Vector3.new(pos.X, pos.Y, minZ - 6)) or Vector3.new(pos.X, pos.Y, maxZ + 6)
                                    hrp.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
                                    hrp.CFrame = CFrame.new(pushPos) * (hrp.CFrame - hrp.CFrame.Position)
                                end
                            end
                        end
                    end
                end
                RunService.Heartbeat:Wait()
            end
        end)
    end
end)

refreshBoxesList()

-- =========================================================
-- ----- КОНЕЦ ЧАСТИ 9.3 -----
-- =========================================================
-- =========================================================
-- ----- НАЧАЛО ЧАСТИ 10.1 -----
-- =========================================================

local ziplineSpeedValue = 50
local ziplineDelayValue = 0
local dropOnPoint = false

local pointScrollFrame = Instance.new("ScrollingFrame")
pointScrollFrame.Size = UDim2.new(1, 0, 1, -175)
pointScrollFrame.Position = UDim2.new(0, 0, 0, 40)
pointScrollFrame.BackgroundTransparency = 1
pointScrollFrame.BorderSizePixel = 0
pointScrollFrame.ScrollBarThickness = 4
pointScrollFrame.Parent = pointsPage

local listLayout = Instance.new("UIListLayout")
listLayout.Padding = UDim.new(0, 6)
listLayout.SortOrder = Enum.SortOrder.LayoutOrder
listLayout.Parent = pointScrollFrame
listLayout:GetPropertyChangedSignal("AbsoluteContentSize"):Connect(function()
    pointScrollFrame.CanvasSize = UDim2.new(0, 0, 0, listLayout.AbsoluteContentSize.Y + 10)
end)

local savedNameTemp = "Точка 1"
local inputFrame = Instance.new("Frame")
inputFrame.Size = UDim2.new(1, 0, 0, 35)
inputFrame.BackgroundTransparency = 1
inputFrame.Parent = pointsPage

local box = Instance.new("TextBox")
box.Size = UDim2.new(1, -45, 0, 26)
box.Position = UDim2.new(0, 0, 0.5, -13)
box.BackgroundColor3 = Color3.fromRGB(40, 40, 40)
box.PlaceholderText = "Название точки..."
box.Text = ""
box.TextColor3 = Color3.fromRGB(255, 255, 255)
box.TextSize = 13
box.Font = Enum.Font.SourceSans
box.Parent = inputFrame
Instance.new("UICorner", box).CornerRadius = UDim.new(0, 5)
box.FocusLost:Connect(function() if box.Text ~= "" then savedNameTemp = box.Text end end)

local addBtn = Instance.new("TextButton")
addBtn.Size = UDim2.new(0, 35, 0, 26)
addBtn.Position = UDim2.new(1, -35, 0.5, -13)
addBtn.BackgroundColor3 = Color3.fromRGB(50, 180, 50)
addBtn.Text = "✓"
addBtn.TextColor3 = Color3.fromRGB(255, 255, 255)
addBtn.Font = Enum.Font.SourceSansBold
addBtn.TextSize = 14
addBtn.Parent = inputFrame
Instance.new("UICorner", addBtn).CornerRadius = UDim.new(0, 5)

local function recalculateOrders()
    orderCounter = 0
    local sorted = {}
    for _, pt in ipairs(savedPoints) do
        if pt.Order and pt.Order > 0 then table.insert(sorted, pt) end
    end
    table.sort(sorted, function(a,b) return a.Order < b.Order end)
    for i, pt in ipairs(sorted) do
        pt.Order = i
        if pt.NumBox then pt.NumBox.Text = tostring(i) end
        orderCounter = i
    end
end

local refreshPointList
refreshPointList = function()
    for _, child in pairs(pointScrollFrame:GetChildren()) do
        if child:IsA("Frame") then child:Destroy() end
    end
    for index, pt in ipairs(savedPoints) do
        local pFrame = Instance.new("Frame")
        pFrame.Size = UDim2.new(1, 0, 0, 32)
        pFrame.BackgroundColor3 = Color3.fromRGB(35, 35, 35)
        pFrame.Parent = pointScrollFrame
        Instance.new("UICorner", pFrame).CornerRadius = UDim.new(0, 5)

        local numBox = Instance.new("TextButton")
        numBox.Size = UDim2.new(0, 24, 0, 24)
        numBox.Position = UDim2.new(0, 6, 0.5, -12)
        numBox.BackgroundColor3 = Color3.fromRGB(50, 50, 50)
        numBox.Text = pt.Order and tostring(pt.Order) or ""
        numBox.TextColor3 = Color3.fromRGB(255, 220, 60)
        numBox.Font = Enum.Font.SourceSansBold
        numBox.TextSize = 13
        numBox.Parent = pFrame
        Instance.new("UICorner", numBox).CornerRadius = UDim.new(0, 4)
        pt.NumBox = numBox
        numBox.MouseButton1Click:Connect(function()
            if pt.Order and pt.Order > 0 then
                pt.Order = nil
                numBox.Text = ""
                recalculateOrders()
            else
                orderCounter = orderCounter + 1
                pt.Order = orderCounter
                numBox.Text = tostring(orderCounter)
            end
        end)

        local nameLabel = Instance.new("TextLabel")
        nameLabel.Size = UDim2.new(1, -140, 1, 0)
        nameLabel.Position = UDim2.new(0, 38, 0, 0)
        nameLabel.BackgroundTransparency = 1
        nameLabel.Text = pt.Name
        nameLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
        nameLabel.TextSize = 13
        nameLabel.Font = Enum.Font.SourceSans
        nameLabel.TextXAlignment = Enum.TextXAlignment.Left
        nameLabel.Parent = pFrame

        local tpBtn = Instance.new("TextButton")
        tpBtn.Size = UDim2.new(0, 35, 0, 22)
        tpBtn.Position = UDim2.new(1, -85, 0.5, -11)
        tpBtn.BackgroundColor3 = Color3.fromRGB(40, 100, 160)
        tpBtn.Text = "🌀"
        tpBtn.TextColor3 = Color3.fromRGB(255, 255, 255)
        tpBtn.Font = Enum.Font.SourceSansBold
        tpBtn.TextSize = 11
        tpBtn.Parent = pFrame
        Instance.new("UICorner", tpBtn).CornerRadius = UDim.new(0, 4)
        tpBtn.MouseButton1Click:Connect(function()
            if invisActive and ghostSimulationCube then ghostSimulationCube.Position = pt.Pos
            elseif godmodeEnabled and godGroundCube then godGroundCube.Position = pt.Pos
            else
                local char = Player.Character
                if char and char:FindFirstChild("HumanoidRootPart") then char.HumanoidRootPart.CFrame = CFrame.new(pt.Pos + Vector3.new(0, 3, 0)) end
            end
        end)

        local delBtn = Instance.new("TextButton")
        delBtn.Size = UDim2.new(0, 35, 0, 22)
        delBtn.Position = UDim2.new(1, -42, 0.5, -11)
        delBtn.BackgroundColor3 = Color3.fromRGB(160, 40, 40)
        delBtn.Text = "🗑️"
        delBtn.TextColor3 = Color3.fromRGB(255, 255, 255)
        delBtn.Font = Enum.Font.SourceSansBold
        delBtn.TextSize = 11
        delBtn.Parent = pFrame
        Instance.new("UICorner", delBtn).CornerRadius = UDim.new(0, 4)
        delBtn.MouseButton1Click:Connect(function()
            if pt.Visual then pt.Visual:Destroy() end
            table.remove(savedPoints, index)
            recalculateOrders()
            refreshPointList()
        end)
    end
end

-- =========================================================
-- ----- КОНЕЦ ЧАСТИ 10.1 -----
-- =========================================================
-- =========================================================
-- ----- НАЧАЛО ЧАСТИ 10.2 -----
-- =========================================================

addBtn.MouseButton1Click:Connect(function()
    local char = Player.Character
    local hrp = char and char:FindFirstChild("HumanoidRootPart")
    if hrp then
        local currentPos = (invisActive and ghostSimulationCube) and ghostSimulationCube.Position or ((godmodeEnabled and godGroundCube) and godGroundCube.Position or hrp.Position)
        if box.Text == "" then
            local maxNum = 0
            for _, pt in ipairs(savedPoints) do
                local num = tonumber(pt.Name:match("Точка%s+(%d+)"))
                if num and num > maxNum then maxNum = num end
            end
            savedNameTemp = "Точка " .. (maxNum + 1)
        else
            savedNameTemp = box.Text
        end

        local part = Instance.new("Part")
        part.Size = Vector3.new(1.5, 1.5, 1.5)
        part.Position = currentPos
        part.Anchored = true
        part.CanCollide = false
        part.Material = Enum.Material.Neon
        part.Color = Color3.fromRGB(255, 220, 60)
        part.Parent = workspace

        local adorn = Instance.new("BoxHandleAdornment", part)
        adorn.Size = part.Size
        adorn.Color3 = part.Color
        adorn.AlwaysOnTop = true
        adorn.ZIndex = 4
        adorn.Adornee = part

        local bbg = Instance.new("BillboardGui", part)
        bbg.AlwaysOnTop = true
        bbg.Size = UDim2.new(0, 140, 0, 40)
        bbg.StudsOffset = Vector3.new(0, 3, 0)

        local lbl = Instance.new("TextLabel", bbg)
        lbl.Size = UDim2.new(1, 0, 1, 0)
        lbl.BackgroundTransparency = 1
        lbl.Text = savedNameTemp
        lbl.TextColor3 = Color3.fromRGB(255, 220, 60)
        lbl.Font = Enum.Font.SourceSansBold
        lbl.TextSize = 16

        task.spawn(function()
            local cam = workspace.CurrentCamera
            while part and part.Parent and not _G.ScriptDestroyed do
                local dist = (cam.CFrame.Position - part.Position).Magnitude
                lbl.TextSize = math.clamp(14 + (dist / 120), 14, 45)
                task.wait(0.2)
            end
        end)

        table.insert(savedPoints, {Name = savedNameTemp, Pos = currentPos, Order = nil, Visual = part})
        local maxNum = 0
        for _, pt in ipairs(savedPoints) do
            local num = tonumber(pt.Name:match("Точка%s+(%d+)"))
            if num and num > maxNum then maxNum = num end
        end
        box.Text = ""
        savedNameTemp = "Точка " .. (maxNum + 1)
        refreshPointList()
    end
end)

local bPanel = Instance.new("Frame")
bPanel.Size = UDim2.new(1, 0, 0, 122)
bPanel.Position = UDim2.new(0, 0, 1, -122)
bPanel.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
bPanel.Parent = pointsPage
Instance.new("UICorner", bPanel).CornerRadius = UDim.new(0, 5)

local zipSpeedBox = Instance.new("TextBox", bPanel)
zipSpeedBox.Size = UDim2.new(0.48, -5, 0, 26)
zipSpeedBox.Position = UDim2.new(0, 5, 0, 5)
zipSpeedBox.BackgroundColor3 = Color3.fromRGB(45, 45, 45)
zipSpeedBox.Text = "Скор: " .. ziplineSpeedValue
zipSpeedBox.TextColor3 = Color3.fromRGB(255, 220, 60)
zipSpeedBox.Font = Enum.Font.SourceSansBold
zipSpeedBox.TextSize = 11
zipSpeedBox.ClearTextOnFocus = true
Instance.new("UICorner", zipSpeedBox).CornerRadius = UDim.new(0, 4)
zipSpeedBox.FocusLost:Connect(function()
    local n = tonumber(zipSpeedBox.Text)
    if n and n > 0 then ziplineSpeedValue = n end
    zipSpeedBox.Text = "Скор: " .. ziplineSpeedValue
end)

local zipDelayBox = Instance.new("TextBox", bPanel)
zipDelayBox.Size = UDim2.new(0.48, -5, 0, 26)
zipDelayBox.Position = UDim2.new(0.52, 0, 0, 5)
zipDelayBox.BackgroundColor3 = Color3.fromRGB(45, 45, 45)
zipDelayBox.Text = "Пауза: " .. ziplineDelayValue .. "с"
zipDelayBox.TextColor3 = Color3.fromRGB(100, 220, 255)
zipDelayBox.Font = Enum.Font.SourceSansBold
zipDelayBox.TextSize = 11
zipDelayBox.ClearTextOnFocus = true
Instance.new("UICorner", zipDelayBox).CornerRadius = UDim.new(0, 4)
zipDelayBox.FocusLost:Connect(function()
    local n = tonumber(zipDelayBox.Text)
    if n and n >= 0 then ziplineDelayValue = n end
    zipDelayBox.Text = "Пауза: " .. ziplineDelayValue .. "с"
end)

local zipModeBtn = Instance.new("TextButton", bPanel)
zipModeBtn.Size = UDim2.new(0.48, -5, 0, 28)
zipModeBtn.Position = UDim2.new(0, 5, 0, 36)
zipModeBtn.BackgroundColor3 = Color3.fromRGB(45, 90, 140)
zipModeBtn.Text = "Режим: Лететь"
zipModeBtn.TextColor3 = Color3.fromRGB(255, 255, 255)
zipModeBtn.Font = Enum.Font.SourceSansBold
zipModeBtn.TextSize = 11
Instance.new("UICorner", zipModeBtn).CornerRadius = UDim.new(0, 4)
local isTeleportMode = false
zipModeBtn.MouseButton1Click:Connect(function()
    isTeleportMode = not isTeleportMode
    zipModeBtn.Text = isTeleportMode and "Режим: Телепорт" or "Режим: Лететь"
    zipModeBtn.BackgroundColor3 = isTeleportMode and Color3.fromRGB(130, 60, 160) or Color3.fromRGB(45, 90, 140)
end)

local dropToggleBtn = Instance.new("TextButton", bPanel)
dropToggleBtn.Size = UDim2.new(0.48, -5, 0, 28)
dropToggleBtn.Position = UDim2.new(0.52, 0, 0, 36)
dropToggleBtn.BackgroundColor3 = Color3.fromRGB(50, 140, 80)
dropToggleBtn.Text = "Падать: НЕТ (Висеть)"
dropToggleBtn.TextColor3 = Color3.fromRGB(255, 255, 255)
dropToggleBtn.Font = Enum.Font.SourceSansBold
dropToggleBtn.TextSize = 11
Instance.new("UICorner", dropToggleBtn).CornerRadius = UDim.new(0, 4)
dropToggleBtn.MouseButton1Click:Connect(function()
    dropOnPoint = not dropOnPoint
    dropToggleBtn.Text = dropOnPoint and "Падать: ДА" or "Падать: НЕТ (Висеть)"
    dropToggleBtn.BackgroundColor3 = dropOnPoint and Color3.fromRGB(180, 110, 40) or Color3.fromRGB(50, 140, 80)
end)

-- =========================================================
-- ----- КОНЕЦ ЧАСТИ 10.2 -----
-- =========================================================
-- =========================================================
-- ----- НАЧАЛО ЧАСТИ 10.3 -----
-- =========================================================

local runZiplineBtn = Instance.new("TextButton", bPanel)
runZiplineBtn.Size = UDim2.new(0.27, -4, 0, 42)
runZiplineBtn.Position = UDim2.new(0, 5, 0, 72)
runZiplineBtn.BackgroundColor3 = Color3.fromRGB(220, 180, 40)
runZiplineBtn.Text = "🚀 Старт"
runZiplineBtn.TextColor3 = Color3.fromRGB(25, 25, 25)
runZiplineBtn.Font = Enum.Font.SourceSansBold
runZiplineBtn.TextSize = 11
Instance.new("UICorner", runZiplineBtn).CornerRadius = UDim.new(0, 4)

local loopZiplineBtn = Instance.new("TextButton", bPanel)
loopZiplineBtn.Size = UDim2.new(0.23, -4, 0, 42)
loopZiplineBtn.Position = UDim2.new(0.27, 3, 0, 72)
loopZiplineBtn.BackgroundColor3 = Color3.fromRGB(160, 40, 40)
loopZiplineBtn.Text = "Loop:\nВЫКЛ"
loopZiplineBtn.TextColor3 = Color3.fromRGB(255, 255, 255)
loopZiplineBtn.Font = Enum.Font.SourceSansBold
loopZiplineBtn.TextSize = 10
Instance.new("UICorner", loopZiplineBtn).CornerRadius = UDim.new(0, 4)
local isZiplineLoop = false
loopZiplineBtn.MouseButton1Click:Connect(function()
    isZiplineLoop = not isZiplineLoop
    loopZiplineBtn.Text = isZiplineLoop and "Loop:\nВКЛ" or "Loop:\nВЫКЛ"
    loopZiplineBtn.BackgroundColor3 = isZiplineLoop and Color3.fromRGB(40, 140, 40) or Color3.fromRGB(160, 40, 40)
end)

local deathZipBtn = Instance.new("TextButton", bPanel)
deathZipBtn.Size = UDim2.new(0.27, -4, 0, 42)
deathZipBtn.Position = UDim2.new(0.50, 2, 0, 72)
deathZipBtn.BackgroundColor3 = Color3.fromRGB(160, 40, 40)
deathZipBtn.Text = "💀 Смерть:\nВЫКЛ"
deathZipBtn.TextColor3 = Color3.fromRGB(255, 255, 255)
deathZipBtn.Font = Enum.Font.SourceSansBold
deathZipBtn.TextSize = 10
Instance.new("UICorner", deathZipBtn).CornerRadius = UDim.new(0, 4)
local deathZiplineEnabled = false
local lastDeathPos = nil
deathZipBtn.MouseButton1Click:Connect(function()
    deathZiplineEnabled = not deathZiplineEnabled
    deathZipBtn.Text = deathZiplineEnabled and "💀 Смерть:\nВКЛ" or "💀 Смерть:\nВЫКЛ"
    deathZipBtn.BackgroundColor3 = deathZiplineEnabled and Color3.fromRGB(40, 140, 40) or Color3.fromRGB(160, 40, 40)
end)

local massActionsBtn = Instance.new("TextButton", bPanel)
massActionsBtn.Size = UDim2.new(0.23, -6, 0, 42)
massActionsBtn.Position = UDim2.new(0.77, 1, 0, 72)
massActionsBtn.BackgroundColor3 = Color3.fromRGB(50, 50, 50)
massActionsBtn.Text = "🧹 Стереть\nвыдел."
massActionsBtn.TextColor3 = Color3.fromRGB(255, 255, 255)
massActionsBtn.Font = Enum.Font.SourceSansBold
massActionsBtn.TextSize = 10
Instance.new("UICorner", massActionsBtn).CornerRadius = UDim.new(0, 4)
massActionsBtn.MouseButton1Click:Connect(function()
    local i = #savedPoints
    while i >= 1 do
        if savedPoints[i].Order and savedPoints[i].Order > 0 then
            if savedPoints[i].Visual then savedPoints[i].Visual:Destroy() end
            table.remove(savedPoints, i)
        end
        i = i - 1
    end
    recalculateOrders()
    refreshPointList()
end)

local function moveToDest(hrp, dest, abortFn)
    if isTeleportMode then
        hrp.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
        hrp.CFrame = CFrame.new(dest)
        return
    end
    local wasAnc = hrp.Anchored
    if not dropOnPoint then hrp.Anchored = true end
    while hrp and hrp.Parent and not _G.ScriptDestroyed do
        if abortFn and abortFn() then break end
        local diff = dest - hrp.Position
        local dist = diff.Magnitude
        if dist <= 1.8 then
            hrp.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
            hrp.CFrame = CFrame.new(dest)
            break
        end
        local dt = RunService.Heartbeat:Wait()
        hrp.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
        hrp.CFrame = CFrame.new(hrp.Position + diff.Unit * math.min(dist, ziplineSpeedValue * dt))
    end
    if hrp and hrp.Parent and not invisActive then hrp.Anchored = wasAnc end
end

local ziplineActive = false
runZiplineBtn.MouseButton1Click:Connect(function()
    if ziplineActive then ziplineActive = false return end
    local char = Player.Character
    local hrp = (invisActive and ghostSimulationCube) or (godmodeEnabled and godGroundCube) or (char and char:FindFirstChild("HumanoidRootPart"))
    if not hrp then return end

    ziplineActive = true
    runZiplineBtn.BackgroundColor3 = Color3.fromRGB(120, 100, 20)
    runZiplineBtn.Text = "🛑 Стоп"

    task.spawn(function()
        repeat
            local ordered = {}
            for _, pt in ipairs(savedPoints) do
                if pt.Order and pt.Order > 0 then table.insert(ordered, pt) end
            end
            table.sort(ordered, function(a, b) return a.Order < b.Order end)
            if #ordered == 0 then break end

            for _, pt in ipairs(ordered) do
                if not ziplineActive or _G.ScriptDestroyed then break end
                local r = (invisActive and ghostSimulationCube) or (godmodeEnabled and godGroundCube) or (Player.Character and Player.Character:FindFirstChild("HumanoidRootPart"))
                if not r then break end
                moveToDest(r, pt.Pos + Vector3.new(0, 3, 0), function() return not ziplineActive end)
                if ziplineDelayValue > 0 and ziplineActive then task.wait(ziplineDelayValue) end
            end
            task.wait(0.05)
        until not isZiplineLoop or not ziplineActive or _G.ScriptDestroyed

        ziplineActive = false
        runZiplineBtn.BackgroundColor3 = Color3.fromRGB(220, 180, 40)
        runZiplineBtn.Text = "🚀 Старт"
    end)
end)

local function bindDeathTracker(char)
    if not char then return end
    local hum = char:WaitForChild("Humanoid", 5)
    local hrp = char:WaitForChild("HumanoidRootPart", 5)
    if hum and hrp then
        hum.Died:Connect(function() if hrp and hrp.Parent then lastDeathPos = hrp.Position end end)
    end
end
if Player.Character then task.spawn(bindDeathTracker, Player.Character) end

Player.CharacterAdded:Connect(function(newChar)
    task.spawn(bindDeathTracker, newChar)
    if not deathZiplineEnabled or _G.ScriptPaused or _G.ScriptDestroyed then return end
    local newHrp = newChar:WaitForChild("HumanoidRootPart", 5)
    if not newHrp then return end
    task.wait(0.45)

    local ordered = {}
    for _, pt in ipairs(savedPoints) do
        if pt.Order and pt.Order > 0 then table.insert(ordered, pt) end
    end
    table.sort(ordered, function(a, b) return a.Order < b.Order end)
    if #ordered == 0 then return end

    local backPos = lastDeathPos or newHrp.Position
    for _, pt in ipairs(ordered) do
        if not deathZiplineEnabled or _G.ScriptDestroyed or not newHrp.Parent then break end
        moveToDest(newHrp, pt.Pos + Vector3.new(0, 3, 0), function() return not deathZiplineEnabled end)
        if ziplineDelayValue > 0 then task.wait(ziplineDelayValue) end
    end
    if deathZiplineEnabled and newHrp.Parent and backPos then
        moveToDest(newHrp, backPos + Vector3.new(0, 3, 0), function() return not deathZiplineEnabled end)
    end
end)

refreshPointList()

-- =========================================================
-- ----- КОНЕЦ ЧАСТИ 10.3 -----
-- =========================================================

-- =========================================================
-- ----- НАЧАЛО ЧАСТИ 11 (v3.0) -----
-- Конфиги / Копия мира / Шейдеры / Макро / Килл-аура
-- Весь код лежит внутри одной функции и не занимает локальные переменные основного скрипта.
-- =========================================================
xpcall(function()

local PH = {}
local HttpService = game:GetService("HttpService")
local UIS3 = game:GetService("UserInputService")
local GuiService3 = game:GetService("GuiService")
local StarterGui3 = game:GetService("StarterGui")

PH.ROOT = "PromptHacker"
PH.CFG = "PromptHacker/configs"
PH.MAC = "PromptHacker/macros"
PH.settings = {
    shaderIdx = 1, shaderStrength = 1,
    killRange = 18, killDelay = 0.12,
    copyHeight = 40, copyYaw = 0,
}
PH.current = "default"
PH.skip = {}
PH.loading = false
PH.autosave = false

-- ---------- общие помощники ----------
function PH.notify(text)
    pcall(function()
        StarterGui3:SetCore("SendNotification", {Title = "⚡ Prompt v3.0", Text = tostring(text), Duration = 4})
    end)
end

function PH.corner(obj, r)
    local c = Instance.new("UICorner")
    c.CornerRadius = UDim.new(0, r or 5)
    c.Parent = obj
end

function PH.label(page, text, height, color)
    local l = Instance.new("TextLabel")
    l.Size = UDim2.new(1, 0, 0, height or 22)
    l.BackgroundTransparency = 1
    l.Text = text
    l.TextColor3 = color or Color3.fromRGB(255, 220, 60)
    l.Font = Enum.Font.SourceSansBold
    l.TextSize = 13
    l.TextWrapped = true
    l.TextXAlignment = Enum.TextXAlignment.Left
    l.Parent = page
    return l
end

function PH.btn(page, text, color, cb)
    local b = Instance.new("TextButton")
    b.Size = UDim2.new(1, 0, 0, 30)
    b.BackgroundColor3 = color or Color3.fromRGB(40, 40, 40)
    b.Text = text
    b.TextColor3 = Color3.fromRGB(255, 255, 255)
    b.TextSize = 13
    b.Font = Enum.Font.SourceSansBold
    b.Parent = page
    PH.corner(b, 5)
    b.MouseButton1Click:Connect(function()
        if _G.ScriptDestroyed then return end
        cb(b)
    end)
    return b
end

function PH.makeList(page, height)
    local sf = Instance.new("ScrollingFrame")
    sf.Size = UDim2.new(1, 0, 0, height)
    sf.BackgroundColor3 = Color3.fromRGB(22, 22, 22)
    sf.BorderSizePixel = 0
    sf.ScrollBarThickness = 4
    sf.CanvasSize = UDim2.new(0, 0, 0, 0)
    sf.Parent = page
    PH.corner(sf, 6)
    local lay = Instance.new("UIListLayout")
    lay.Padding = UDim.new(0, 4)
    lay.Parent = sf
    lay:GetPropertyChangedSignal("AbsoluteContentSize"):Connect(function()
        sf.CanvasSize = UDim2.new(0, 0, 0, lay.AbsoluteContentSize.Y + 6)
    end)
    return sf
end

function PH.clearList(sf)
    for _, c in ipairs(sf:GetChildren()) do
        if c:IsA("Frame") then c:Destroy() end
    end
end

function PH.addRow(sf, text, onMain, onDel)
    local row = Instance.new("Frame")
    row.Size = UDim2.new(1, -6, 0, 28)
    row.BackgroundColor3 = Color3.fromRGB(35, 35, 35)
    row.Parent = sf
    PH.corner(row, 5)

    local b = Instance.new("TextButton")
    b.Size = UDim2.new(1, onDel and -34 or -4, 1, -4)
    b.Position = UDim2.new(0, 2, 0, 2)
    b.BackgroundColor3 = Color3.fromRGB(50, 50, 50)
    b.Text = text
    b.TextColor3 = Color3.fromRGB(255, 255, 255)
    b.TextSize = 12
    b.Font = Enum.Font.SourceSansBold
    b.TextTruncate = Enum.TextTruncate.AtEnd
    b.Parent = row
    PH.corner(b, 4)
    b.MouseButton1Click:Connect(function()
        if _G.ScriptDestroyed then return end
        onMain()
    end)

    if onDel then
        local d = Instance.new("TextButton")
        d.Size = UDim2.new(0, 28, 1, -4)
        d.Position = UDim2.new(1, -30, 0, 2)
        d.BackgroundColor3 = Color3.fromRGB(180, 50, 50)
        d.Text = "✕"
        d.TextColor3 = Color3.fromRGB(255, 255, 255)
        d.TextSize = 13
        d.Font = Enum.Font.SourceSansBold
        d.Parent = row
        PH.corner(d, 4)
        d.MouseButton1Click:Connect(function()
            if _G.ScriptDestroyed then return end
            onDel()
        end)
    end
    return row
end

-- ---------- файлы (папка PromptHacker) ----------
function PH.hasFs()
    return type(writefile) == "function" and type(readfile) == "function"
        and type(isfile) == "function" and type(makefolder) == "function" and type(isfolder) == "function"
end

function PH.ensureDirs()
    if not PH.hasFs() then return false end
    pcall(function()
        for _, d in ipairs({PH.ROOT, PH.CFG, PH.MAC}) do
            if not isfolder(d) then makefolder(d) end
        end
    end)
    return true
end

function PH.write(path, tbl)
    if not PH.ensureDirs() then
        PH.notify("Нет доступа к файлам (writefile) в этом экзекьюторе")
        return false
    end
    local ok, err = pcall(function() writefile(path, HttpService:JSONEncode(tbl)) end)
    if not ok then PH.notify("Ошибка записи: " .. tostring(err)) end
    return ok
end

function PH.read(path)
    if not PH.hasFs() then return nil end
    local ok, res = pcall(function()
        if not isfile(path) then return nil end
        return HttpService:JSONDecode(readfile(path))
    end)
    if ok then return res end
    return nil
end

function PH.listNames(dir)
    local names = {}
    if not PH.hasFs() or type(listfiles) ~= "function" then return names end
    pcall(function()
        if not isfolder(dir) then return end
        for _, f in ipairs(listfiles(dir)) do
            local n = tostring(f):match('([^/\\]+)%.json$')
            if n then table.insert(names, n) end
        end
    end)
    table.sort(names)
    return names
end

function PH.delFile(path)
    pcall(function()
        if type(delfile) == "function" and isfile(path) then delfile(path) end
    end)
end

function PH.safeName(n)
    n = tostring(n or "")
    n = n:gsub('[/\\:*?"<>|%c]', "")
    n = n:match("^%s*(.-)%s*$")
    if n == "" then n = "default" end
    return n
end

function PH.autoPath() return PH.CFG .. "/autoload.txt" end

function PH.getAutoload()
    if not PH.hasFs() then return nil end
    local res
    pcall(function()
        local p = PH.autoPath()
        if isfile(p) then
            local t = readfile(p):match("^%s*(.-)%s*$")
            if t ~= "" then res = t end
        end
    end)
    return res
end

function PH.setAutoload(name)
    if not PH.hasFs() then return end
    pcall(function()
        PH.ensureDirs()
        writefile(PH.autoPath(), name or "")
    end)
end

function PH.v3(v) return {v.X, v.Y, v.Z} end
function PH.toV3(t) return Vector3.new(t[1] or 0, t[2] or 0, t[3] or 0) end

function PH.click(btn)
    if not btn then return end
    local ok = false
    if type(firesignal) == "function" then ok = pcall(firesignal, btn.MouseButton1Click) end
    if not ok and type(getconnections) == "function" then
        pcall(function()
            for _, c in ipairs(getconnections(btn.MouseButton1Click)) do c:Fire() end
        end)
    end
end

-- корень персонажа, которым ты реально управляешь (учитывает бога/инвиз/чернильный дайвинг)
function PH.myRoot()
    local dive = _G.PH_GetDiveRoot and _G.PH_GetDiveRoot()
    if dive then return dive, true end
    local r = (invisActive and ghostSimulationCube) or (godmodeEnabled and godGroundCube)
    if r then return r, false end
    local c = Player.Character
    return c and c:FindFirstChild("HumanoidRootPart"), false
end

local OWN_PREFIXES = {"PromptHitbox", "PromptCopy_", "PromptWorldCopies", "PromptShader", "Phantom_", "Bunker_",
    "ZoneMarker_", "ZoneBoxVisual_", "Cushion_", "BendySurfacePuppet"}

function PH.isOwn(obj)
    local roots = {godAirPlatform, godGroundCube, godVisualClone, ghostSimulationCube, ghostVisualClone, zoneBoxVisual, markerA, markerB}
    for i = 1, 8 do
        local root = roots[i]
        if root and (obj == root or obj:IsDescendantOf(root)) then return true end
    end
    local cur = obj
    while cur and cur ~= workspace do
        local n = cur.Name
        for _, pre in ipairs(OWN_PREFIXES) do
            if n:sub(1, #pre) == pre then return true end
        end
        cur = cur.Parent
    end
    return false
end

function PH.inCharacter(obj)
    local m = obj:FindFirstAncestorOfClass("Model")
    while m do
        if m:FindFirstChildOfClass("Humanoid") then return true end
        m = m:FindFirstAncestorOfClass("Model")
    end
    return false
end

PH.ensureDirs()

-- =========================================================
-- 💾 КОНФИГИ (коробки + точки + включённые тумблеры)
-- =========================================================
function PH.collect()
    local data = {version = 3, toggles = {}, boxes = {}, points = {}, settings = PH.settings,
        zonesEnabled = zonesEnabled and true or false}
    for name, api in pairs(_G.PH_Toggles or {}) do
        if not PH.skip[name] then
            local ok, v = pcall(api.Get)
            if ok and v then data.toggles[name] = true end
        end
    end
    for _, b in ipairs(_G.SavedZoneBoxes or {}) do
        if b.PointA and b.PointB then
            table.insert(data.boxes, {name = b.Name, a = PH.v3(b.PointA), b = PH.v3(b.PointB),
                rule = b.Rule or "", active = (b.Active ~= false)})
        end
    end
    for _, p in ipairs(savedPoints or {}) do
        if p.Pos then
            table.insert(data.points, {name = p.Name, pos = PH.v3(p.Pos), order = p.Order})
        end
    end
    return data
end

function PH.applyBoxes(list)
    for _, b in ipairs(_G.SavedZoneBoxes) do
        pcall(function()
            if b.Visual then b.Visual:Destroy() end
            if b.MarkerA then b.MarkerA:Destroy() end
            if b.MarkerB then b.MarkerB:Destroy() end
        end)
    end
    table.clear(_G.SavedZoneBoxes)
    for _, d in ipairs(list or {}) do
        pcall(function()
            local a, b = PH.toV3(d.a), PH.toV3(d.b)
            local name = tostring(d.name or "Коробка")
            local mA = createZoneMarker(a, name .. " [А]", Color3.fromRGB(255, 220, 60))
            local mB = createZoneMarker(b, name .. " [Б]", Color3.fromRGB(60, 220, 255))
            local vis = buildBoxVisual(a, b, name, d.rule or "")
            table.insert(_G.SavedZoneBoxes, {Name = name, PointA = a, PointB = b, MarkerA = mA, MarkerB = mB,
                Visual = vis, Rule = d.rule or "", Active = (d.active ~= false)})
        end)
    end
    pcall(refreshBoxesList)
end

function PH.makePointVisual(name, pos)
    local part = Instance.new("Part")
    part.Size = Vector3.new(1.5, 1.5, 1.5)
    part.Position = pos
    part.Anchored = true
    part.CanCollide = false
    part.Material = Enum.Material.Neon
    part.Color = Color3.fromRGB(255, 220, 60)
    part.Parent = workspace

    local adorn = Instance.new("BoxHandleAdornment", part)
    adorn.Size = part.Size
    adorn.Color3 = part.Color
    adorn.AlwaysOnTop = true
    adorn.ZIndex = 4
    adorn.Adornee = part

    local bbg = Instance.new("BillboardGui", part)
    bbg.AlwaysOnTop = true
    bbg.Size = UDim2.new(0, 140, 0, 40)
    bbg.StudsOffset = Vector3.new(0, 3, 0)

    local lbl = Instance.new("TextLabel", bbg)
    lbl.Size = UDim2.new(1, 0, 1, 0)
    lbl.BackgroundTransparency = 1
    lbl.Text = name
    lbl.TextColor3 = Color3.fromRGB(255, 220, 60)
    lbl.Font = Enum.Font.SourceSansBold
    lbl.TextSize = 16

    task.spawn(function()
        local cam = workspace.CurrentCamera
        while part and part.Parent and not _G.ScriptDestroyed do
            local dist = (cam.CFrame.Position - part.Position).Magnitude
            lbl.TextSize = math.clamp(14 + (dist / 120), 14, 45)
            task.wait(0.2)
        end
    end)
    return part
end

function PH.applyPoints(list)
    for _, pt in ipairs(savedPoints) do
        pcall(function() if pt.Visual then pt.Visual:Destroy() end end)
    end
    table.clear(savedPoints)
    for _, d in ipairs(list or {}) do
        pcall(function()
            local pos = PH.toV3(d.pos)
            local name = tostring(d.name or "Точка")
            local vis = PH.makePointVisual(name, pos)
            table.insert(savedPoints, {Name = name, Pos = pos, Order = tonumber(d.order), Visual = vis})
        end)
    end
    pcall(recalculateOrders)
    pcall(refreshPointList)
end

function PH.applyToggles(map)
    for name, api in pairs(_G.PH_Toggles or {}) do
        if not PH.skip[name] then
            local want = (map[name] == true)
            local ok, cur = pcall(api.Get)
            if ok and cur ~= want then
                pcall(api.Apply, want)
                task.wait(0.12)
            end
        end
    end
end

function PH.loadConfig(name)
    name = PH.safeName(name)
    local data = PH.read(PH.CFG .. "/" .. name .. ".json")
    if type(data) ~= "table" then
        PH.notify("Конфиг не найден: " .. name)
        return false
    end
    PH.loading = true
    local ok, err = pcall(function()
        if type(data.settings) == "table" then
            for k, v in pairs(data.settings) do PH.settings[k] = v end
        end
        PH.applyBoxes(data.boxes)
        PH.applyPoints(data.points)
        PH.applyToggles(type(data.toggles) == "table" and data.toggles or {})
        local want = (data.zonesEnabled == true)
        if want ~= (zonesEnabled and true or false) then PH.click(toggleZonesBtn) end
        if PH.updateShaderBtn then PH.updateShaderBtn() end
    end)
    PH.loading = false
    if ok then
        PH.notify("Конфиг загружен: " .. name)
    else
        PH.notify("Ошибка загрузки: " .. tostring(err))
    end
    return ok
end

function PH.saveConfig(name)
    name = PH.safeName(name)
    local ok = PH.write(PH.CFG .. "/" .. name .. ".json", PH.collect())
    if ok then
        PH.notify("Конфиг сохранён: " .. name)
        if PH.getAutoload() then PH.setAutoload(name) end
        if PH.refreshCfgList then PH.refreshCfgList() end
    end
    return ok
end

local cfgPage = createTab("💾 Конфиг")
PH.label(cfgPage, "💾 Конфиги: коробки, точки и включённые тумблеры. Папка: PromptHacker/configs", 34)
createInput(cfgPage, "Имя конфига", "default", function(t) PH.current = PH.safeName(t) end)
PH.btn(cfgPage, "💾 Сохранить конфиг", Color3.fromRGB(40, 120, 200), function() PH.saveConfig(PH.current) end)
PH.btn(cfgPage, "📂 Загрузить конфиг", Color3.fromRGB(50, 140, 80), function() task.spawn(PH.loadConfig, PH.current) end)
PH.btn(cfgPage, "🗑 Удалить конфиг", Color3.fromRGB(170, 50, 50), function()
    PH.delFile(PH.CFG .. "/" .. PH.current .. ".json")
    PH.notify("Удалён: " .. PH.current)
    if PH.refreshCfgList then PH.refreshCfgList() end
end)

PH.skip["🔁 Автозагрузка при запуске"] = true
PH.skip["⏱ Автосохранение (каждые 30 с)"] = true
local autoTg = createToggle(cfgPage, "🔁 Автозагрузка при запуске", function(v)
    PH.setAutoload(v and PH.current or nil)
    if v then PH.saveConfig(PH.current) end
end)
createToggle(cfgPage, "⏱ Автосохранение (каждые 30 с)", function(v) PH.autosave = v end)
if PH.getAutoload() then autoTg.Set(true) end

PH.label(cfgPage, "Сохранённые конфиги (нажми — загрузить, ✕ — удалить):", 20, Color3.fromRGB(200, 200, 200))
PH.cfgList = PH.makeList(cfgPage, 120)
function PH.refreshCfgList()
    PH.clearList(PH.cfgList)
    for _, n in ipairs(PH.listNames(PH.CFG)) do
        PH.addRow(PH.cfgList, n, function()
            PH.current = n
            task.spawn(PH.loadConfig, n)
        end, function()
            PH.delFile(PH.CFG .. "/" .. n .. ".json")
            PH.refreshCfgList()
        end)
    end
end
PH.btn(cfgPage, "🔄 Обновить список", Color3.fromRGB(45, 45, 45), function() PH.refreshCfgList() end)
PH.refreshCfgList()

task.spawn(function()
    while not _G.ScriptDestroyed do
        for _ = 1, 60 do
            if _G.ScriptDestroyed then return end
            task.wait(0.5)
        end
        if PH.autosave and not PH.loading then PH.saveConfig(PH.current) end
    end
end)

-- =========================================================
-- 🌍 WORLD COPY (во вкладке «Зоны»): копия всего внутри коробки + вставка куда хочешь + удаление копий
-- Копии клиентские (видишь только ты). Terrain (ландшафт) скопировать нельзя.
-- =========================================================
PH.clip = nil
PH.copies = {}
PH.copyCounter = 0
PH.pasteArmed = false

function PH.copyFolder()
    local f = workspace:FindFirstChild("PromptWorldCopies")
    if not f then
        f = Instance.new("Folder")
        f.Name = "PromptWorldCopies"
        f.Parent = workspace
    end
    return f
end

function PH.copyBox(b)
    if not b or not b.PointA or not b.PointB then return end
    local A, B = b.PointA, b.PointB
    local minX, maxX = math.min(A.X, B.X) - 5, math.max(A.X, B.X) + 5
    local minZ, maxZ = math.min(A.Z, B.Z) - 5, math.max(A.Z, B.Z) + 5
    local minY = (A.Y + B.Y) / 2 - 10
    local h = math.clamp(tonumber(PH.settings.copyHeight) or 40, 5, 1000)
    local size = Vector3.new(maxX - minX, h, maxZ - minZ)
    local center = Vector3.new((minX + maxX) / 2, minY + h / 2, (minZ + maxZ) / 2)
    local origin = CFrame.new((minX + maxX) / 2, minY, (minZ + maxZ) / 2)

    PH.notify("Копирую «" .. tostring(b.Name) .. "»...")
    local params = OverlapParams.new()
    params.FilterType = Enum.RaycastFilterType.Exclude
    params.FilterDescendantsInstances = {}
    local parts = workspace:GetPartBoundsInBox(CFrame.new(center), size, params)
    local limitAxis = math.max(size.X, size.Z, h) * 3
    local items = {}

    for i, p in ipairs(parts) do
        if #items >= 4000 then break end
        if p:IsA("BasePart") and not p:IsA("Terrain") and not PH.isOwn(p) and not PH.inCharacter(p) then
            local s = p.Size
            if math.max(s.X, s.Y, s.Z) <= limitAxis then
                local ok, clone = pcall(function() return p:Clone() end)
                if ok and clone then
                    for _, d in ipairs(clone:GetDescendants()) do
                        if d:IsA("LuaSourceContainer") or d:IsA("JointInstance") or d:IsA("Constraint")
                            or d:IsA("WeldConstraint") or d:IsA("BodyMover") or d:IsA("ProximityPrompt")
                            or d:IsA("ClickDetector") then
                            d:Destroy()
                        end
                    end
                    clone.Anchored = true
                    clone.Parent = nil
                    items[#items + 1] = {template = clone, rel = origin:ToObjectSpace(p.CFrame)}
                end
            end
        end
        if i % 150 == 0 then task.wait() end
    end

    if #items == 0 then
        PH.notify("В коробке нечего копировать (деталей: 0)")
        return
    end
    PH.clip = {name = tostring(b.Name), items = items, radius = math.max(size.X, size.Z) / 2, height = h}
    if PH.clipLabel then PH.clipLabel.Text = "Буфер: «" .. PH.clip.name .. "» — деталей: " .. #items end
    PH.notify("Скопировано деталей: " .. #items)
end

function PH.paste(pos)
    if not PH.clip then
        PH.notify("Сначала скопируй коробку")
        return
    end
    PH.copyCounter = PH.copyCounter + 1
    local yaw = math.rad(tonumber(PH.settings.copyYaw) or 0)
    local rootCf = CFrame.new(pos) * CFrame.Angles(0, yaw, 0)
    local model = Instance.new("Model")
    model.Name = "PromptCopy_" .. PH.copyCounter
    model.Parent = PH.copyFolder()
    for i, item in ipairs(PH.clip.items) do
        local p = item.template:Clone()
        p.CFrame = rootCf * item.rel
        p.Anchored = true
        p.Parent = model
        if i % 200 == 0 then task.wait() end
    end
    table.insert(PH.copies, {name = "Копия " .. PH.copyCounter .. " (" .. PH.clip.name .. ")", model = model})
    if PH.refreshCopies then PH.refreshCopies() end
    PH.notify("Вставлено: Копия " .. PH.copyCounter)
end

PH.label(zonesPage, "🌍 WORLD COPY — копия всего, что внутри коробки (видишь только ты)", 34, Color3.fromRGB(120, 220, 255))
createInput(zonesPage, "Высота копии (студы, дефолт 40)", "5–1000", function(t)
    local n = tonumber(t)
    if n then PH.settings.copyHeight = math.clamp(n, 5, 1000) end
end)
createInput(zonesPage, "Поворот при вставке (°)", "0", function(t)
    local n = tonumber(t)
    if n then PH.settings.copyYaw = n end
end)
PH.label(zonesPage, "1) Выбери коробку для копирования:", 20, Color3.fromRGB(200, 200, 200))
PH.boxList = PH.makeList(zonesPage, 110)
function PH.refreshBoxCopyList()
    PH.clearList(PH.boxList)
    for _, b in ipairs(_G.SavedZoneBoxes or {}) do
        if b.PointA and b.PointB then
            PH.addRow(PH.boxList, "📋 Копировать: " .. tostring(b.Name), function() task.spawn(PH.copyBox, b) end)
        end
    end
end
PH.clipLabel = PH.label(zonesPage, "Буфер: пусто", 22, Color3.fromRGB(200, 200, 200))
PH.label(zonesPage, "2) Вставь копию:", 20, Color3.fromRGB(200, 200, 200))
PH.btn(zonesPage, "📌 Вставить перед собой", Color3.fromRGB(50, 140, 80), function()
    local r = PH.myRoot()
    if not r or not PH.clip then
        PH.notify("Сначала скопируй коробку")
        return
    end
    local look = r.CFrame.LookVector
    look = Vector3.new(look.X, 0, look.Z)
    if look.Magnitude < 0.01 then look = Vector3.new(0, 0, -1) end
    local pos = r.Position + look.Unit * (PH.clip.radius + 6) - Vector3.new(0, 3, 0)
    task.spawn(PH.paste, pos)
end)
PH.armBtn = PH.btn(zonesPage, "🎯 Вставить по тапу (нажми и тапни в мире)", Color3.fromRGB(40, 120, 200), function(b)
    if not PH.clip then
        PH.notify("Сначала скопируй коробку")
        return
    end
    PH.pasteArmed = not PH.pasteArmed
    b.Text = PH.pasteArmed and "🎯 Тапни по месту вставки... (нажми ещё раз — отмена)" or "🎯 Вставить по тапу (нажми и тапни в мире)"
end)
PH.label(zonesPage, "3) Копии (нажми — телепорт к копии, ✕ — удалить):", 20, Color3.fromRGB(200, 200, 200))
PH.copyList = PH.makeList(zonesPage, 100)
function PH.refreshCopies()
    PH.clearList(PH.copyList)
    for idx, c in ipairs(PH.copies) do
        PH.addRow(PH.copyList, "📦 " .. c.name, function()
            local r = PH.myRoot()
            if r and c.model and c.model.Parent then
                local ok, cf, sz = pcall(function() return c.model:GetBoundingBox() end)
                if ok and cf then r.CFrame = CFrame.new(cf.Position + Vector3.new(0, sz.Y / 2 + 4, 0)) end
            end
        end, function()
            pcall(function() c.model:Destroy() end)
            table.remove(PH.copies, idx)
            PH.refreshCopies()
        end)
    end
end
PH.btn(zonesPage, "🗑 Удалить ВСЕ копии", Color3.fromRGB(170, 50, 50), function()
    for _, c in ipairs(PH.copies) do pcall(function() c.model:Destroy() end) end
    table.clear(PH.copies)
    PH.refreshCopies()
    PH.notify("Все копии удалены")
end)

UIS3.InputBegan:Connect(function(input, gp)
    if not PH.pasteArmed or gp or _G.ScriptDestroyed then return end
    local t = input.UserInputType
    if t ~= Enum.UserInputType.MouseButton1 and t ~= Enum.UserInputType.Touch then return end
    PH.pasteArmed = false
    if PH.armBtn then PH.armBtn.Text = "🎯 Вставить по тапу (нажми и тапни в мире)" end
    local cam = workspace.CurrentCamera
    local ray = cam:ViewportPointToRay(input.Position.X, input.Position.Y)
    local rp = RaycastParams.new()
    rp.FilterType = Enum.RaycastFilterType.Exclude
    rp.FilterDescendantsInstances = {Player.Character, PH.copyFolder()}
    local res = workspace:Raycast(ray.Origin, ray.Direction * 2000, rp)
    if res then
        task.spawn(PH.paste, res.Position)
    else
        PH.notify("Не попал по поверхности, попробуй ещё раз")
    end
end)

task.spawn(function()
    local lastSig = nil
    while not _G.ScriptDestroyed do
        local parts = {}
        for _, b in ipairs(_G.SavedZoneBoxes or {}) do parts[#parts + 1] = tostring(b.Name) end
        local sig = table.concat(parts, "|")
        if sig ~= lastSig then
            lastSig = sig
            PH.refreshBoxCopyList()
        end
        task.wait(1)
    end
end)

-- =========================================================
-- ✨ ШЕЙДЕРЫ (реалистичность)
-- =========================================================
PH.presetNames = {"Реализм", "Кино", "Бенди (сепия)", "Яркий", "Мрак"}
PH.presets = {
    {cc = {b = 0.02, c = 0.14, s = 0.14, t = Color3.fromRGB(255, 250, 243)}, bloom = {i = 0.35, sz = 26, th = 0.9},
        rays = {i = 0.10, sp = 0.75}, dof = {f = 0.10, d = 90, r = 140}, lit = {e = 0.12, df = 1, sp = 1, soft = 0.25}},
    {cc = {b = -0.02, c = 0.22, s = -0.12, t = Color3.fromRGB(255, 236, 215)}, bloom = {i = 0.45, sz = 30, th = 0.85},
        rays = {i = 0.08, sp = 0.7}, dof = {f = 0.18, d = 70, r = 90}, lit = {e = 0.05, df = 1, sp = 1, soft = 0.3}},
    {cc = {b = 0, c = 0.25, s = -0.7, t = Color3.fromRGB(255, 222, 175)}, bloom = {i = 0.5, sz = 32, th = 0.8},
        rays = {i = 0.05, sp = 0.6}, dof = {f = 0.22, d = 60, r = 80}, lit = {e = -0.1, df = 1, sp = 1, soft = 0.35}},
    {cc = {b = 0.04, c = 0.08, s = 0.38, t = Color3.fromRGB(255, 255, 255)}, bloom = {i = 0.55, sz = 24, th = 0.85},
        rays = {i = 0.2, sp = 0.9}, dof = {f = 0.05, d = 120, r = 200}, lit = {e = 0.2, df = 1, sp = 1, soft = 0.2}},
    {cc = {b = -0.05, c = 0.25, s = -0.2, t = Color3.fromRGB(190, 200, 255)}, bloom = {i = 0.3, sz = 24, th = 0.9},
        rays = {i = 0.02, sp = 0.5}, dof = {f = 0.15, d = 70, r = 100}, lit = {e = -0.3, df = 1, sp = 1, soft = 0.3}},
}
PH.shaderOn = false
PH.orig = nil

function PH.getFx(class, name)
    local e = Lighting:FindFirstChild(name)
    if e and not e:IsA(class) then
        e:Destroy()
        e = nil
    end
    if not e then
        e = Instance.new(class)
        e.Name = name
        e.Parent = Lighting
    end
    return e
end

function PH.applyShader()
    if not PH.orig then
        PH.orig = {e = Lighting.ExposureCompensation, df = Lighting.EnvironmentDiffuseScale,
            sp = Lighting.EnvironmentSpecularScale, soft = Lighting.ShadowSoftness, sh = Lighting.GlobalShadows}
        pcall(function()
            if type(gethiddenproperty) == "function" then PH.orig.tech = gethiddenproperty(Lighting, "Technology") end
        end)
    end
    local idx = math.clamp(math.floor(tonumber(PH.settings.shaderIdx) or 1), 1, #PH.presets)
    local p = PH.presets[idx]
    local k = math.clamp(tonumber(PH.settings.shaderStrength) or 1, 0.1, 2)

    local cc = PH.getFx("ColorCorrectionEffect", "PromptShader_CC")
    cc.Brightness = p.cc.b * k
    cc.Contrast = p.cc.c * k
    cc.Saturation = p.cc.s * k
    cc.TintColor = p.cc.t

    local bl = PH.getFx("BloomEffect", "PromptShader_Bloom")
    bl.Intensity = p.bloom.i * k
    bl.Size = p.bloom.sz
    bl.Threshold = p.bloom.th

    local sr = PH.getFx("SunRaysEffect", "PromptShader_Rays")
    sr.Intensity = p.rays.i * k
    sr.Spread = p.rays.sp

    local dof = PH.getFx("DepthOfFieldEffect", "PromptShader_DoF")
    dof.FarIntensity = p.dof.f * k
    dof.NearIntensity = 0
    dof.FocusDistance = p.dof.d
    dof.InFocusRadius = p.dof.r

    Lighting.ExposureCompensation = p.lit.e * k
    Lighting.EnvironmentDiffuseScale = p.lit.df
    Lighting.EnvironmentSpecularScale = p.lit.sp
    if not fullBrightEnabled then
        Lighting.GlobalShadows = true
        Lighting.ShadowSoftness = p.lit.soft
    end
    pcall(function()
        if type(sethiddenproperty) == "function" then sethiddenproperty(Lighting, "Technology", Enum.Technology.Future) end
    end)
end

function PH.removeShader()
    for _, n in ipairs({"PromptShader_CC", "PromptShader_Bloom", "PromptShader_Rays", "PromptShader_DoF"}) do
        local e = Lighting:FindFirstChild(n)
        if e then e:Destroy() end
    end
    if PH.orig then
        Lighting.ExposureCompensation = PH.orig.e
        Lighting.EnvironmentDiffuseScale = PH.orig.df
        Lighting.EnvironmentSpecularScale = PH.orig.sp
        if not fullBrightEnabled then
            Lighting.ShadowSoftness = PH.orig.soft
            Lighting.GlobalShadows = PH.orig.sh
        end
        pcall(function()
            if PH.orig.tech and type(sethiddenproperty) == "function" then
                sethiddenproperty(Lighting, "Technology", PH.orig.tech)
            end
        end)
        PH.orig = nil
    end
end

local shPage = createTab("✨ Шейдеры")
PH.label(shPage, "✨ Шейдеры: цвет, блум, лучи солнца, глубина резкости, тени. Можно листать пресеты на лету.", 34)
createToggle(shPage, "✨ Шейдеры (реализм)", function(v)
    PH.shaderOn = v
    if not v then
        PH.removeShader()
        return
    end
    PH.applyShader()
    task.spawn(function()
        while PH.shaderOn and not _G.ScriptDestroyed do
            if not Lighting:FindFirstChild("PromptShader_CC") then PH.applyShader() end
            task.wait(2)
        end
    end)
end)
PH.shaderBtn = PH.btn(shPage, "🎨 Пресет: Реализм (нажми — следующий)", Color3.fromRGB(110, 70, 160), function()
    local n = (math.floor(tonumber(PH.settings.shaderIdx) or 1) % #PH.presets) + 1
    PH.settings.shaderIdx = n
    PH.updateShaderBtn()
    if PH.shaderOn then PH.applyShader() end
end)
function PH.updateShaderBtn()
    local idx = math.clamp(math.floor(tonumber(PH.settings.shaderIdx) or 1), 1, #PH.presets)
    if PH.shaderBtn then PH.shaderBtn.Text = "🎨 Пресет: " .. PH.presetNames[idx] .. " (нажми — следующий)" end
    if PH.shaderOn then PH.applyShader() end
end
createInput(shPage, "Сила эффектов (0.1–2, дефолт 1)", "1", function(t)
    local n = tonumber(t)
    if n then
        PH.settings.shaderStrength = math.clamp(n, 0.1, 2)
        if PH.shaderOn then PH.applyShader() end
    end
end)

-- =========================================================
-- ⚔ КИЛЛ АУРА
-- Ищет ближайшую цель в радиусе и бьёт оружием из рук (Tool): firetouchinterest + Activate.
-- В чернильном дайвинге вылезает на удар через модуль «Вылезать из дайвинга на удар» (его нужно включить).
-- =========================================================
PH.ka = {on = false, npcs = false, hitTeam = false, equip = true, face = false}
PH.npcCache = {}

function PH.refreshNpcs()
    local list = {}
    for _, d in ipairs(workspace:GetDescendants()) do
        if d:IsA("Humanoid") and d.Health > 0 then
            local m = d.Parent
            if m and m:IsA("Model") and m ~= Player.Character and not Players:GetPlayerFromCharacter(m) and not PH.isOwn(m) then
                local r = m:FindFirstChild("HumanoidRootPart") or m.PrimaryPart
                if r then list[#list + 1] = {model = m, hum = d, root = r} end
            end
        end
    end
    PH.npcCache = list
end

function PH.findTarget(pos, range)
    local best, bestD = nil, range
    for _, plr in ipairs(Players:GetPlayers()) do
        if plr ~= Player and plr.Character then
            local hum = plr.Character:FindFirstChildOfClass("Humanoid")
            local r = plr.Character:FindFirstChild("HumanoidRootPart")
            local sameTeam = (Player.Team ~= nil and plr.Team == Player.Team)
            if hum and r and hum.Health > 0 and (PH.ka.hitTeam or not sameTeam) then
                local d = (r.Position - pos).Magnitude
                if d <= bestD then best, bestD = r, d end
            end
        end
    end
    if PH.ka.npcs then
        for _, n in ipairs(PH.npcCache) do
            if n.hum and n.hum.Parent and n.hum.Health > 0 and n.root and n.root.Parent then
                local d = (n.root.Position - pos).Magnitude
                if d <= bestD then best, bestD = n.root, d end
            end
        end
    end
    return best
end

function PH.attack(targetRoot)
    local char = Player.Character
    if not char then return end
    local hum = char:FindFirstChildOfClass("Humanoid")
    local tool = char:FindFirstChildOfClass("Tool")
    if not tool and PH.ka.equip and hum then
        local bp = Player:FindFirstChildOfClass("Backpack")
        local t = bp and bp:FindFirstChildOfClass("Tool")
        if t then
            pcall(function() hum:EquipTool(t) end)
            task.wait(0.1)
            tool = char:FindFirstChildOfClass("Tool")
        end
    end
    if not tool then return end

    local function swing()
        local handle = tool:FindFirstChild("Handle")
        if handle and type(firetouchinterest) == "function" then
            pcall(firetouchinterest, handle, targetRoot, 0)
            pcall(firetouchinterest, handle, targetRoot, 1)
        end
        pcall(function() tool:Activate() end)
    end

    if _G.PH_IsDiving and _G.PH_IsDiving() then
        if _G.PH_InkPop then _G.PH_InkPop(swing) end
    else
        swing()
    end
end

function PH.startKillAura()
    PH.ka.on = true
    task.spawn(function()
        local lastNpc = 0
        while PH.ka.on and not _G.ScriptDestroyed do
            if not _G.ScriptPaused then
                local root, diving = PH.myRoot()
                local hum = Player.Character and Player.Character:FindFirstChildOfClass("Humanoid")
                if root and hum and hum.Health > 0 then
                    if PH.ka.npcs and tick() - lastNpc > 5 then
                        lastNpc = tick()
                        PH.refreshNpcs()
                    end
                    local t = PH.findTarget(root.Position, tonumber(PH.settings.killRange) or 18)
                    if t then
                        if PH.ka.face and not diving then
                            pcall(function()
                                root.CFrame = CFrame.lookAt(root.Position, Vector3.new(t.Position.X, root.Position.Y, t.Position.Z))
                            end)
                        end
                        PH.attack(t)
                    end
                end
            end
            task.wait(math.clamp(tonumber(PH.settings.killDelay) or 0.12, 0.05, 2))
        end
    end)
end

local kaPage = createTab("⚔ Килл Аура")
PH.label(kaPage, "⚔ Килл Аура: бьёт ближайшую цель в радиусе предметом из рук. В дайвинге — вылезает на удар (включи «Вылезать из дайвинга на удар»).", 48)
createToggle(kaPage, "⚔ Килл Аура", function(v)
    PH.ka.on = false
    if v then PH.startKillAura() end
end)
createInput(kaPage, "Радиус (студы, дефолт 18)", "5–200", function(t)
    local n = tonumber(t)
    if n then PH.settings.killRange = math.clamp(n, 3, 200) end
end)
createInput(kaPage, "Задержка между ударами (сек)", "0.12", function(t)
    local n = tonumber(t)
    if n then PH.settings.killDelay = math.clamp(n, 0.05, 2) end
end)
createToggle(kaPage, "🧟 Бить NPC (мобов/боссов)", function(v)
    PH.ka.npcs = v
    if v then task.spawn(PH.refreshNpcs) end
end)
createToggle(kaPage, "👥 Бить и своих по команде", function(v) PH.ka.hitTeam = v end)
local kaEquip = createToggle(kaPage, "🗡 Авто-экип оружия из рюкзака", function(v) PH.ka.equip = v end)
kaEquip.Set(true)
createToggle(kaPage, "🎯 Поворачиваться к цели", function(v) PH.ka.face = v end)

-- =========================================================
-- 🎬 МАКРО / SMART-МАКРО (папка PromptHacker/macros)
-- Запись: клавиши, нажатия по экрану (тапы) и, по желанию, твой путь (позиция). Повтор с ограничениями.
-- =========================================================
PH.mac = {rec = false, play = false, events = {}, t0 = 0, recPos = false, held = {}, ptrDown = nil,
    name = "macro1", opts = {loops = 1, speed = 1, pause = 0.2, maxTime = 0, hpStop = 0, enemyR = 0}}

function PH.overMyUI(pos)
    for _, ch in ipairs(ScreenGui:GetChildren()) do
        if ch:IsA("GuiObject") and ch.Visible then
            local p, s = ch.AbsolutePosition, ch.AbsoluteSize
            if pos.X >= p.X and pos.X <= p.X + s.X and pos.Y >= p.Y and pos.Y <= p.Y + s.Y then return true end
        end
    end
    return false
end

function PH.updateMacUi()
    local m = PH.mac
    if PH.macStatus then
        local st = m.rec and "● ЗАПИСЬ" or (m.play and "▶ ВОСПРОИЗВЕДЕНИЕ" or "ожидание")
        PH.macStatus.Text = "Статус: " .. st .. " | событий: " .. #m.events
    end
    if PH.recBtn then
        PH.recBtn.Text = m.rec and "⏹ Остановить запись" or "⏺ Начать запись"
        PH.recBtn.BackgroundColor3 = m.rec and Color3.fromRGB(180, 50, 50) or Color3.fromRGB(40, 120, 200)
    end
    if PH.playBtn then
        PH.playBtn.Text = m.play and "⏹ Остановить макро" or "▶ Запустить макро"
        PH.playBtn.BackgroundColor3 = m.play and Color3.fromRGB(180, 110, 40) or Color3.fromRGB(50, 140, 80)
    end
end

function PH.onInput(input, down)
    local m = PH.mac
    if not m.rec or _G.ScriptDestroyed then return end
    local ut = input.UserInputType
    local t = tick() - m.t0
    local e
    if ut == Enum.UserInputType.Keyboard then
        if UIS3:GetFocusedTextBox() then return end
        e = {t = t, k = "key", c = input.KeyCode.Name, d = down}
    elseif ut == Enum.UserInputType.MouseButton1 or ut == Enum.UserInputType.MouseButton2 or ut == Enum.UserInputType.Touch then
        local pos = Vector2.new(input.Position.X, input.Position.Y)
        if PH.overMyUI(pos) then return end
        e = {t = t, k = "ptr", b = (ut == Enum.UserInputType.MouseButton2) and 1 or 0, x = pos.X, y = pos.Y, d = down}
    end
    if e then
        table.insert(m.events, e)
        if #m.events % 5 == 0 then PH.updateMacUi() end
    end
end
UIS3.InputBegan:Connect(function(input) PH.onInput(input, true) end)
UIS3.InputEnded:Connect(function(input) PH.onInput(input, false) end)

function PH.startRecording()
    local m = PH.mac
    if m.play then return end
    m.events = {}
    m.t0 = tick()
    m.rec = true
    PH.updateMacUi()
    task.spawn(function()
        local last = nil
        while m.rec and not _G.ScriptDestroyed do
            if m.recPos then
                local r = PH.myRoot()
                if r then
                    local p = r.Position
                    if not last or (p - last).Magnitude > 0.6 then
                        last = p
                        local _, ry = r.CFrame:ToEulerAnglesYXZ()
                        table.insert(m.events, {t = tick() - m.t0, k = "pos", x = p.X, y = p.Y, z = p.Z, r = ry})
                    end
                end
            end
            task.wait(0.15)
        end
    end)
end

function PH.stopRecording()
    PH.mac.rec = false
    PH.updateMacUi()
    PH.notify("Записано событий: " .. #PH.mac.events)
end

function PH.stopPlay()
    local m = PH.mac
    m.play = false
    for code in pairs(m.held) do
        pcall(function() VirtualInputManager:SendKeyEvent(false, Enum.KeyCode[code], false, game) end)
    end
    m.held = {}
    if m.ptrDown then
        local p = m.ptrDown
        pcall(function() VirtualInputManager:SendMouseButtonEvent(p.x, p.y, p.b, false, game, 0) end)
        m.ptrDown = nil
    end
    PH.updateMacUi()
end

function PH.exec(e, nextPos)
    local m = PH.mac
    if e.k == "key" then
        local ok, code = pcall(function() return Enum.KeyCode[e.c] end)
        if ok and code then
            pcall(function() VirtualInputManager:SendKeyEvent(e.d and true or false, code, false, game) end)
            m.held[e.c] = e.d and true or nil
        end
    elseif e.k == "ptr" then
        local inset = GuiService3:GetGuiInset()
        local y = e.y + inset.Y
        pcall(function() VirtualInputManager:SendMouseButtonEvent(e.x, y, e.b or 0, e.d and true or false, game, 0) end)
        m.ptrDown = e.d and {x = e.x, y = y, b = e.b or 0} or nil
    elseif e.k == "pos" then
        local r = PH.myRoot()
        if r then
            local target = CFrame.new(e.x, e.y, e.z) * CFrame.Angles(0, e.r or 0, 0)
            local dur = nextPos and math.clamp((nextPos.t - e.t) / m.opts.speed, 0.03, 2) or 0.1
            pcall(function()
                r.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
                TweenService:Create(r, TweenInfo.new(dur, Enum.EasingStyle.Linear), {CFrame = target}):Play()
            end)
        end
    end
end

function PH.enemyNear(range)
    local r = PH.myRoot()
    if not r then return false end
    return PH.findTarget(r.Position, range) ~= nil
end

function PH.playMacro(events)
    local m = PH.mac
    if m.play or m.rec then return end
    if #events == 0 then
        PH.notify("Макро пустое: сначала запиши или загрузи")
        return
    end
    m.play = true
    PH.updateMacUi()
    task.spawn(function()
        local o = m.opts
        local started = tick()
        local loop = 0

        local nextPos = {}
        local upcoming = nil
        for i = #events, 1, -1 do
            nextPos[i] = upcoming
            if events[i].k == "pos" then upcoming = events[i] end
        end

        local function limitHit()
            if o.maxTime > 0 and tick() - started > o.maxTime then return true end
            if o.hpStop > 0 then
                local h = Player.Character and Player.Character:FindFirstChildOfClass("Humanoid")
                if h and h.MaxHealth > 0 and (h.Health / h.MaxHealth * 100) < o.hpStop then return true end
            end
            return false
        end

        while m.play and not _G.ScriptDestroyed do
            loop = loop + 1
            if o.loops > 0 and loop > o.loops then break end

            if o.enemyR > 0 then
                if PH.ka.npcs and #PH.npcCache == 0 then PH.refreshNpcs() end
                while m.play and not limitHit() and not PH.enemyNear(o.enemyR) do task.wait(0.2) end
                if not m.play or limitHit() then break end
            end

            local base = tick()
            local stopAll = false
            for i, e in ipairs(events) do
                while m.play and (tick() - base) < (e.t / o.speed) do task.wait(0.01) end
                if not m.play then break end
                while _G.ScriptPaused and m.play do task.wait(0.2) end
                if limitHit() then
                    stopAll = true
                    break
                end
                PH.exec(e, nextPos[i])
            end
            if stopAll then break end

            if o.pause > 0 then
                local w = tick()
                while m.play and tick() - w < o.pause do task.wait(0.05) end
            end
        end
        PH.stopPlay()
    end)
end

function PH.saveMacro(name)
    name = PH.safeName(name)
    local m = PH.mac
    if #m.events == 0 then
        PH.notify("Нечего сохранять: макро пустое")
        return
    end
    local ok = PH.write(PH.MAC .. "/" .. name .. ".json", {name = name, events = m.events, opts = m.opts, recPos = m.recPos})
    if ok then
        PH.notify("Макро сохранено: " .. name)
        if PH.refreshMacList then PH.refreshMacList() end
    end
end

function PH.loadMacro(name)
    name = PH.safeName(name)
    local data = PH.read(PH.MAC .. "/" .. name .. ".json")
    if type(data) ~= "table" or type(data.events) ~= "table" then
        PH.notify("Макро не найдено: " .. name)
        return
    end
    local m = PH.mac
    if m.play then PH.stopPlay() end
    m.events = data.events
    m.name = name
    if type(data.opts) == "table" then
        for k, v in pairs(data.opts) do
            if type(v) == "number" then m.opts[k] = v end
        end
    end
    PH.updateMacUi()
    PH.notify("Макро загружено: " .. name .. " (" .. #m.events .. ")")
end

local macPage = createTab("🎬 Макро")
PH.label(macPage, "🎬 Макро: записывает клавиши, тапы по экрану и (по желанию) твой путь. Папка: PromptHacker/macros", 34)
PH.macStatus = PH.label(macPage, "Статус: ожидание | событий: 0", 20, Color3.fromRGB(200, 200, 200))
createInput(macPage, "Имя макро", "macro1", function(t) PH.mac.name = PH.safeName(t) end)
local recPosTg = createToggle(macPage, "🚶 Записывать позицию (путь)", function(v) PH.mac.recPos = v end)
PH.skip["🚶 Записывать позицию (путь)"] = false
PH.recBtn = PH.btn(macPage, "⏺ Начать запись", Color3.fromRGB(40, 120, 200), function()
    if PH.mac.rec then PH.stopRecording() else PH.startRecording() end
end)
PH.playBtn = PH.btn(macPage, "▶ Запустить макро", Color3.fromRGB(50, 140, 80), function()
    if PH.mac.play then PH.stopPlay() else PH.playMacro(PH.mac.events) end
end)
PH.btn(macPage, "💾 Сохранить макро в файл", Color3.fromRGB(40, 90, 150), function() PH.saveMacro(PH.mac.name) end)
PH.btn(macPage, "📂 Загрузить макро по имени", Color3.fromRGB(60, 110, 60), function() PH.loadMacro(PH.mac.name) end)

PH.label(macPage, "🧠 SMART-ограничения (0 = выключено):", 20, Color3.fromRGB(120, 220, 255))
createInput(macPage, "Повторов (0 = бесконечно)", "1", function(t)
    local n = tonumber(t)
    if n then PH.mac.opts.loops = math.max(0, math.floor(n)) end
end)
createInput(macPage, "Скорость (x, дефолт 1)", "1", function(t)
    local n = tonumber(t)
    if n then PH.mac.opts.speed = math.clamp(n, 0.1, 10) end
end)
createInput(macPage, "Пауза между повторами (сек)", "0.2", function(t)
    local n = tonumber(t)
    if n then PH.mac.opts.pause = math.clamp(n, 0, 600) end
end)
createInput(macPage, "Макс. время работы (сек)", "0", function(t)
    local n = tonumber(t)
    if n then PH.mac.opts.maxTime = math.max(0, n) end
end)
createInput(macPage, "Стоп, если HP ниже (%)", "0", function(t)
    local n = tonumber(t)
    if n then PH.mac.opts.hpStop = math.clamp(n, 0, 100) end
end)
createInput(macPage, "Работать, только пока враг в радиусе", "0", function(t)
    local n = tonumber(t)
    if n then PH.mac.opts.enemyR = math.clamp(n, 0, 500) end
end)

PH.label(macPage, "Сохранённые макро (нажми — загрузить, ✕ — удалить):", 20, Color3.fromRGB(200, 200, 200))
PH.macList = PH.makeList(macPage, 110)
function PH.refreshMacList()
    PH.clearList(PH.macList)
    for _, n in ipairs(PH.listNames(PH.MAC)) do
        PH.addRow(PH.macList, n, function() PH.loadMacro(n) end, function()
            PH.delFile(PH.MAC .. "/" .. n .. ".json")
            PH.refreshMacList()
        end)
    end
end
PH.btn(macPage, "🔄 Обновить список макро", Color3.fromRGB(45, 45, 45), function() PH.refreshMacList() end)
PH.refreshMacList()
PH.updateMacUi()

-- =========================================================
-- Закрытие скрипта: убираем копии, шейдеры, останавливаем аура/макро. Автозагрузка конфига при запуске.
-- =========================================================
task.spawn(function()
    while not _G.ScriptDestroyed do task.wait(0.5) end
    if PH.autosave and not PH.loading then pcall(PH.saveConfig, PH.current) end
    PH.ka.on = false
    PH.shaderOn = false
    PH.mac.rec = false
    pcall(PH.stopPlay)
    pcall(PH.removeShader)
    pcall(function()
        local f = workspace:FindFirstChild("PromptWorldCopies")
        if f then f:Destroy() end
    end)
end)

task.spawn(function()
    task.wait(2.5)
    local name = PH.getAutoload()
    if name then
        PH.current = name
        PH.loadConfig(name)
    end
end)

end, function(err)
    warn("[PromptHacker v3.0] Часть 11: " .. tostring(err))
end)
-- =========================================================
-- ----- КОНЕЦ ЧАСТИ 11 -----
-- =========================================================


-- Отключение диагностики при полном закрытии GUI
task.spawn(function()
    while not _G.ScriptDestroyed do task.wait(0.5) end
    if phLogConnection then pcall(function() phLogConnection:Disconnect() end); phLogConnection = nil end
end)
